# Case Study 5 bundle

Unpacked by notebook `07_cs5_report_qa` into `_local/cs5_bundle/`. Every file is listed with its checksum in
`cs5_bundle_manifest.json` next to the notebook.

- `build/` holds the case study's Python modules and documents in the layout they were built in.
  - `cs5_core.py`, `cs5_checks.py` and `cs5_llm_checks.py` are byte-identical to the versions frozen on
    23 September 2026 at 10:09 UTC, before the hold-out errors were planted. The notebook checks their checksums and
    applies the three post-hoc changes at run time, in a cell you can read and switch off.
  - `cs5_llm.py` is the notebook's version of the call module: it takes its client, ledger and session cap from the
    notebook, counts the calls under way against the cap, and sends nothing more once three requests in a row have
    failed on a timeout, a lost connection or a server error. Its interface and its fingerprint function are those of
    the build version.
  - `cs5_warmup.py` and `cs5_translate.py` differ from the build versions in docstrings and one label only.
  - `facts.json`, `drivers.md`, the three documents (fresh, gold, planted), the templates, the charts and the label
    files (`error_log.json`, `judge_testset.json`, `gold_corrections.json`).
  - `work/_chart_rerender_3e9262249866.png`: the reference render of the gold chart from `facts.json`, made in the
    build; the provenance check D-CHART compares every chart with it.
- `legal/spec.json`: the machine-readable legal specification (element list, verbatim texts in English and
  Lithuanian, page cap, notice), retrieved from the Official Journal on 23 September 2026.

Brisendale Mutual is a fictitious insurer; every figure is synthetic.
