"""Grader: runs a test suite in a separate pytest process and decides the route.

This is the "grade" half of "run, then grade". The pytest process never
imports the translated module: it only compares the runner's outputs JSON
(runner.py) with R's ground truth.

    from grade import run_grader
    verdict = run_grader("chain_ladder", "outputs.json", bundle_dir="_local/cs4_bundle")
    verdict["passed"], verdict["n_passed"], verdict["failures"]

pytest is started with
* ``-p no:cacheprovider`` and ``PYTHONDONTWRITEBYTECODE=1``: no .pytest_cache
  or __pycache__ folders are written;
* ``PYTEST_DISABLE_PLUGIN_AUTOLOAD=1``: plugins installed in the environment
  (Colab has several) are not loaded;
* an empty ini file in a temporary folder (``-c``) and ``--rootdir`` set to the
  tests folder, so that no stray configuration file is picked up;
* the explicit path of ONE test file.

Routing (``passed``) requires all three to agree: pytest's exit code is 0,
the results JSON lists exactly the expected test ids (the ``def test_*``
names in the file), and every one of them passed. Any disagreement counts as
a failure and is reported as ``consistent = False``.

``run_article_suite`` runs the article's original suites (tests_article/).
Those import the module under test into the pytest process, as the article
did; use them only on code you have read (mutants, archived translations),
never on fresh LLM output.
"""

from __future__ import annotations

import ast
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time

from runner import scrubbed_env

HARNESS_DIR = os.path.dirname(os.path.abspath(__file__))


def expected_test_ids(test_file: str) -> list[str]:
    with open(test_file, encoding="utf-8") as f:
        tree = ast.parse(f.read())
    return [n.name for n in tree.body if isinstance(n, ast.FunctionDef) and n.name.startswith("test_")]


def _pytest(test_file: str, rootdir: str, env_extra: dict, timeout: float) -> tuple[int, dict | None, float]:
    work = tempfile.mkdtemp(prefix="cs4grade_")
    try:
        ini = os.path.join(work, "pytest.ini")
        with open(ini, "w", encoding="utf-8", newline="\n") as f:
            f.write("[pytest]\n")
        results_json = os.path.join(work, "results.json")
        env = scrubbed_env()
        env.pop("PYTEST_ADDOPTS", None)
        env.update({"PYTEST_DISABLE_PLUGIN_AUTOLOAD": "1", "CS4_RESULTS_JSON": results_json})
        env.update(env_extra)
        cmd = [sys.executable, "-m", "pytest", "-p", "no:cacheprovider", "-c", ini, "--rootdir", rootdir,
               "-q", "--tb=no", "--no-header", "-p", "no:warnings", test_file]
        t0 = time.perf_counter()
        try:
            proc = subprocess.run(cmd, cwd=work, env=env, stdin=subprocess.DEVNULL,
                                  stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=timeout)
            code = proc.returncode  # pytest's console output is discarded on purpose
        except subprocess.TimeoutExpired:
            code = -1
        seconds = time.perf_counter() - t0
        results = None
        if os.path.exists(results_json):
            with open(results_json, encoding="utf-8") as f:
                results = json.load(f)
        return code, results, seconds
    finally:
        shutil.rmtree(work, ignore_errors=True)


def _verdict(code: int, results: dict | None, expected: list[str], seconds: float) -> dict:
    rows = (results or {}).get("results", [])
    ids = [r["id"] for r in rows]
    consistent = results is not None and sorted(ids) == sorted(expected)
    all_passed = consistent and all(r["outcome"] == "passed" for r in rows)
    passed = code == 0 and all_passed
    by_cat: dict[str, list[int]] = {}
    for r in rows:
        c = by_cat.setdefault(r["category"], [0, 0])
        c[1] += 1
        c[0] += r["outcome"] == "passed"
    return {
        "passed": passed,
        "exit_code": code,
        "consistent": consistent and ((code == 0) == all_passed),
        "n_tests": len(expected),
        "n_passed": sum(1 for r in rows if r["outcome"] == "passed"),
        "by_category": by_cat,
        "failures": [{"id": r["id"], "category": r["category"], "message": r["message"]}
                     for r in rows if r["outcome"] != "passed"],
        "missing_ids": sorted(set(expected) - set(ids)),
        "seconds": round(seconds, 3),
    }


def run_grader(example: str, outputs_json: str, bundle_dir: str, timeout: float = 120) -> dict:
    """Grade the runner's outputs for one example with the new suite."""
    tests_dir = os.path.abspath(os.path.join(bundle_dir, "tests"))
    test_file = os.path.join(tests_dir, f"test_{example}.py")
    env = {"CS4_OUTPUTS_JSON": os.path.abspath(outputs_json),
           "CS4_GROUND_TRUTH_DIR": os.path.abspath(os.path.join(bundle_dir, "ground_truth"))}
    code, results, seconds = _pytest(test_file, tests_dir, env, timeout)
    return _verdict(code, results, expected_test_ids(test_file), seconds)


def run_article_suite(example: str, module_dir: str, bundle_dir: str, adaptee: str | None = None,
                      timeout: float = 300) -> dict:
    """Run the article's suite on the module ``<module_dir>/<example>.py``.

    ``adaptee``: path of a module written for the NEW interface; the module
    in ``module_dir`` is then the adapter (mutants/article_adapter/) that
    maps the article's calls onto it.
    """
    tests_dir = os.path.abspath(os.path.join(bundle_dir, "tests_article"))
    test_file = os.path.join(tests_dir, f"test_{example}_article.py")
    env = {"CS4_ARTICLE_TRANSLATED_DIR": os.path.abspath(module_dir)}
    if adaptee:
        env["CS4_ADAPTEE"] = os.path.abspath(adaptee)
    code, results, seconds = _pytest(test_file, tests_dir, env, timeout)
    return _verdict(code, results, expected_test_ids(test_file), seconds)


if __name__ == "__main__":
    print(json.dumps(run_grader(sys.argv[1], sys.argv[2], sys.argv[3]), indent=1))
