"""A PEP 578 audit-hook fence for running LLM-translated code.

This is a *teaching fence, not a production sandbox*. It runs inside the
runner's child process (see runner.py). The runner loads its inputs, installs
the fence, and only then imports the translated module. From then on every
operation that CPython reports as an audit event passes through the hook
below, which raises ``PermissionError`` for anything outside the fence:

* ``open`` (also ``io.open_code`` and ``os.open``): reading only inside the
  run's workspace folder and inside the Python installation (standard library
  and site-packages, needed for lazy imports); writing only inside the
  workspace (a temporary folder that is deleted after the run; the runner's
  own output file lies there and is written last, after all calls).
* directory listings (``os.listdir``, ``os.scandir``, ``glob.glob``): only
  inside those read roots.
* file-system changes (remove, rename, mkdir, chmod, ...), ``os.chdir``,
  changes to the environment.
* processes: ``subprocess.Popen``, ``os.system``, ``os.exec*``, ``os.spawn*``,
  ``os.posix_spawn``, ``os.fork``, ``os.startfile``, ``pty.spawn``, ``_winapi.*``.
* network: every ``socket.*`` event, ``urllib.Request``, ``http.client``,
  ``ftplib``, ``smtplib``, ``imaplib``, ``poplib``, ``webbrowser``.
* ``sqlite3.connect`` to a database file outside the workspace; SQLite
  extensions.
* ``ctypes.*`` and the Windows registry (``winreg.*``: API keys can live there).
* introspection that could reach the runner: ``sys._getframe`` when it would
  return a frame of the translated module or of the harness,
  ``sys._current_frames``, ``gc.get_objects/get_referrers/get_referents``,
  ``sys.settrace``, ``sys.setprofile``, further audit hooks, new threads.

How the hook protects itself: its settings are immutable tuples bound as
default arguments of a closure that only the interpreter's hook list holds;
the helper functions it needs (getcwd, isinstance, ...) are captured when the
fence is installed, so patching ``os.path`` or ``builtins`` later has no
effect on it; any error inside the hook refuses the operation (fail closed);
paths must be exact ``str``/``bytes``/``pathlib`` objects (a path-like object
with its own ``__fspath__`` could answer differently the second time).

Known limits (say them when you teach this):

* Audit hooks see only what CPython reports. Frame objects reached through an
  exception's ``__traceback__`` and ``f_back`` are not audited. The runner
  process therefore holds no expected values at all (grading happens in a
  separate process), so there is nothing to find there.
* ``os.environ`` fires no event: the runner removes every variable whose name
  contains KEY, TOKEN, SECRET or PASSWORD before it starts the child.
* SQLite's ``ATTACH DATABASE`` runs inside SQLite's C code and fires no event.
  No answers are stored as SQLite files.
* Native code inside extension modules can do anything. The import allow-list
  in the interface text and the AST tripwire (tripwire.py) are further layers;
  human review is the last one.
"""

from __future__ import annotations

import os
import pathlib
import site
import sys

BLOCK_EXACT = frozenset({
    "subprocess.Popen", "os.system", "os.exec", "os.spawn", "os.posix_spawn", "os.fork",
    "os.forkpty", "os.startfile", "os.startfile/2", "os.kill", "os.killpg", "pty.spawn",
    "urllib.Request", "http.client.connect", "http.client.send", "ftplib.connect",
    "smtplib.connect", "imaplib.open", "poplib.connect", "nntplib.connect",
    "telnetlib.Telnet.open", "webbrowser.open", "ensurepip.bootstrap",
    "sys._current_frames", "gc.get_objects", "gc.get_referrers", "gc.get_referents",
    "sys.settrace", "sys.setprofile", "sys.addaudithook", "_thread.start_new_thread",
    "_thread.start_joinable_thread",
    "sqlite3.enable_load_extension", "sqlite3.load_extension",
    "os.chdir", "os.remove", "os.rename", "os.rmdir", "os.mkdir", "os.symlink", "os.link",
    "os.chmod", "os.chown", "os.chflags", "os.lchflags", "os.truncate", "os.utime",
    "os.setxattr", "os.removexattr", "os.putenv", "os.unsetenv",
    "shutil.rmtree", "shutil.copyfile", "shutil.copymode", "shutil.copystat",
    "shutil.copytree", "shutil.move", "shutil.chown", "shutil.make_archive",
    "shutil.unpack_archive",
})
BLOCK_PREFIX = ("socket.", "ctypes.", "winreg.", "_winapi.")
LISTING_EVENTS = frozenset({"os.listdir", "os.scandir", "glob.glob", "glob.glob/2"})
WRITE_FLAGS = (os.O_WRONLY | os.O_RDWR | os.O_APPEND | os.O_CREAT | os.O_TRUNC
               | getattr(os, "O_EXCL", 0))
WINDOWS = os.name == "nt"
SEP = "\\" if WINDOWS else "/"
PATH_TYPES = (pathlib.PurePosixPath, pathlib.PureWindowsPath, pathlib.PosixPath, pathlib.WindowsPath)


def make_normaliser():
    """Return a fresh path normaliser whose helpers are bound when it is made.

    The normaliser gives an absolute, '..'-free, case-normalised path using
    string operations only. It deliberately does not follow links: the fence
    denies by default, and the workspace (created by the runner) holds none.
    Built-ins are bound as default arguments, so a translation that later
    replaces ``builtins.len`` (for example) cannot change its behaviour, and
    the copy used by the hook is reachable only through the hook.
    """
    def normalise(path, cwd, _len=len, _win=WINDOWS, _sep=SEP):
        p = path.replace("/", "\\") if _win else path
        if _win:
            if p.startswith("\\\\"):
                return p.lower()  # UNC or device path: never inside a read root
            if _len(p) >= 2 and p[1] == ":":
                if _len(p) == 2 or p[2] != "\\":
                    p = cwd + "\\" + p[2:]  # drive-relative such as 'C:x'
            elif p.startswith("\\"):
                p = cwd[:2] + p  # rooted on the current drive
            else:
                p = cwd + "\\" + p
        elif not p.startswith("/"):
            p = cwd + "/" + p
        parts = []
        for part in p.split(_sep):
            if part == "" or part == ".":
                continue
            if part == "..":
                if _len(parts) > 1 or (not _win and _len(parts) > 0):
                    parts.pop()
                continue
            parts.append(part)
        out = _sep.join(parts) if _win else "/" + "/".join(parts)
        return out.lower() if _win else out
    return normalise


normalise = make_normaliser()  # for set-up code; the hook gets its own copy


def python_read_roots() -> list[str]:
    """Folders of the running Python installation (stdlib and site-packages)."""
    roots = {sys.prefix, sys.base_prefix, sys.exec_prefix, sys.base_exec_prefix}
    try:
        roots.update(site.getsitepackages())
    except Exception:  # some virtualenv builds lack it
        pass
    try:
        roots.add(site.getusersitepackages())
    except Exception:
        pass
    for name in ("numpy", "pandas", "scipy", "statsmodels", "patsy", "dateutil", "pytz", "tzdata"):
        f = getattr(sys.modules.get(name), "__file__", None)
        if f:
            roots.add(os.path.dirname(os.path.dirname(f)))
    # Keep each folder both as written and link-resolved: on some Windows setups
    # (packaged apps) realpath maps AppData to a redirected location, while
    # the import system opens files under the path as written.
    out = set()
    for r in roots:
        if r and os.path.isdir(r):
            out.add(os.path.abspath(r))
            out.add(os.path.realpath(r))
    return sorted(out)


def install(workspace: str, write_path: str, guarded_files: list[str],
            extra_read_roots: list[str] | None = None) -> list[dict]:
    """Install the fence for the rest of this process; it cannot be removed.

    Returns a list to which refused events are appended (event name and a
    file base name only, never a full path), for the runner's report.
    """
    cwd0 = os.getcwd()

    def both(p):  # the path as written and link-resolved (see python_read_roots)
        return {normalise(os.path.abspath(p), cwd0), normalise(os.path.realpath(p), cwd0)}

    ws_forms = tuple(sorted(both(workspace)))
    ws = ws_forms[0]
    extra = set()
    for r in (extra_read_roots or []):
        extra |= both(r)
    read_roots = tuple(sorted(set(ws_forms) | {normalise(r, cwd0) for r in python_read_roots()} | extra))
    write_forms = frozenset(both(write_path))
    guarded = frozenset(x for f in guarded_files for x in both(f))
    log: list[dict] = []
    norm = make_normaliser()  # private copy, reachable only through the hook

    def inside(path, root, _sep=SEP):
        return path == root or path.startswith(root.rstrip(_sep) + _sep)

    def last_part(path, _sep=SEP):
        return path.rsplit(_sep, 1)[-1]

    def parent_of(text, _win=WINDOWS, _sep=SEP):
        t = text.replace("/", "\\") if _win else text
        return t.rsplit(_sep, 1)[0] if _sep in t else "."

    def as_text(obj, _type=type, _str=str, _bytes=bytes, _enc=sys.getfilesystemencoding(),
                _path_types=PATH_TYPES, _fspath=pathlib.PurePath.__fspath__,
                _pstr=pathlib.PurePath.__str__):
        t = _type(obj)
        if t is _str:
            return obj
        if t is _bytes:
            return obj.decode(_enc, "surrogateescape")
        # exact pathlib objects only, and only while pathlib's own methods are in place
        if t in _path_types and t.__fspath__ is _fspath and t.__str__ is _pstr:
            text = _fspath(obj)
            if _type(text) is _str:
                return text
        raise TypeError("unsupported path object")

    def decide(event, args, _getcwd=os.getcwd, _type=type, _int=int, _str=str, _len=len,
               _any=any, _bool=bool, _block=BLOCK_EXACT, _prefix=BLOCK_PREFIX,
               _listing=LISTING_EVENTS, _roots=read_roots, _ws=ws_forms, _write=write_forms,
               _guarded=guarded, _wflags=WRITE_FLAGS, _norm=norm, _inside=inside, _text=as_text,
               _last=last_part, _parent=parent_of, _getattr=getattr):
        """Return None to allow, or (reason, detail) to refuse."""
        if event in _block or event.startswith(_prefix):
            return (event, "")
        if event == "open":
            target = args[0] if _len(args) > 0 else None
            if target is None or _type(target) is _int:
                return None  # file descriptors such as stdout
            mode = args[1] if _len(args) > 1 else None
            flags = args[2] if _len(args) > 2 else 0
            if mode is None:
                writing = _type(flags) is not _int or _bool(flags & _wflags)
            elif _type(mode) is not _str:
                writing = True
            else:
                writing = _any(c in mode for c in "wax+")
            path = _norm(_text(target), _getcwd())
            if writing:  # only inside the workspace (the runner's output file lies there too)
                if path in _write or _any(_inside(path, w) for w in _ws):
                    return None
                return ("open for writing outside the workspace", _last(path))
            if not _any(_inside(path, r) for r in _roots):
                return ("open outside the workspace", _last(path))
            return None
        if event in _listing:
            target = args[0] if _len(args) > 0 else None
            if _type(target) is _int:
                return None
            text = "." if (target is None or target == "" or target == b"") else _text(target)
            if event.startswith("glob"):
                text = _parent(text)
            path = _norm(text, _getcwd())
            if not _any(_inside(path, r) for r in _roots):
                return ("directory listing outside the workspace", _last(path))
            return None
        if event == "sqlite3.connect":
            db = _text(args[0]) if _len(args) > 0 else ":memory:"
            if db.startswith("file:"):
                db = db[5:].split("?", 1)[0]
            if db == "" or db == ":memory:":
                return None
            dbp = _norm(db, _getcwd())
            if not _any(_inside(dbp, w) for w in _ws):
                return ("sqlite3.connect outside the workspace", _last(dbp))
            return None
        if event == "sys._getframe":
            frame = args[0] if _len(args) > 0 else None
            fname = _getattr(_getattr(frame, "f_code", None), "co_filename", "") or ""
            if fname and _norm(_text(fname), _getcwd()) in _guarded:
                return ("sys._getframe", "")
        return None

    def hook(event, args, _decide=decide, _log=log, _len=len, _perm=PermissionError, _dict=dict):
        try:
            verdict = _decide(event, args)
        except BaseException:
            verdict = ("fence could not check " + event, "")
        if verdict is not None:
            if _len(_log) < 50:
                _log.append(_dict(event=verdict[0], detail=verdict[1]))
            raise _perm("blocked by the migration fence: " + verdict[0]
                        + (" (" + verdict[1] + ")" if verdict[1] else ""))

    sys.addaudithook(hook)
    return log
