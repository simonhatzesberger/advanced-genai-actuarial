# Interface: `reserving_glm.py` (translation of `reserving_glm.R`)

Write one Python module, `reserving_glm.py`, that reproduces the R script's
calculations. The tests call the functions below on the given data **and on
another triangle you will not see**, so the code must compute everything from
its inputs; hardcoded results fail.

## Functions

### `load_policy_data(db_path: str) -> dict`
Keys: `premium_by_year` (`pd.DataFrame` with exactly the columns
`origin_year`, `total_earned_premium`, `total_written_premium`, `n_policies`;
one row per origin year, sorted by `origin_year`), `policies` (the table
`policies`), `claims` (the table `claims_detail`), both as `pd.DataFrame`.

### `prepare_glm_data(triangle: pd.DataFrame) -> pd.DataFrame`
`triangle` is the incremental triangle as returned by
`pd.read_csv(path, index_col=0)` (`NaN` where not observed). Return one row
per observed cell, ordered by origin then development period (R's loops),
with columns `origin` and `dev` (int, 1-based row and column numbers),
`incremental` (float), `origin_f` and `dev_f` (categorical versions of
`origin` and `dev`).

### `fit_odp_glm(data: pd.DataFrame) -> dict`
Over-dispersed Poisson GLM, log link, `incremental ~ origin_f + dev_f`.
Keys: `model` (the fitted model; any object your own `predict_reserves` and
`bootstrap_reserves` can use), `phi` (float: Pearson chi-square divided by the
residual degrees of freedom, i.e. what R's
`summary(glm(..., family = quasipoisson))$dispersion` returns), `deviance`
(float), `df_residual` (int).

### `predict_reserves(fit: dict, n_rows: int, n_cols: int) -> pd.DataFrame`
`fit` is the dict returned by `fit_odp_glm`. One row per future cell, in R's
order (origin `i` = 2 ... n_rows; development `j` = n_cols - i + 2 ... n_cols),
columns `origin`, `dev` (int, 1-based) and `predicted` (float, expected
incremental amount).

### `bootstrap_reserves(glm_data, fit, n_rows, n_cols, n_boot=1000, seed=42) -> np.ndarray`
R's bootstrap algorithm, step by step as in the R script (residuals, their
adjustment, resampling with replacement, the floor on the pseudo data, the
refit, the prediction, and the gamma step for process variance with the phi
of the ORIGINAL fit). Return the total reserve of each successful replicate
(a replicate whose refit fails is dropped, as in R). The same `seed` must give
the same draws, and a different `seed` different draws. Python's and R's
random generators differ: the tests compare the distribution of your draws
with R's (mean and standard deviation), not single draws.

### `run_analysis(triangle_path: str, db_path: str, n_boot: int = 1000, seed: int = 42) -> dict`
The whole script as one function, without printing requirements and
**without writing files** (the R script's final `write.csv` belongs in a
`main()` if you translate it; the tests do not call `main()`). Keys:

| Key | Type | Content |
|---|---|---|
| `phi` | float | dispersion of the fitted GLM |
| `deviance` | float | residual deviance |
| `df_residual` | int | residual degrees of freedom |
| `reserves_by_origin` | `pd.DataFrame` | columns `origin` (int, 2 ... n_rows), `origin_year` (int, the label from the CSV), `reserve` (float) |
| `total_reserve` | float | point estimate, sum of the predictions |
| `boot_results` | `np.ndarray` of float | the draws of `bootstrap_reserves(..., n_boot, seed)` |
| `premium_by_year` | `pd.DataFrame` | as returned by `load_policy_data` |
| `premium_ratios` | `pd.DataFrame` | columns `origin_year`, `reserve`, `total_earned_premium`, `reserve_to_premium` (reserve divided by earned premium) |

**All numbers are unrounded.** R rounds only for display (and rounds the
ratio to 4 decimals and the bootstrap summary to 2); return the unrounded
values.

## Rules

- Allowed imports: `pandas`, `numpy`, `scipy`, `statsmodels`, `sqlite3` and the
  Python standard library, except modules that start processes or use the
  network (`subprocess`, `socket`, `urllib`, `http`, `multiprocessing`,
  `ctypes`, ...).
- Read only the paths passed to your functions. Write no files.
- No hardcoded results: every number must be computed from the inputs.
- The code runs in a sandbox that refuses file access outside its working
  folder, processes and network access (`PermissionError`).
- The test suite reports failures without numbers: the quantity that failed
  and a band for its relative error (bootstrap: a band in Monte Carlo
  standard errors or percent); a failure on the unseen triangle says only
  that it fails there.
