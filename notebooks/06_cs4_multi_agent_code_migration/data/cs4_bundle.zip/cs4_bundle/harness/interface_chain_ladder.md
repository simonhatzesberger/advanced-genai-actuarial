# Interface: `chain_ladder.py` (translation of `chain_ladder.R`)

Write one Python module, `chain_ladder.py`, that reproduces the R script's
calculations exactly. The tests call the functions below on the given
triangle **and on other triangles you will not see**, so the code must compute
everything from its input; hardcoded results fail.

## Functions

### `run_chain_ladder(triangle: pd.DataFrame, tail_factor: float = 1.0) -> dict`

`triangle` is the incremental triangle as returned by
`pd.read_csv(path, index_col=0)`: one row per origin period (the index holds
the origin labels, e.g. 2010), one column per development period (e.g.
`dev_1` ... `dev_10`), `NaN` where not yet observed. Do not modify it.

Return a dict with exactly these keys (more keys are allowed):

| Key | Type | Content |
|---|---|---|
| `cumulative` | `pd.DataFrame` | cumulative triangle, same index and columns as the input, `NaN` where not observed |
| `dev_factors` | `np.ndarray` of float, length n_dev - 1 | volume-weighted age-to-age factors, as in R |
| `n_pairs` | `np.ndarray` of int, length n_dev - 1 | number of origin rows used for each factor |
| `cdf_to_ultimate` | `np.ndarray` of float, length n_dev | cumulative development factor to ultimate for each development period; the last one equals `tail_factor` |
| `results` | `pd.DataFrame`, one row per origin period, in input order | columns `origin_year` (str), `latest_dev_period` (str), `latest_observed`, `cdf_to_ultimate`, `ultimate`, `unpaid_claims_reserve` (float) |
| `total_reserve` | `float` | sum of the unpaid claims reserves |

**All numbers are unrounded.** R rounds only when it prints; do the same.
In particular, chain the unrounded factors (R's printed factor table is
rounded to 6 decimals, but R's calculation is not).

Where the R script calls `stop()`, raise `ValueError` (with R's message).
Where it calls `warning()`, call `warnings.warn(...)`.

### `main(path: str = "triangle.csv") -> dict`

Read the CSV with `pd.read_csv(path, index_col=0)`, print the same four tables
and the final line as the R script (rounded for display, like R), and return
the dict from `run_chain_ladder`. Note how R computes the printed total: it
sums the reserves after rounding them to 2 decimals. The printed line must
read `Total Unpaid Claims Reserve: <number>`.

## Rules

- Allowed imports: `pandas`, `numpy`, `scipy`, `statsmodels`, `sqlite3` and the
  Python standard library, except modules that start processes or use the
  network (`subprocess`, `socket`, `urllib`, `http`, `multiprocessing`,
  `ctypes`, ...).
- Read only the paths passed to your functions. Write no files.
- No hardcoded results: every number must be computed from the input.
- The code runs in a sandbox that refuses file access outside its working
  folder, processes and network access (`PermissionError`).
- The test suite reports failures without numbers: the quantity that failed
  and a band for its relative error; a failure on the unseen triangles says
  only that it fails there.
