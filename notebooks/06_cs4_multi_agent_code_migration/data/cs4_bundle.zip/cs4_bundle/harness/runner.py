"""Runner: executes a translated module on the test inputs and records its outputs.

This is fixed code, not written by an LLM. It is the "run" half of
"run, then grade": it never sees an expected value. The grader (pytest, in a
separate process; see grade.py) compares the JSON written here with R's
ground truth.

    from runner import run_translation
    summary = run_translation("chain_ladder", "path/to/chain_ladder.py",
                              bundle_dir="_local/cs4_bundle", out_json="outputs.json")

What happens:

1. The parent (this function) makes a fresh temporary workspace outside the
   repository, copies in the translated module and the input files the calls
   need (and nothing else), and writes a ``job.json`` listing the calls.
2. It starts a child Python process in that workspace with
   ``os.environ`` minus every variable whose name contains KEY, TOKEN, SECRET
   or PASSWORD (a completely empty environment crashes Python on Windows).
3. The child loads the inputs, installs the audit-hook fence
   (audit_fence.py), registers the module in ``sys.modules`` and executes it,
   then calls the interface on every input, with the module's printing
   captured. It writes outputs only (numbers, shapes, types, exception types
   and messages) to ``outputs.json`` and exits with ``os._exit`` so that no
   code of the translation runs afterwards.
4. The parent copies ``outputs.json`` to ``out_json``, deletes the workspace
   and returns a short summary.

Modes: ``"given"`` runs only on the given data (triangle A; for the
compilation check); ``"all"`` runs every test input (for the test suite).
Timeouts: 120 s (chain ladder) and 300 s (GLM) by default.
"""

from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time

HARNESS_DIR = os.path.dirname(os.path.abspath(__file__))
DEFAULT_TIMEOUT = {"chain_ladder": 120, "reserving_glm": 300}
SECRET_MARKERS = ("KEY", "TOKEN", "SECRET", "PASSWORD")

# Input files per example: bundle-relative source -> name in the workspace.
INPUT_FILES = {
    "chain_ladder": {
        "given": {"legacy/chain_ladder/triangle.csv": "triangle.csv"},
        "all": {"legacy/chain_ladder/triangle.csv": "triangle.csv",
                "inputs/chain_ladder/triangle_B.csv": "triangle_B.csv",
                "inputs/chain_ladder/triangle_gap.csv": "triangle_gap.csv"},
    },
    "reserving_glm": {
        "given": {"legacy/reserving_glm/claims_triangle.csv": "claims_triangle.csv",
                  "legacy/reserving_glm/policies.db": "policies.db"},
        "all": {"legacy/reserving_glm/claims_triangle.csv": "claims_triangle.csv",
                "legacy/reserving_glm/policies.db": "policies.db",
                "inputs/reserving_glm/claims_triangle_B.csv": "claims_triangle_B.csv"},
    },
}

# The calls, in order. "df:<file>" = the runner reads the CSV into a DataFrame
# (pd.read_csv(file, index_col=0)) before the fence is installed; "df2:<file>"
# = the same triangle multiplied by 2 (scaling test).
JOBS = {
    ("chain_ladder", "given"): [
        {"id": "A", "fn": "run_chain_ladder", "args": ["df:triangle.csv"], "kwargs": {}},
        {"id": "main", "fn": "main", "args": ["triangle.csv"], "kwargs": {}},
    ],
    ("chain_ladder", "all"): [
        {"id": "A", "fn": "run_chain_ladder", "args": ["df:triangle.csv"], "kwargs": {}},
        {"id": "A_tail105", "fn": "run_chain_ladder", "args": ["df:triangle.csv"],
         "kwargs": {"tail_factor": 1.05}},
        {"id": "B", "fn": "run_chain_ladder", "args": ["df:triangle_B.csv"], "kwargs": {}},
        {"id": "A_x2", "fn": "run_chain_ladder", "args": ["df2:triangle.csv"], "kwargs": {}},
        {"id": "gap", "fn": "run_chain_ladder", "args": ["df:triangle_gap.csv"], "kwargs": {}},
        {"id": "main", "fn": "main", "args": ["triangle.csv"], "kwargs": {}},
    ],
    ("reserving_glm", "given"): [
        {"id": "A", "fn": "run_analysis", "args": ["claims_triangle.csv", "policies.db"],
         "kwargs": {"n_boot": 100, "seed": 42}},
    ],
    ("reserving_glm", "all"): [
        {"id": "A", "fn": "run_analysis", "args": ["claims_triangle.csv", "policies.db"],
         "kwargs": {"n_boot": 1000, "seed": 42}},
        {"id": "B", "fn": "run_analysis", "args": ["claims_triangle_B.csv", "policies.db"],
         "kwargs": {"n_boot": 1000, "seed": 42}},
        {"id": "policy_data", "fn": "load_policy_data", "args": ["policies.db"], "kwargs": {}},
        {"id": "steps_A", "fn": "@steps", "args": ["df:claims_triangle.csv"], "kwargs": {}},
        {"id": "steps_A_x2", "fn": "@steps", "args": ["df2:claims_triangle.csv"], "kwargs": {}},
        {"id": "seed42_a", "fn": "@boot", "args": ["df:claims_triangle.csv"],
         "kwargs": {"n_boot": 200, "seed": 42}},
        {"id": "seed42_b", "fn": "@boot", "args": ["df:claims_triangle.csv"],
         "kwargs": {"n_boot": 200, "seed": 42}},
        {"id": "seed43", "fn": "@boot", "args": ["df:claims_triangle.csv"],
         "kwargs": {"n_boot": 200, "seed": 43}},
    ],
}


# ---------------------------------------------------------------------------
# Parent side
# ---------------------------------------------------------------------------
def scrubbed_env() -> dict:
    """os.environ minus secrets, plus settings for a quiet, cache-free child."""
    env = {k: v for k, v in os.environ.items()
           if not any(m in k.upper() for m in SECRET_MARKERS)}
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    env["PYTHONIOENCODING"] = "utf-8"
    env["PYTHONHASHSEED"] = "0"
    return env


def rewrite_paths(text: str, workdir: str | None = None) -> str:
    """Remove absolute paths (workspace, Python installation, home) from text."""
    if not text:
        return text
    reps = []
    if workdir:
        reps += [(workdir, "<workspace>"), (os.path.realpath(workdir), "<workspace>")]
    for p in {sys.prefix, sys.base_prefix, sys.exec_prefix}:
        reps.append((p, "<python>"))
    reps.append((os.path.expanduser("~"), "<home>"))
    for old, new in sorted(reps, key=lambda t: -len(t[0])):
        for variant in {old, old.replace("\\", "/"), old.replace("/", "\\")}:
            text = re.sub(re.escape(variant), new.replace("\\", r"\\"), text, flags=re.IGNORECASE)
    # any remaining absolute path: keep only its last component
    text = re.sub(r"[A-Za-z]:[\\/][^\s\"'<>|]*[\\/]([^\s\"'<>|\\/]+)", r"<path>/\1", text)
    text = re.sub(r"(?<![\w.<>])/(?:[^\s\"'<>/]+/)+([^\s\"'<>/]+)", r"<path>/\1", text)
    return text


def run_translation(example: str, module_path: str, bundle_dir: str, out_json: str,
                    mode: str = "all", timeout: float | None = None,
                    keep_workspace: bool = False) -> dict:
    """Run a translated module on the test inputs in a fenced child process."""
    if (example, mode) not in JOBS:
        raise ValueError(f"unknown example/mode: {example}/{mode}")
    timeout = timeout or DEFAULT_TIMEOUT[example]
    module_path, bundle_dir = os.path.abspath(module_path), os.path.abspath(bundle_dir)
    work = os.path.realpath(tempfile.mkdtemp(prefix="cs4run_"))
    t0 = time.perf_counter()
    try:
        os.makedirs(os.path.join(work, "translated"))
        shutil.copyfile(module_path, os.path.join(work, "translated", f"{example}.py"))
        for src, dst in INPUT_FILES[example][mode].items():
            shutil.copyfile(os.path.join(bundle_dir, *src.split("/")), os.path.join(work, dst))
        job = {"example": example, "mode": mode, "module": f"translated/{example}.py",
               "calls": JOBS[(example, mode)]}
        with open(os.path.join(work, "job.json"), "w", encoding="utf-8") as f:
            json.dump(job, f)
        cmd = [sys.executable, "-X", "utf8", os.path.join(HARNESS_DIR, "runner.py"), "--child", work]
        status, stderr_tail = "ok", ""
        try:
            proc = subprocess.run(cmd, cwd=work, env=scrubbed_env(), stdin=subprocess.DEVNULL,
                                  stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=timeout)
            if proc.returncode != 0:
                status = "child_failed"
                stderr_tail = rewrite_paths(proc.stderr.decode("utf-8", "replace")[-2000:], work)
        except subprocess.TimeoutExpired:
            status = "timeout"
        seconds = time.perf_counter() - t0
        out_path = os.path.join(work, "outputs.json")
        if os.path.exists(out_path):
            with open(out_path, encoding="utf-8") as f:
                outputs = json.load(f)
        else:
            outputs = {"example": example, "mode": mode, "import": {"ok": False,
                       "error_type": status, "message": "the child process wrote no outputs"},
                       "calls": {}}
            if status == "ok":
                status = "no_outputs"
        outputs["runner"] = {"status": status, "seconds": round(seconds, 3), "timeout": timeout,
                             "stderr_tail": stderr_tail}
        os.makedirs(os.path.dirname(os.path.abspath(out_json)), exist_ok=True)
        with open(out_json, "w", encoding="utf-8", newline="\n") as f:
            json.dump(outputs, f, indent=1)
        calls = outputs.get("calls", {})
        return {"status": status, "seconds": round(seconds, 3),
                "import_ok": bool(outputs.get("import", {}).get("ok")),
                "calls_ok": sum(1 for c in calls.values() if c.get("ok")),
                "calls_total": len(JOBS[(example, mode)]),
                "fence_blocked": outputs.get("fence_blocked", []),
                "out_json": out_json}
    finally:
        if not keep_workspace:
            shutil.rmtree(work, ignore_errors=True)


# ---------------------------------------------------------------------------
# Child side
# ---------------------------------------------------------------------------
def _child(work: str) -> None:
    # Import everything the harness and honest translations need BEFORE the fence.
    import contextlib
    import importlib.util
    import io
    import math
    import traceback
    import warnings

    import numpy as np
    import pandas as pd
    import scipy  # noqa: F401  (allowed import; loaded now so its files need no access later)
    import scipy.stats  # noqa: F401
    import sqlite3  # noqa: F401
    import statsmodels.api  # noqa: F401
    import statsmodels.formula.api  # noqa: F401

    import audit_fence

    _dumps, _open = json.dumps, open  # captured before the translation can touch them
    out_path = os.path.join(work, "outputs.json")
    with _open(os.path.join(work, "job.json"), encoding="utf-8") as f:
        job = json.load(f)
    module_file = os.path.join(work, *job["module"].split("/"))
    example = job["example"]

    # Inputs are read before the fence is installed.
    frames: dict[str, pd.DataFrame] = {}
    for call in job["calls"]:
        for a in call["args"]:
            if isinstance(a, str) and a.startswith(("df:", "df2:")):
                name = a.split(":", 1)[1]
                if name not in frames:
                    frames[name] = pd.read_csv(os.path.join(work, name), index_col=0)

    def materialise(arg):
        if isinstance(arg, str) and arg.startswith("df:"):
            return frames[arg[3:]].copy()
        if isinstance(arg, str) and arg.startswith("df2:"):
            return frames[arg[4:]].copy() * 2
        return arg

    this_file = os.path.abspath(__file__)

    def short_tb(exc: BaseException) -> str:
        # skip the runner's own frames: the agents only need the translation's part
        tb = exc.__traceback__
        while tb is not None and os.path.abspath(tb.tb_frame.f_code.co_filename) == this_file:
            tb = tb.tb_next
        lines = traceback.format_exception(type(exc), exc, tb)
        text = "".join(lines)
        return rewrite_paths(text, work)[-3000:]

    def exc_info(exc: BaseException) -> dict:
        return {"ok": False, "error_type": type(exc).__name__,
                "is_value_error": isinstance(exc, ValueError),
                "message": rewrite_paths(str(exc), work)[:500], "traceback": short_tb(exc)}

    # ---- converters: outputs only, JSON-safe --------------------------------
    def num_list(x):
        arr = np.asarray(x, dtype=float).ravel()
        return [None if not math.isfinite(v) else float(v) for v in arr]

    def num(x):
        try:
            v = float(x)
        except Exception:
            return None
        return v if math.isfinite(v) else None

    def describe(obj) -> dict:
        d = {"type": type(obj).__name__}
        if isinstance(obj, np.ndarray):
            d.update(dtype_kind=obj.dtype.kind, shape=list(obj.shape))
        elif isinstance(obj, pd.DataFrame):
            d.update(shape=list(obj.shape), columns=[str(c) for c in obj.columns])
        elif isinstance(obj, (list, tuple, pd.Series)):
            d.update(shape=[len(obj)])
        return d

    def frame_to_json(df) -> dict:
        out = {"columns": [str(c) for c in df.columns], "n_rows": int(len(df)),
               "index": [str(i) for i in df.index], "data": {}}
        for c in df.columns:
            s = df[c]
            if pd.api.types.is_numeric_dtype(s) and not pd.api.types.is_bool_dtype(s):
                out["data"][str(c)] = num_list(s.to_numpy(dtype=float))
                out.setdefault("dtype_kind", {})[str(c)] = s.dtype.kind
            else:
                out["data"][str(c)] = [str(v) for v in s.tolist()]
                out.setdefault("dtype_kind", {})[str(c)] = "O"
        return out

    def convert_value(v):
        """Numbers and arrays become lists; DataFrames become column dicts."""
        if isinstance(v, pd.DataFrame):
            return {"kind": "frame", **describe(v), "frame": frame_to_json(v)}
        if isinstance(v, (np.ndarray, list, tuple, pd.Series)):
            try:
                arr = np.asarray(v)
                return {"kind": "array", **describe(v), "values": num_list(arr),
                        "shape": list(arr.shape), "dtype_kind": arr.dtype.kind}
            except Exception:
                return {"kind": "unconvertible", **describe(v)}
        if isinstance(v, (bool, np.bool_)):
            return {"kind": "bool", "value": bool(v)}
        if isinstance(v, (int, float, np.integer, np.floating)):
            return {"kind": "number", "type": type(v).__name__, "value": num(v),
                    "is_integer_type": isinstance(v, (int, np.integer))}
        return {"kind": "other", **describe(v)}

    def convert_dict(res, keys) -> dict:
        if not isinstance(res, dict):
            return {"returned_type": type(res).__name__}
        out = {"returned_type": "dict", "keys": [str(k) for k in res.keys()], "values": {}}
        for k in keys:
            if k in res:
                try:
                    out["values"][k] = convert_value(res[k])
                except Exception as exc:  # noqa: BLE001
                    out["values"][k] = {"kind": "unconvertible", "error_type": type(exc).__name__}
        return out

    CL_KEYS = ["cumulative", "dev_factors", "n_pairs", "cdf_to_ultimate", "results", "total_reserve"]
    GLM_KEYS = ["phi", "deviance", "df_residual", "reserves_by_origin", "total_reserve",
                "boot_results", "premium_by_year", "premium_ratios"]

    # ---- install the fence, then import the translation ----------------------
    blocked = audit_fence.install(workspace=work, write_path=out_path,
                                  guarded_files=[module_file, os.path.abspath(__file__),
                                                 audit_fence.__file__])
    # drop harness folders from the import path; the workspace comes first
    sys.path[:] = [work] + [p for p in sys.path if p and os.path.realpath(p) != HARNESS_DIR]

    record: dict = {"example": example, "mode": job["mode"], "import": {}, "calls": {}}
    t_import = time.perf_counter()
    stdout_buf = io.StringIO()
    mod = None
    try:
        with contextlib.redirect_stdout(stdout_buf), warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            spec = importlib.util.spec_from_file_location(example, module_file)
            mod = importlib.util.module_from_spec(spec)
            sys.modules[example] = mod  # register first (dataclasses and friends need it)
            spec.loader.exec_module(mod)
        record["import"] = {"ok": True, "seconds": round(time.perf_counter() - t_import, 3),
                            "stdout_chars": len(stdout_buf.getvalue()),
                            "warnings": [f"{x.category.__name__}: {str(x.message)[:200]}" for x in w[:5]],
                            "callables": sorted(n for n in dir(mod) if callable(getattr(mod, n, None))
                                                and not n.startswith("_"))}
    except BaseException as exc:  # noqa: BLE001  (SystemExit included)
        record["import"] = exc_info(exc)
        mod = None

    # ---- the calls ------------------------------------------------------------
    glm_cache: dict = {}
    if mod is not None:
        for call in job["calls"]:
            cid, fn_name = call["id"], call["fn"]
            args = [materialise(a) for a in call["args"]]
            kwargs = dict(call["kwargs"])
            buf = io.StringIO()
            t_call = time.perf_counter()
            entry: dict = {}
            try:
                with contextlib.redirect_stdout(buf), warnings.catch_warnings(record=True) as w:
                    warnings.simplefilter("always")
                    if fn_name == "@steps":
                        # prepare -> fit -> predict on one triangle (GLM deterministic parts)
                        tri = args[0]
                        gd = mod.prepare_glm_data(tri)
                        fit = mod.fit_odp_glm(gd)
                        pred = mod.predict_reserves(fit, tri.shape[0], tri.shape[1])
                        glm_cache[call["args"][0]] = (gd, fit)
                        entry = {"glm_data": convert_value(gd),
                                 "fit": convert_dict(fit, ["phi", "deviance", "df_residual"]),
                                 "predictions": convert_value(pred)}
                    elif fn_name == "@boot":
                        key = call["args"][0]
                        if key not in glm_cache:
                            tri = args[0]
                            gd = mod.prepare_glm_data(tri)
                            glm_cache[key] = (gd, mod.fit_odp_glm(gd))
                        gd, fit = glm_cache[key]
                        tri = args[0]
                        draws = mod.bootstrap_reserves(gd, fit, tri.shape[0], tri.shape[1], **kwargs)
                        entry = {"draws": convert_value(draws)}
                    else:
                        fn = getattr(mod, fn_name)
                        res = fn(*args, **kwargs)
                        if fn_name in ("run_chain_ladder", "main"):
                            entry = convert_dict(res, CL_KEYS)
                        elif fn_name == "run_analysis":
                            entry = convert_dict(res, GLM_KEYS)
                        elif fn_name == "load_policy_data":
                            entry = convert_dict(res, ["premium_by_year", "policies", "claims"])
                            for k in ("policies", "claims"):  # sizes only for the big tables
                                v = entry.get("values", {}).get(k)
                                if isinstance(v, dict) and v.get("kind") == "frame":
                                    v.pop("frame", None)
                entry["ok"] = True
                entry["warnings"] = [f"{x.category.__name__}: {str(x.message)[:200]}" for x in w[:5]]
            except BaseException as exc:  # noqa: BLE001
                entry = exc_info(exc)
            entry["seconds"] = round(time.perf_counter() - t_call, 3)
            printed = buf.getvalue()
            entry["stdout_chars"] = len(printed)
            if fn_name == "main":
                # the printed total is an output of the translation; keep the tail only
                entry["stdout_tail"] = rewrite_paths(printed[-3000:], work)
            record["calls"][cid] = entry

    record["fence_blocked"] = list(blocked)
    payload = _dumps(record, allow_nan=False, indent=1)
    with _open(out_path, "w", encoding="utf-8", newline="\n") as f:
        f.write(payload)
    sys.stdout.flush()
    sys.stderr.flush()
    os._exit(0)  # no atexit handlers or finalisers of the translation run after this


if __name__ == "__main__":
    if len(sys.argv) == 3 and sys.argv[1] == "--child":
        _child(os.path.realpath(sys.argv[2]))
    else:
        print("usage: python runner.py --child <workspace>  (normally called via run_translation)")
        sys.exit(2)
