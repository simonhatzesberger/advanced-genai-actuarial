"""Runner for exercise (b): call a translated mtpl_premium.py on every test input
and record the OUTPUTS ONLY as JSON (no ground truth is read here).

    python runner_vba.py --module <dir>/mtpl_premium.py --cases <dir>/vba_cases.json --out <dir>/outputs.json

Run it in a child process whose working directory is a fresh temporary folder
(run_suite.py does this). The grader (tests/) reads the JSON afterwards and never
imports the translation. This standalone runner has no audit-hook fence; in the
notebook the harness runner (harness/runner.py with audit_fence.py) should call
the same interface and write the same JSON layout.

Output layout:
  import_error  null, or the exception type if the module could not be loaded
  interface     has_mtpl_premium, has_premium_table, mtpl_premium_parameters
  scalar        {case_id: {status: "value"|"error", value, value_type, error_type}}
  table         {status, error_type, is_series, index_matches, dtype, values: {case_id: float|null}}
"""
from __future__ import annotations

import argparse
import importlib.util
import inspect
import json
import math
import sys
from pathlib import Path

import pandas as pd

MODULE_NAME = "mtpl_premium"


def load_module(path: Path):
    spec = importlib.util.spec_from_file_location(MODULE_NAME, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[MODULE_NAME] = module          # registered before exec (dataclasses etc. need it)
    spec.loader.exec_module(module)
    return module


def as_number(value):
    """A JSON-safe float, or None for NaN/None/non-numbers."""
    try:
        x = float(value)
    except (TypeError, ValueError):
        return None
    return None if math.isnan(x) or math.isinf(x) else x


def call_scalar(fn, case: dict) -> dict:
    try:
        value = fn(case["DrivAge"], case["VehPower"], case["BonusMalus"], case["Area"], case["Exposure"])
    except Exception as exc:                      # the translation's own error, recorded by type
        return {"status": "error", "value": None, "value_type": None, "error_type": type(exc).__name__}
    return {"status": "value", "value": as_number(value), "value_type": type(value).__name__, "error_type": None}


def input_table(cases: list[dict]) -> pd.DataFrame:
    """The inputs as a DataFrame with freMTPL2 column names; empty age = NaN."""
    df = pd.DataFrame({
        "DrivAge": [math.nan if c["DrivAge"] is None else float(c["DrivAge"]) for c in cases],
        "VehPower": pd.array([c["VehPower"] for c in cases], dtype="int64"),
        "BonusMalus": pd.array([c["BonusMalus"] for c in cases], dtype="int64"),
        "Area": pd.array([c["Area"] for c in cases], dtype=object),
        "Exposure": [float(c["Exposure"]) for c in cases],
    }, index=pd.Index([c["case_id"] for c in cases], name="case_id"))
    return df


def call_table(fn, cases: list[dict]) -> dict:
    df = input_table(cases)
    try:
        result = fn(df.copy())
    except Exception as exc:
        return {"status": "error", "error_type": type(exc).__name__}
    is_series = isinstance(result, pd.Series)
    out = {"status": "value", "error_type": None, "is_series": is_series,
           "index_matches": bool(is_series and result.index.equals(df.index)),
           "dtype": str(result.dtype) if is_series else type(result).__name__, "values": {}}
    if out["index_matches"]:
        out["values"] = {cid: as_number(v) for cid, v in result.items()}
    return out


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--module", required=True, type=Path)
    ap.add_argument("--cases", required=True, type=Path)
    ap.add_argument("--out", required=True, type=Path)
    args = ap.parse_args()
    cases = json.loads(args.cases.read_text(encoding="utf-8"))

    record: dict = {"import_error": None, "interface": {}, "scalar": {}, "table": {}}
    try:
        module = load_module(args.module)
    except Exception as exc:
        record["import_error"] = type(exc).__name__
    else:
        mp = getattr(module, "mtpl_premium", None)
        pt = getattr(module, "premium_table", None)
        params = None
        if callable(mp):
            try:
                params = list(inspect.signature(mp).parameters)
            except (TypeError, ValueError):
                params = None
        record["interface"] = {"has_mtpl_premium": callable(mp), "has_premium_table": callable(pt),
                               "mtpl_premium_parameters": params}
        if callable(mp):
            record["scalar"] = {c["case_id"]: call_scalar(mp, c) for c in cases}
        if callable(pt):
            record["table"] = call_table(pt, cases)
    args.out.write_text(json.dumps(record, indent=1, allow_nan=False) + "\n", encoding="utf-8", newline="\n")


if __name__ == "__main__":
    main()
