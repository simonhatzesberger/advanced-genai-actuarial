"""Reference translation of the VBA function MTPL_Premium (legacy/MTPL_Premium.bas).

The translation follows the VBA line by line: each block quotes the VBA line it
replaces. It keeps the legacy behaviour, including the parts an actuary would
query (flag them, do not silently "fix" them in a migration):

* An empty DrivAge cell compares as 0 in VBA, so it gets the young-driver
  factor 1.75. Here an empty cell arrives as None (scalar call) or NaN (table).
* "Case 25 To 29" and "Case 30 To 69" leave gaps for fractional ages: 29.5 falls
  through to "Case Else" (factor 1.125).
* The minimum annual premium applies before pro-rating by exposure.
* VBA's Trim removes spaces only (not tabs or non-breaking spaces); UCase
  upper-cases the area code.
* Err.Raise becomes ValueError, in the same order (area first, then BonusMalus).
* Application.WorksheetFunction.Round is Excel's ROUND: halves go away from zero,
  and Excel looks at the number to 15 significant digits first. Python's round()
  and numpy's round() send halves to the even neighbour, so they differ.

Interface (given to the translator in the exercise):
    mtpl_premium(driv_age, veh_power, bonus_malus, area, exposure) -> float
    premium_table(df) -> pd.Series
"""
from __future__ import annotations

import math
from decimal import ROUND_HALF_UP, Decimal

import pandas as pd

BASE_RATE = 180.0      # Const BASE_RATE As Double = 180
MIN_ANNUAL = 90.25     # Const MIN_ANNUAL As Double = 90.25


def excel_round(x: float, digits: int) -> float:
    """Excel's ROUND(x, digits), as called by Application.WorksheetFunction.Round.

    Two steps:
    1. Take x to 15 significant digits, the precision Excel works to. A product
       such as 90.25 * 0.3 is 27.074999999999999... in binary; to 15 digits it
       is 27.075, as the decimal intent says.
    2. Round half away from zero: ROUND_HALF_UP in Python's decimal module
       sends 27.075 to 27.08 and -27.075 to -27.08.
    Measured on 72 probe values in Excel 16.0 build 17932: this rule agreed with
    Excel's ROUND on all 72; Decimal(repr(x)) on 62, Decimal(x) on 51 and
    Python's round() on 45 (excel_check/excel_formula_results.json).
    """
    fifteen_digits = Decimal(format(x, ".15g"))
    step = Decimal(1).scaleb(-digits)                 # 0.01 for digits = 2
    return float(fifteen_digits.quantize(step, rounding=ROUND_HALF_UP))


def _vba_trim(text: str) -> str:
    """VBA Trim: remove leading and trailing spaces (character 32) only."""
    return text.strip(" ")


def _is_empty(value) -> bool:
    """An empty worksheet cell: None in a scalar call, NaN in a DataFrame column."""
    if value is None:
        return True
    try:
        return math.isnan(value)
    except TypeError:            # a text value is not empty
        return False


def mtpl_premium(driv_age, veh_power, bonus_malus, area, exposure) -> float:
    """Premium for one policy, as the VBA function MTPL_Premium returns it."""
    # Public Function MTPL_Premium(DrivAge As Variant, VehPower As Integer, _
    #     BonusMalus As Integer, Area As String, Exposure As Double) As Double
    # DrivAge is a Variant: an empty cell stays Empty, and Empty compares as 0.
    age = 0.0 if _is_empty(driv_age) else float(driv_age)
    # Area As String: an empty cell becomes the empty string "".
    area_text = "" if _is_empty(area) else str(area)

    # Select Case DrivAge
    if age < 25:                        # Case Is < 25: fAge = 1.75
        f_age = 1.75
    elif 25 <= age <= 29:               # Case 25 To 29: fAge = 1.25
        f_age = 1.25
    elif 30 <= age <= 69:               # Case 30 To 69: fAge = 1
        f_age = 1.0
    else:                               # Case Else: fAge = 1.125 (also 29 < age < 30)
        f_age = 1.125

    if veh_power <= 5:                  # If VehPower <= 5 Then fPow = 0.875
        f_pow = 0.875
    elif veh_power <= 9:                # ElseIf VehPower <= 9 Then fPow = 1
        f_pow = 1.0
    else:                               # Else fPow = 1.25
        f_pow = 1.25

    code = _vba_trim(area_text).upper()     # Select Case UCase(Trim(Area))
    if code in ("A", "B"):                  # Case "A", "B": fArea = 0.875
        f_area = 0.875
    elif code in ("C", "D"):                # Case "C", "D": fArea = 1
        f_area = 1.0
    elif code in ("E", "F"):                # Case "E", "F": fArea = 1.25
        f_area = 1.25
    else:                                   # Case Else: Err.Raise 5, , "Unknown area: " & Area
        raise ValueError("Unknown area: " + area_text)

    # If BonusMalus < 50 Or BonusMalus > 350 Then Err.Raise 5, , "BonusMalus out of range"
    if bonus_malus < 50 or bonus_malus > 350:
        raise ValueError("BonusMalus out of range")

    # annual = BASE_RATE * fAge * fPow * fArea * BonusMalus / 100
    # (same order of operations as the VBA, so the same binary result)
    annual = BASE_RATE * f_age * f_pow * f_area * bonus_malus / 100
    # If annual < MIN_ANNUAL Then annual = MIN_ANNUAL   (before pro-rating)
    if annual < MIN_ANNUAL:
        annual = MIN_ANNUAL
    # MTPL_Premium = Application.WorksheetFunction.Round(annual * Exposure, 2)
    return excel_round(annual * float(exposure), 2)


def premium_table(df: pd.DataFrame) -> pd.Series:
    """mtpl_premium for every row of df (columns DrivAge, VehPower, BonusMalus,
    Area, Exposure). Returns a float Series with df's index, named "premium";
    a row for which mtpl_premium raises ValueError gets NaN."""
    premiums = []
    for row in df[["DrivAge", "VehPower", "BonusMalus", "Area", "Exposure"]].itertuples(index=False):
        try:
            premiums.append(mtpl_premium(row.DrivAge, row.VehPower, row.BonusMalus, row.Area, row.Exposure))
        except ValueError:
            premiums.append(math.nan)
    return pd.Series(premiums, index=df.index, name="premium", dtype="float64")
