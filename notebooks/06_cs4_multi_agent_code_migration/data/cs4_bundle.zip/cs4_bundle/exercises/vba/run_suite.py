"""Grade one translation of the VBA tariff: run, then grade, in two child processes.

    python run_suite.py <path/to/mtpl_premium.py> [--json <summary.json>] [--keep]

1. Copies the translation and the test inputs into a fresh temporary folder
   outside the repository.
2. Runs runner_vba.py there in a child process (environment without variables
   whose names contain KEY, TOKEN, SECRET or PASSWORD; timeout 60 s).
3. Runs pytest on tests/test_vba_premium.py in a second child process
   (-p no:cacheprovider, PYTHONDONTWRITEBYTECODE=1, PYTEST_DISABLE_PLUGIN_AUTOLOAD=1).
   The tests read only the runner's JSON and the ground truth.
4. Accepts the result only if pytest's exit code, the expected set of test ids
   and conftest's results JSON agree (DESIGN.md section 3.3, routing rule).
Prints one line per category and the value-free messages of failed tests.
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
import tempfile
from collections import Counter
from pathlib import Path

EXERCISE = Path(__file__).resolve().parent
TEST_FILE = EXERCISE / "tests" / "test_vba_premium.py"
CASES = EXERCISE / "inputs" / "vba_cases.json"
EDGE_IDS = [f"E{i:02d}" for i in range(1, 19)]
EXPECTED_IDS = ({"test_interface_functions_exist", "test_interface_parameter_names", "test_interface_returns_float",
                 "test_portfolio_premiums", "test_table_returns_aligned_series", "test_table_premiums",
                 "test_table_agrees_with_scalar"} | {f"test_edge_case[{e}]" for e in EDGE_IDS})


def scrubbed_env() -> dict:
    """os.environ without secrets. (A fully empty environment crashes Python on Windows.)"""
    return {k: v for k, v in os.environ.items()
            if not any(word in k.upper() for word in ("KEY", "TOKEN", "SECRET", "PASSWORD"))}


def grade(translation: Path, keep: bool = False) -> dict:
    work = Path(tempfile.mkdtemp(prefix="cs4_vba_"))
    try:
        shutil.copyfile(translation, work / "mtpl_premium.py")
        shutil.copyfile(CASES, work / "vba_cases.json")
        env = scrubbed_env()
        env["PYTHONDONTWRITEBYTECODE"] = "1"
        run = subprocess.run([sys.executable, str(EXERCISE / "runner_vba.py"), "--module", "mtpl_premium.py",
                              "--cases", "vba_cases.json", "--out", "outputs.json"],
                             cwd=work, env=env, capture_output=True, text=True, timeout=60)
        if run.returncode != 0 or not (work / "outputs.json").exists():
            return {"status": "runner_failed", "returncode": run.returncode}

        env_t = dict(env, PYTEST_DISABLE_PLUGIN_AUTOLOAD="1",
                     CS4_VBA_OUTPUTS=str(work / "outputs.json"), CS4_RESULTS_JSON=str(work / "results.json"))
        test = subprocess.run([sys.executable, "-m", "pytest", "-q", "-p", "no:cacheprovider", str(TEST_FILE)],
                              cwd=work, env=env_t, capture_output=True, text=True, timeout=120)
        results = json.loads((work / "results.json").read_text(encoding="utf-8"))
        ids = {r["id"] for r in results["results"]}
        n_failed = sum(r["outcome"] != "passed" for r in results["results"])
        consistent = (ids == EXPECTED_IDS and len(results["results"]) == len(EXPECTED_IDS)
                      and ((test.returncode == 0) == (n_failed == 0)))
        by_cat = Counter()
        passed_cat = Counter()
        for r in results["results"]:
            by_cat[r["category"]] += 1
            passed_cat[r["category"]] += r["outcome"] == "passed"
        return {"status": "passed" if consistent and n_failed == 0 else ("failed" if consistent else "inconsistent"),
                "pytest_exit_code": test.returncode, "n_tests": len(results["results"]),
                "n_passed": len(results["results"]) - n_failed,
                "by_category": {c: f"{passed_cat[c]}/{by_cat[c]}" for c in sorted(by_cat)},
                "ground_truth_source": results["ground_truth_source"],
                "failures": [f"{r['id']}: {r['message']}" for r in results["results"] if r["outcome"] != "passed"]}
    finally:
        if keep:
            print("kept", work)
        else:
            shutil.rmtree(work, ignore_errors=True)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("translation", type=Path)
    ap.add_argument("--json", type=Path, help="also write the summary to this file")
    ap.add_argument("--keep", action="store_true", help="keep the temporary folder")
    args = ap.parse_args()
    summary = grade(args.translation.resolve(), keep=args.keep)
    print(f"{args.translation.name}: {summary['status']}"
          + (f", {summary['n_passed']}/{summary['n_tests']} tests" if "n_tests" in summary else "")
          + (f" (ground truth: {summary['ground_truth_source']})" if "ground_truth_source" in summary else ""))
    for cat, score in summary.get("by_category", {}).items():
        print(f"  {cat:<10} {score}")
    for line in summary.get("failures", []):
        print("  FAIL", line)
    if args.json:
        args.json.write_text(json.dumps(summary, indent=1) + "\n", encoding="utf-8", newline="\n")


if __name__ == "__main__":
    main()
