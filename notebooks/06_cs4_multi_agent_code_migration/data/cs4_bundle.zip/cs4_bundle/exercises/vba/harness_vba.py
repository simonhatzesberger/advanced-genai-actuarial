"""Exercise (b): the adapter between the VBA exercise and the Part A harness.

It lets the migration graph of Part A run, fence and grade a translation of the
VBA function MTPL_Premium exactly as it does for the R examples:

    from harness_vba import run_vba_translation, grade_vba
    summary = run_vba_translation("path/to/mtpl_premium.py", "outputs.json", mode="all")
    verdict = grade_vba("outputs.json")      # same shape as grade._verdict()

What it adds to runner_vba.py (which it reuses for the calls and the JSON layout):

* the translation runs in a child process in a fresh temporary folder, with
  ``os.environ`` minus every variable whose name contains KEY, TOKEN, SECRET or
  PASSWORD (harness/runner.py's ``scrubbed_env``);
* the child installs the harness's PEP 578 audit-hook fence
  (harness/audit_fence.py) BEFORE it imports the translation: reads only in the
  temporary folder and the Python installation, writes only there, no
  processes, no network, no ctypes, no registry;
* mode ``"given"`` (the compilation check) calls the functions on three smoke
  inputs defined below, which are not test cases; mode ``"all"`` calls them on
  the 218 test inputs (inputs/vba_cases.json);
* the grader is the harness's own (grade._pytest: separate process,
  ``-p no:cacheprovider``, plugin autoload off, empty ini file) on
  tests/test_vba_premium.py, with the routing rule of DESIGN.md 3.3: exit code,
  expected test ids and the results JSON must agree.

This is a teaching fence, not a production sandbox (see harness/audit_fence.py).
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import tempfile
import time

EXERCISE_DIR = os.path.dirname(os.path.abspath(__file__))
BUNDLE_DIR = os.path.dirname(os.path.dirname(EXERCISE_DIR))
HARNESS_DIR = os.path.join(BUNDLE_DIR, "harness")
TESTS_DIR = os.path.join(EXERCISE_DIR, "tests")
TEST_FILE = os.path.join(TESTS_DIR, "test_vba_premium.py")
CASES_FILE = os.path.join(EXERCISE_DIR, "inputs", "vba_cases.json")
MODULE_NAME = "mtpl_premium"
DEFAULT_TIMEOUT = 60

# Smoke inputs for the compilation check: they only show that the code runs.
# They are not test cases and carry no legacy results.
SMOKE_CASES = [
    {"case_id": "S1", "DrivAge": 45, "VehPower": 7, "BonusMalus": 100, "Area": "C", "Exposure": 1.0},
    {"case_id": "S2", "DrivAge": None, "VehPower": 4, "BonusMalus": 60, "Area": "a", "Exposure": 0.5},
    {"case_id": "S3", "DrivAge": 30, "VehPower": 6, "BonusMalus": 100, "Area": "X", "Exposure": 1.0},
]

EDGE_IDS = [f"E{i:02d}" for i in range(1, 19)]
EXPECTED_IDS = sorted(["test_interface_functions_exist", "test_interface_parameter_names",
                       "test_interface_returns_float", "test_portfolio_premiums",
                       "test_table_returns_aligned_series", "test_table_premiums",
                       "test_table_agrees_with_scalar"] + [f"test_edge_case[{e}]" for e in EDGE_IDS])


def _harness():
    if HARNESS_DIR not in sys.path:
        sys.path.insert(0, HARNESS_DIR)
    import grade   # noqa: E402
    import runner  # noqa: E402
    return runner, grade


# ---------------------------------------------------------------------------
# Parent side
# ---------------------------------------------------------------------------
def run_vba_translation(module_path: str, out_json: str, mode: str = "all",
                        timeout: float = DEFAULT_TIMEOUT, keep_workspace: bool = False) -> dict:
    """Run a translated mtpl_premium.py on the smoke inputs ("given") or the test inputs ("all")."""
    if mode not in ("given", "all"):
        raise ValueError(f"unknown mode: {mode}")
    runner, _ = _harness()
    module_path = os.path.abspath(module_path)
    work = os.path.realpath(tempfile.mkdtemp(prefix="cs4vba_"))
    t0 = time.perf_counter()
    try:
        os.makedirs(os.path.join(work, "translated"))
        shutil.copyfile(module_path, os.path.join(work, "translated", f"{MODULE_NAME}.py"))
        if mode == "all":
            shutil.copyfile(CASES_FILE, os.path.join(work, "cases.json"))
        else:
            with open(os.path.join(work, "cases.json"), "w", encoding="utf-8", newline="\n") as f:
                json.dump(SMOKE_CASES, f, indent=1)
        with open(os.path.join(work, "job.json"), "w", encoding="utf-8", newline="\n") as f:
            json.dump({"mode": mode, "module": f"translated/{MODULE_NAME}.py", "cases": "cases.json"}, f)
        cmd = [sys.executable, "-X", "utf8", os.path.abspath(__file__), "--child", work]
        status, stderr_tail = "ok", ""
        try:
            proc = subprocess.run(cmd, cwd=work, env=runner.scrubbed_env(), stdin=subprocess.DEVNULL,
                                  stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=timeout)
            if proc.returncode != 0:
                status = "child_failed"
                stderr_tail = runner.rewrite_paths(proc.stderr.decode("utf-8", "replace")[-2000:], work)
        except subprocess.TimeoutExpired:
            status = "timeout"
        seconds = time.perf_counter() - t0
        out_path = os.path.join(work, "outputs.json")
        if os.path.exists(out_path):
            with open(out_path, encoding="utf-8") as f:
                outputs = json.load(f)
        else:
            outputs = {"import_error": status, "import_detail": {"message": "the child process wrote no outputs"},
                       "interface": {}, "scalar": {}, "table": {}}
            if status == "ok":
                status = "no_outputs"
        outputs["runner"] = {"status": status, "seconds": round(seconds, 3), "timeout": timeout,
                             "stderr_tail": stderr_tail, "mode": mode}
        os.makedirs(os.path.dirname(os.path.abspath(out_json)), exist_ok=True)
        with open(out_json, "w", encoding="utf-8", newline="\n") as f:
            json.dump(outputs, f, indent=1)
        scalar = outputs.get("scalar", {})
        return {"status": status, "seconds": round(seconds, 3),
                "import_ok": not outputs.get("import_error"),
                "calls_ok": sum(1 for r in scalar.values() if r.get("status") == "value"),
                "calls_error": sum(1 for r in scalar.values() if r.get("status") == "error"),
                "calls_total": len(scalar),
                "table_ok": outputs.get("table", {}).get("status") == "value",
                "fence_blocked": outputs.get("fence_blocked", []), "out_json": out_json}
    finally:
        if not keep_workspace:
            shutil.rmtree(work, ignore_errors=True)


def grade_vba(outputs_json: str, timeout: float = 120) -> dict:
    """Grade the runner's outputs with tests/test_vba_premium.py (the harness grader, separate process)."""
    _, grade = _harness()
    env = {"CS4_VBA_OUTPUTS": os.path.abspath(outputs_json)}
    code, results, seconds = grade._pytest(TEST_FILE, TESTS_DIR, env, timeout)
    verdict = grade._verdict(code, results, EXPECTED_IDS, seconds)
    verdict["ground_truth_source"] = (results or {}).get("ground_truth_source")
    return verdict


# ---------------------------------------------------------------------------
# Child side
# ---------------------------------------------------------------------------
def _child(work: str) -> None:
    # Everything the harness and an honest translation need is imported BEFORE the fence.
    import contextlib
    import decimal  # noqa: F401  (allowed standard library; loaded now)
    import importlib.util
    import inspect  # noqa: F401
    import io
    import math  # noqa: F401
    import traceback
    import warnings

    import numpy  # noqa: F401
    import pandas  # noqa: F401

    sys.path.insert(0, HARNESS_DIR)
    sys.path.insert(0, EXERCISE_DIR)
    import audit_fence
    import runner_vba
    from runner import rewrite_paths

    _dumps, _open = json.dumps, open  # captured before the translation can touch them
    out_path = os.path.join(work, "outputs.json")
    with _open(os.path.join(work, "job.json"), encoding="utf-8") as f:
        job = json.load(f)
    with _open(os.path.join(work, job["cases"]), encoding="utf-8") as f:
        cases = json.load(f)
    module_file = os.path.join(work, *job["module"].split("/"))
    given = job["mode"] == "given"

    blocked = audit_fence.install(workspace=work, write_path=out_path,
                                  guarded_files=[module_file, os.path.abspath(__file__),
                                                 os.path.abspath(runner_vba.__file__), audit_fence.__file__])
    sys.path[:] = [work] + [p for p in sys.path
                            if p and os.path.realpath(p) not in (os.path.realpath(HARNESS_DIR),
                                                                 os.path.realpath(EXERCISE_DIR))]

    this_file = os.path.abspath(__file__)

    def detail(exc: BaseException) -> dict:
        # skip this adapter's own frames: the agents only need the translation's part
        tb = exc.__traceback__
        while tb is not None and os.path.abspath(tb.tb_frame.f_code.co_filename) == this_file:
            tb = tb.tb_next
        text = "".join(traceback.format_exception(type(exc), exc, tb))
        return {"error_type": type(exc).__name__, "message": rewrite_paths(str(exc), work)[:300],
                "traceback": rewrite_paths(text, work)[-2000:]}

    record: dict = {"mode": job["mode"], "import_error": None, "import_detail": None, "interface": {},
                    "scalar": {}, "table": {}, "stdout_chars": 0}
    stdout_buf = io.StringIO()
    module = None
    try:
        with contextlib.redirect_stdout(stdout_buf), warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            spec = importlib.util.spec_from_file_location(MODULE_NAME, module_file)
            module = importlib.util.module_from_spec(spec)
            sys.modules[MODULE_NAME] = module
            spec.loader.exec_module(module)
        record["import_warnings"] = [f"{x.category.__name__}: {str(x.message)[:200]}" for x in w[:5]]
    except BaseException as exc:  # noqa: BLE001
        record["import_error"] = type(exc).__name__
        record["import_detail"] = detail(exc)
        module = None

    if module is not None:
        mp = getattr(module, "mtpl_premium", None)
        pt = getattr(module, "premium_table", None)
        params = None
        if callable(mp):
            try:
                params = list(inspect.signature(mp).parameters)
            except (TypeError, ValueError):
                params = None
        record["interface"] = {"has_mtpl_premium": callable(mp), "has_premium_table": callable(pt),
                               "mtpl_premium_parameters": params}
        with contextlib.redirect_stdout(stdout_buf):
            if callable(mp):
                for case in cases:
                    rec = runner_vba.call_scalar(mp, case)
                    if given and rec["status"] == "error":  # smoke inputs: the message helps the diagnosis
                        try:
                            mp(case["DrivAge"], case["VehPower"], case["BonusMalus"], case["Area"], case["Exposure"])
                        except BaseException as exc:  # noqa: BLE001
                            rec.update({k: v for k, v in detail(exc).items() if k in ("message", "traceback")})
                    record["scalar"][case["case_id"]] = rec
            if callable(pt):
                record["table"] = runner_vba.call_table(pt, cases)
                if given and record["table"].get("status") == "error":
                    try:
                        pt(runner_vba.input_table(cases))
                    except BaseException as exc:  # noqa: BLE001
                        record["table"].update({k: v for k, v in detail(exc).items() if k in ("message", "traceback")})
    record["stdout_chars"] = len(stdout_buf.getvalue())
    record["fence_blocked"] = list(blocked)
    payload = _dumps(record, allow_nan=False, indent=1)
    with _open(out_path, "w", encoding="utf-8", newline="\n") as f:
        f.write(payload)
    sys.stdout.flush()
    sys.stderr.flush()
    os._exit(0)  # no code of the translation runs after this


if __name__ == "__main__":
    if len(sys.argv) == 3 and sys.argv[1] == "--child":
        _child(os.path.realpath(sys.argv[2]))
    else:
        print("usage: python harness_vba.py --child <workspace>  (normally called via run_vba_translation)")
        sys.exit(2)
