"""Value-free tests for exercise (b): the migrated VBA tariff function.

"Run, then grade" (DESIGN.md section 3.3): the runner calls the translation in
another process and records its outputs as JSON; these tests only compare that
JSON with the legacy results. Every failure message names the quantity or the
test case and at most a band of the relative error, never a number from the
ground truth.

Categories (from the test names): interface, portfolio, edge, table.
"""
from __future__ import annotations

import pytest
from valuefree import ValueFreeFailure, check_close

# A premium is a whole number of cents, so an honest translation returns the
# same double as the legacy code. 1e-9 relative is far below one cent (a cent is
# 1e-4 relative on a premium of 100), so any difference of a cent fails.
PREMIUM_RTOL = 1e-9

PARAMETERS = ["driv_age", "veh_power", "bonus_malus", "area", "exposure"]

# Labels describe the INPUTS of each edge case, not the legacy result.
EDGE_LABELS = {
    "E01": "full year, age 72, power 11, area C",
    "E02": "empty driver age",
    "E03": "area code in lower case with spaces",
    "E04": "BonusMalus 49",
    "E05": "BonusMalus 351",
    "E06": "BonusMalus 50, half-year exposure",
    "E07": "BonusMalus 350",
    "E08": "area code G",
    "E09": "empty area code",
    "E10": "driver age 29.5",
    "E11": "age 25, power 5, area B",
    "E12": "age 70, power 10, area F",
    "E13": "BonusMalus 230, exposure 2.01",
    "E14": "area code Z and BonusMalus 400",
    "E15": "area code followed by a non-breaking space",
    "E16": "exposure 0",
    "E17": "BonusMalus 50, exposure 0.3",
    "E18": "age 22, power 5, area B, BonusMalus 64, exposure 0.7",
}


def _valid_ids(truth: dict, prefix: str = "") -> list[str]:
    return sorted(c for c, e in truth["cases"].items() if "premium" in e and c.startswith(prefix))


def _invalid_ids(truth: dict) -> list[str]:
    return sorted(c for c, e in truth["cases"].items() if "error" in e)


# --- interface ---------------------------------------------------------------
def test_interface_functions_exist(outputs):
    if outputs.get("import_error"):
        raise ValueFreeFailure("interface: the module could not be imported")
    itf = outputs.get("interface", {})
    if not (itf.get("has_mtpl_premium") and itf.get("has_premium_table")):
        raise ValueFreeFailure("interface: mtpl_premium and premium_table must both be defined")


def test_interface_parameter_names(outputs):
    if outputs.get("interface", {}).get("mtpl_premium_parameters") != PARAMETERS:
        raise ValueFreeFailure("interface: mtpl_premium must take (driv_age, veh_power, bonus_malus, area, exposure)")


def test_interface_returns_float(outputs):
    types = {r.get("value_type") for r in outputs.get("scalar", {}).values() if r.get("status") == "value"}
    if not types or not types <= {"float", "float64"}:
        raise ValueFreeFailure("interface: mtpl_premium must return a float")


# --- portfolio: the 200 freMTPL2-like rows ------------------------------------
def test_portfolio_premiums(outputs, truth):
    ids = _valid_ids(truth, "P")
    recs = [outputs.get("scalar", {}).get(c, {}) for c in ids]
    if any(r.get("status") != "value" for r in recs):
        raise ValueFreeFailure("portfolio rows: an exception or no value where the legacy code returns a premium")
    check_close("premium on the portfolio rows", [r["value"] for r in recs],
                [truth["cases"][c]["premium"] for c in ids], PREMIUM_RTOL)


# --- edge cases: one test each ------------------------------------------------
@pytest.mark.parametrize("case_id", sorted(EDGE_LABELS))
def test_edge_case(outputs, truth, case_id):
    label = f"edge case {case_id} ({EDGE_LABELS[case_id]})"
    expected = truth["cases"][case_id]
    got = outputs.get("scalar", {}).get(case_id, {"status": "missing"})
    if "error" in expected:
        if got.get("status") != "error":
            raise ValueFreeFailure(f"{label}: the legacy code raises an error here, so mtpl_premium must raise")
        if got.get("error_type") != "ValueError":
            raise ValueFreeFailure(f"{label}: raises the wrong exception type (ValueError required)")
    else:
        if got.get("status") != "value":
            raise ValueFreeFailure(f"{label}: raises an exception where the legacy code returns a premium")
        check_close(label, got["value"], expected["premium"], PREMIUM_RTOL)


# --- premium_table -------------------------------------------------------------
def _table(outputs) -> dict:
    t = outputs.get("table", {})
    if t.get("status") != "value":
        raise ValueFreeFailure("premium_table: raises an exception on the test table (rejected rows must give NaN)")
    if not t.get("is_series"):
        raise ValueFreeFailure("premium_table: must return a pandas Series")
    if not t.get("index_matches"):
        raise ValueFreeFailure("premium_table: the Series must have the input DataFrame's index")
    return t


def test_table_returns_aligned_series(outputs):
    _table(outputs)


def test_table_premiums(outputs, truth):
    values = _table(outputs)["values"]
    if any(values.get(c) is not None for c in _invalid_ids(truth)):
        raise ValueFreeFailure("premium_table: rows that the legacy code rejects must be NaN")
    valid = _valid_ids(truth)
    if any(values.get(c) is None for c in valid):
        raise ValueFreeFailure("premium_table: NaN or missing on a row that the legacy code prices")
    check_close("premium_table on the valid rows", [values[c] for c in valid],
                [truth["cases"][c]["premium"] for c in valid], PREMIUM_RTOL)


def test_table_agrees_with_scalar(outputs):
    values = _table(outputs)["values"]
    for case_id, rec in outputs.get("scalar", {}).items():
        table_value = values.get(case_id)
        same = (table_value is None) if rec.get("status") == "error" else (
            table_value is not None and rec.get("value") is not None
            and abs(table_value - rec["value"]) <= PREMIUM_RTOL * max(abs(rec["value"]), 1e-12))
        if not same:
            raise ValueFreeFailure("premium_table and mtpl_premium disagree on at least one row")
