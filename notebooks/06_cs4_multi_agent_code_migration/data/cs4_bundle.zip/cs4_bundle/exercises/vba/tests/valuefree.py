"""Value-free comparison helper for the graders (DESIGN.md section 3.3).

A failed check says WHICH quantity is off and roughly HOW FAR (a band of the
relative error), never the expected value, the actual value, the sign or the
exact error. The messages can therefore go back to an agent without handing it
the answers.

This module is imported by the tests but is not a test module, so pytest does
not rewrite its asserts (a rewritten assert would print both values).
Compatible with the harness's tests/valuefree.py: check_close(name, actual,
expected, rtol) and ValueFreeFailure. If the harness version exists when the
bundle is assembled, use that one instead.
"""
from __future__ import annotations

import numpy as np

# Upper edges of the relative-error bands reported in messages.
_BANDS = [(1e-9, "below 1e-9"), (1e-6, "1e-9 to 1e-6"), (1e-3, "1e-6 to 1e-3"),
          (1e-1, "1e-3 to 1e-1"), (np.inf, "above 1e-1")]


class ValueFreeFailure(AssertionError):
    """A test failure whose message carries no numbers from the ground truth."""


def _band(rel: float) -> str:
    for edge, label in _BANDS:
        if rel < edge:
            return label
    return _BANDS[-1][1]


def check_close(name: str, actual, expected, rtol: float) -> None:
    """Fail with a value-free message unless actual matches expected within rtol.

    actual and expected may be scalars or arrays of the same shape. The relative
    error is |actual - expected| / max(|expected|, 1e-12), element by element.
    """
    try:
        a = np.asarray(actual, dtype=float)
    except (TypeError, ValueError):
        raise ValueFreeFailure(f"{name}: not a number or an array of numbers") from None
    e = np.asarray(expected, dtype=float)
    if a.shape != e.shape:
        raise ValueFreeFailure(f"{name}: shape differs from the required shape")
    if not np.all(np.isfinite(a)):
        raise ValueFreeFailure(f"{name}: contains a value that is not a finite number")
    rel = float(np.max(np.abs(a - e) / np.maximum(np.abs(e), 1e-12))) if a.size else 0.0
    if not rel <= rtol:
        raise ValueFreeFailure(f"{name}: outside tolerance (relative error band {_band(rel)})")
