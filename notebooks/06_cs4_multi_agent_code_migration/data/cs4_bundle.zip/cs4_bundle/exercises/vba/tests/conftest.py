"""pytest configuration for the exercise (b) grader.

The grader never imports the translation. It reads two JSON files:
  CS4_VBA_OUTPUTS       what the runner recorded when it called the translation
  CS4_VBA_GROUND_TRUTH  the legacy results (default: the VBA run if it exists,
                        otherwise Excel's worksheet-formula restatement)
and, if CS4_RESULTS_JSON is set, writes one record per test there: test id,
category, outcome and only the value-free message (never pytest's report text
or captured output, which could contain numbers).
"""
from __future__ import annotations

import json
import os
from pathlib import Path

import pytest

EXERCISE = Path(__file__).resolve().parent.parent
GT_VBA = EXERCISE / "ground_truth" / "mtpl_premium_ground_truth_vba.json"
GT_WORKSHEET = EXERCISE / "ground_truth" / "mtpl_premium_ground_truth.json"

RESULTS: list[dict] = []


def ground_truth_path() -> Path:
    if os.environ.get("CS4_VBA_GROUND_TRUTH"):
        return Path(os.environ["CS4_VBA_GROUND_TRUTH"])
    return GT_VBA if GT_VBA.exists() else GT_WORKSHEET


@pytest.fixture(scope="session")
def outputs() -> dict:
    return json.loads(Path(os.environ["CS4_VBA_OUTPUTS"]).read_text(encoding="utf-8"))


@pytest.fixture(scope="session")
def truth() -> dict:
    return json.loads(ground_truth_path().read_text(encoding="utf-8"))


def _category(nodeid: str) -> str:
    """test_<category>_... -> <category> (interface, portfolio, edge, table)."""
    name = nodeid.split("::")[-1]
    return name.split("_")[1].split("[")[0] if name.startswith("test_") else "other"


@pytest.hookimpl(wrapper=True)
def pytest_runtest_makereport(item, call):
    rep = yield
    if rep.when == "call" or (rep.failed and rep.when == "setup"):
        message = ""
        if call.excinfo is not None:
            exc = call.excinfo.value
            # Only our own ValueFreeFailure messages are passed on; anything else
            # (a KeyError in a fixture, a plain assert) is reported by type only.
            message = str(exc) if type(exc).__name__ == "ValueFreeFailure" else call.excinfo.typename
        RESULTS.append({"id": item.nodeid.split("::")[-1], "category": _category(item.nodeid),
                        "outcome": rep.outcome, "message": message})
    return rep


def pytest_sessionfinish(session, exitstatus):
    path = os.environ.get("CS4_RESULTS_JSON")
    if path:
        gt = ground_truth_path()
        try:
            source = json.loads(gt.read_text(encoding="utf-8")).get("source", "unknown")
        except (OSError, ValueError):
            source = "missing"
        Path(path).write_text(json.dumps({"ground_truth_source": source, "results": RESULTS}, indent=1) + "\n",
                              encoding="utf-8", newline="\n")
