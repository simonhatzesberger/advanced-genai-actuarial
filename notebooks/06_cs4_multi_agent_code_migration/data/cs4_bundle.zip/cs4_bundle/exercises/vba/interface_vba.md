# Interface: migrating the VBA function MTPL_Premium to Python

Write one Python module, `mtpl_premium.py`, that reproduces the VBA function
`MTPL_Premium` in `MTPL_Premium.bas`. Only the expected numbers are hidden; this
interface is fixed.

## Functions

`mtpl_premium(driv_age, veh_power, bonus_malus, area, exposure) -> float`

- `driv_age`: float or None. None (or NaN) stands for an empty worksheet cell.
- `veh_power`: int
- `bonus_malus`: int
- `area`: str
- `exposure`: float, the years insured
- Returns the premium exactly as the VBA function returns it, as a float.
- Raises `ValueError` wherever the VBA function raises an error (`Err.Raise`).

`premium_table(df: pandas.DataFrame) -> pandas.Series`

- `df` has the columns `DrivAge`, `VehPower`, `BonusMalus`, `Area` and `Exposure`
  (the freMTPL2 names) and any index. An empty `DrivAge` is NaN.
- Returns a float Series with the same index as `df`: `mtpl_premium` for each
  row, and NaN for a row on which `mtpl_premium` raises `ValueError`.

## Rules

- Allowed imports: numpy, pandas and the standard library, except process and
  network modules (subprocess, os.system, socket, urllib and the like).
- No hardcoded results. Read no files: the functions receive everything they
  need as arguments.
- Keep the legacy behaviour, including behaviour that looks wrong. List anything
  an actuary should review in a comment at the top of the module.
- The tests compare your results with the legacy results on 200 portfolio rows
  and 18 edge cases, to the cent. A failure message names the quantity or the
  case, never the expected number.
