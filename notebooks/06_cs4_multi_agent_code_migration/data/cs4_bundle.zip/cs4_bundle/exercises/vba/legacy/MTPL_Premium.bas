Attribute VB_Name = "Tariff"
Option Explicit

' Motor third-party liability (MTPL) tariff.
' Annual premium from driver age, vehicle power, area and bonus-malus level,
' pro-rated by the exposure (years insured). Used on the pricing sheet as
' =MTPL_Premium(DrivAge, VehPower, BonusMalus, Area, Exposure).

Public Function MTPL_Premium(DrivAge As Variant, VehPower As Integer, _
    BonusMalus As Integer, Area As String, Exposure As Double) As Double
    Const BASE_RATE As Double = 180
    Const MIN_ANNUAL As Double = 90.25
    Dim fAge As Double, fPow As Double, fArea As Double, annual As Double
    Select Case DrivAge
        Case Is < 25: fAge = 1.75
        Case 25 To 29: fAge = 1.25
        Case 30 To 69: fAge = 1
        Case Else: fAge = 1.125
    End Select
    If VehPower <= 5 Then
        fPow = 0.875
    ElseIf VehPower <= 9 Then
        fPow = 1
    Else
        fPow = 1.25
    End If
    Select Case UCase(Trim(Area))
        Case "A", "B": fArea = 0.875
        Case "C", "D": fArea = 1
        Case "E", "F": fArea = 1.25
        Case Else: Err.Raise 5, , "Unknown area: " & Area
    End Select
    If BonusMalus < 50 Or BonusMalus > 350 Then Err.Raise 5, , "BonusMalus out of range"
    annual = BASE_RATE * fAge * fPow * fArea * BonusMalus / 100
    If annual < MIN_ANNUAL Then annual = MIN_ANNUAL
    MTPL_Premium = Application.WorksheetFunction.Round(annual * Exposure, 2)
End Function
