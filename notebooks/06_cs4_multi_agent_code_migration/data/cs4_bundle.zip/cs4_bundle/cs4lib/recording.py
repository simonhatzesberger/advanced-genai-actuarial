"""Fingerprints, recordings and the replay of a recorded run.

A recording (one run, JSON only) carries the run id, the example and variant, the models and efforts, the
package versions, UTC times, one log entry per node (agent calls with tokens incl. cached tokens, cache
writes and reasoning tokens, cost, seconds, tool calls with truncated arguments and results), the
attempts with their value-free test results and tripwire reports, the final translation, the report and a
fingerprint: the sha256 of the prompts, the interface, the tests and the settings. Absolute local paths
are rewritten before a recording is kept (<workspace>, <bundle>, <python>, <home>, <path>).
"""
from __future__ import annotations

import hashlib
import json
import platform
import re
from pathlib import Path


def versions() -> dict:
    import importlib.metadata as md
    out = {"python": platform.python_version()}
    for p in ("openai", "langgraph", "numpy", "pandas", "statsmodels", "scipy", "pytest"):
        try:
            out[p] = md.version(p)
        except Exception:
            out[p] = None
    return out


def sha(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def fingerprint(ws, prompts: dict, settings: dict) -> dict:
    """sha256 of the prompts, the interface, the tests and the settings (and of all four together).
    settings: agents, max_attempts, recursion_limit, run_cap_usd, session_cap_usd, prices, report_narrative."""
    tests_text = "".join(Path(f).read_text(encoding="utf-8") for f in ws.test_files)
    parts = {"prompts": sha(json.dumps(prompts, sort_keys=True)), "interface": sha(ws.interface),
             "tests": sha(tests_text), "settings": sha(json.dumps(settings, sort_keys=True))}
    return {"fingerprint": sha(json.dumps(parts, sort_keys=True)), "parts": parts}


PATH_PATTERN = re.compile(r"(?<![A-Za-z])[A-Za-z]:[\\/]|[\\/]Users[\\/]|[\\/]home[\\/]|AppData", re.IGNORECASE)


def strings(obj):
    """Every string inside a JSON-like object (keys included), for the path check."""
    if isinstance(obj, str):
        yield obj
    elif isinstance(obj, list):
        for x in obj:
            yield from strings(x)
    elif isinstance(obj, dict):
        for k, v in obj.items():
            yield k
            yield from strings(v)


def deep_sanitise(obj, fn):
    if isinstance(obj, str):
        return fn(obj)
    if isinstance(obj, list):
        return [deep_sanitise(x, fn) for x in obj]
    if isinstance(obj, dict):
        return {k: deep_sanitise(v, fn) for k, v in obj.items()}
    return obj


def path_fragments(obj) -> list[str]:
    """Absolute-path fragments left anywhere in a JSON-like object (an empty list is the goal)."""
    return sorted({m.group(0) for text in strings(obj) for m in PATH_PATTERN.finditer(text)})


def finish_recording(rec: dict, ws) -> dict:
    """Rewrite absolute paths in a recording and add the path check."""
    rec = deep_sanitise(rec, ws.sanitise)
    rec["path_check"] = {"absolute_path_fragments_left": path_fragments(rec)}
    return rec


# ---- recorded runs ---------------------------------------------------------------------------------------
def load_recordings(path) -> dict:
    """data/recordings.json: Part A runs, Part B runs and the recorded scores (one JSON file)."""
    return json.loads(Path(path).read_text(encoding="utf-8"))


def part_a_run(recordings: dict, run_id: str) -> dict:
    return next(r for r in recordings["part_a"]["runs"] if r["run_id"] == run_id)


def replay_printout(rec: dict, print_fn=print, show_tests: bool = True) -> None:
    """Print a recorded run as the live run printed it, clearly labelled as a recording."""
    print_fn(f"[recorded run {rec['run_id']}, {rec['utc_start']} UTC, openai {rec['versions'].get('openai')}]")
    for line in rec["printout"]:
        print_fn(line)
    if show_tests:
        print_fn("\n" + rec["test_table"])
