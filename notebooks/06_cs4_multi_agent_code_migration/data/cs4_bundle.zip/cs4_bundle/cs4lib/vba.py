"""Exercise (b): the Part A migration graph on a VBA tariff function.

The legacy code is the VBA function MTPL_Premium (exercises/vba/legacy/MTPL_Premium.bas). The graph, the
five agents, their settings, the routing in code, the caps and the recording are those of Part A. What
changes:

* the agent workspace holds only MTPL_Premium.bas and interface_vba.md (no data, no legacy output);
* the analysis and translation instructions are adapted for VBA (the notebook's exercise cell holds them;
  vba_prompts() puts them together with the other three prompts, whose R wording it replaces);
* check_and_run_translation() and run_test_suite() go through the exercise's adapter
  exercises/vba/harness_vba.py: the translation runs in a child process behind the harness's audit-hook
  fence; the compilation check calls it on three smoke inputs (not test cases); the test suite (25 tests:
  interface 3, portfolio 1, edge 18, table 3) is graded by the harness grader in a separate pytest
  process; the messages are value-free;
* the tripwire uses the legacy results as answer keys, minus the tariff's own constants (a translation
  must be able to write MIN_ANNUAL = 90.25, which is also the premium of many full-year rows).

The ground truth is Excel's worksheet formula restating MTPL_Premium, computed through Excel over COM; the
VBA function itself was never executed.
"""
from __future__ import annotations

import json
import os
import re
import shutil
import sys
import tempfile
from collections import Counter
from pathlib import Path

from . import BUNDLE_DIR
from . import tasks as _tasks
from .workspace import TOOL_TEXT_LIMIT, changed_grader_files, harness_modules, not_graded

EXAMPLE = "vba_premium"
SPEC = {
    "r_file": "exercises/vba/legacy/MTPL_Premium.bas",     # the legacy file (the key name is Part A's)
    "data": [],
    "interface": "exercises/vba/interface_vba.md",
    "module": "mtpl_premium.py",
    "gt": "exercises/vba/ground_truth/mtpl_premium_ground_truth.json",
    "hidden_calls": set(),
    "expected_raise": set(),
}


def vba_prompts(part_a_prompts: dict, analysis_prompt: str, translation_prompt: str) -> dict:
    """The five prompts of the VBA run: the exercise's analysis and translation instructions, and Part A's
    compilation, test-runner and report prompts with their R wording replaced."""
    compilation = part_a_prompts["compilation"].replace(
        "You check that the translated module imports and runs on the given data.",
        "You check that the translated module imports and runs on three smoke inputs (not test cases).").replace(
        "scans the module with a static tripwire and then runs it in a fenced sandbox on the given data.",
        "scans the module with a static tripwire and then runs it in a fenced sandbox on three smoke inputs.").replace(
        "You may use read_file to look at the translated module (translated/<module>.py), the R script or R's printed "
        "output on the given data (r_output_A.txt).",
        "You may use read_file to look at the translated module (translated/<module>.py), the VBA module or the "
        "interface.").replace(
        "printed output that differs from R's printed output on the given data).",
        "smoke results that contradict the VBA code).")
    test_runner = part_a_prompts["test_runner"].replace(
        "grades its outputs against R's results in a separate process.",
        "grades its outputs against the legacy results in a separate process.").replace(
        "or the R script to locate", "or the VBA module to locate").replace(
        "The test messages name the quantity and a band for the relative error; a failure on the hidden triangle says "
        "only that it fails there. They never contain expected values. Do not guess R's values.",
        "The test messages name the quantity or the edge case and a band for the relative error. They never contain "
        "expected values. Do not guess the legacy values.")
    report = part_a_prompts["report"].replace(
        "[2-3 sentences: what the original R code does]", "[2-3 sentences: what the original VBA code does]").replace(
        "### Key R-to-Python Library Mappings\n| R Construct |", "### Key VBA-to-Python Mappings\n| VBA Construct |").replace(
        "[bullet list of R-specific constructs that needed special treatment]",
        "[bullet list of VBA-specific constructs that needed special treatment]")
    out = {"analysis": analysis_prompt, "translation": translation_prompt, "compilation": compilation,
           "test_runner": test_runner, "report": report}
    for name in ("compilation", "test_runner", "report"):
        if out[name] == part_a_prompts[name] or "R's" in out[name] or " R script" in out[name]:
            print(f"[ATTENTION] The VBA wording of the {name} prompt did not apply fully: its Part A text has changed.")
    return out


# ---- Task messages ---------------------------------------------------------------------------------------
def _user(text: str) -> list[dict]:
    return [{"role": "user", "content": text}]


def analysis_task(ws) -> list[dict]:
    return _user(f"Analyse the legacy VBA module `MTPL_Premium.bas` for its migration to the Python module "
                 f"`{ws.spec['module']}`.\n\nFiles in the workspace:\n{ws.listing()}\n\n"
                 f"The target interface (interface_vba.md; the translator must implement exactly this):\n\n{ws.interface}")


def translation_task(ws, analysis: str, attempt: int, max_attempts: int, feedback: str | None,
                     previous_code: str | None, leak_note: str | None = None,
                     retry_reason: str | None = None) -> list[dict]:
    """As in Part A: message 1 is identical in every attempt (prompt cache); message 2 only on a retry."""
    source = (ws.root / "MTPL_Premium.bas").read_text(encoding="utf-8")
    parts = [f"Translate `MTPL_Premium.bas` into the Python module `{ws.spec['module']}` "
             f"(at most {max_attempts} attempts; a retry message follows this one if an attempt fails).",
             f"## Interface (binding)\n\n{ws.interface}",
             f"## The VBA module `MTPL_Premium.bas`\n\n```vb\n{source}\n```",
             f"## Analysis by the analysis agent\n\n{analysis or '(no analysis available)'}",
             f"## Files in the workspace\n\n{ws.listing(include_translation=False)}"]
    items = _user("\n\n".join(parts))
    if attempt > 1:
        retry = [f"## Attempt {attempt} of at most {max_attempts}: {retry_reason or 'the previous attempt failed'}"]
        if feedback:
            retry.append(f"## Feedback on the previous attempt\n\n{feedback}")
        if previous_code:
            retry.append(f"## The previous translation ({ws.module_rel})\n\n```python\n{previous_code}\n```")
        items += _user("\n\n".join(retry))
    return items


def compilation_task(ws) -> list[dict]:
    return _user(f"A new translation was written to {ws.module_rel} (attempt {ws.attempt}). Check that it imports "
                 "and runs on the smoke inputs, and report.")


def test_task(ws) -> list[dict]:
    return _user(f"The translation {ws.module_rel} (attempt {ws.attempt}) runs on the smoke inputs. "
                 "Run the test suite and report.")


report_task = _tasks.report_task


# ---- The workspace and the two fenced tools --------------------------------------------------------------
def adapter():
    d = str(BUNDLE_DIR / "exercises" / "vba")
    if d not in sys.path:
        sys.path.insert(0, d)
    import harness_vba  # noqa: E402
    return harness_vba


NUM_IN_BAS = re.compile(r"(?<![\w.])\d+\.\d+(?![\w.])")


class VBAFencedTools:
    """A mixin for the notebook's Workspace: the VBA exercise's set-up and its two fenced tools.

        class VBAWorkspace(cs4lib.vba.VBAFencedTools, Workspace): ...

    The four file tools come from the notebook's Workspace; everything else of WorkspaceBase is reused."""

    def __init__(self):  # the Part A constructor copies R files; this one does its own set-up
        self.example, self.leak_answers, self.custom_r_source = EXAMPLE, False, False
        self.spec = dict(SPEC)
        self.runner, self.grader, self.tripwire = harness_modules()
        self.hv = adapter()
        self.root = Path(os.path.realpath(tempfile.mkdtemp(prefix="cs4agent_")))
        self.outdir = Path(os.path.realpath(tempfile.mkdtemp(prefix="cs4out_")))  # never shown to agents
        (self.root / "translated").mkdir()
        self.files = {}
        for rel in (SPEC["r_file"], SPEC["interface"]):
            shutil.copyfile(BUNDLE_DIR / rel, self.root / Path(rel).name)
            self.files[Path(rel).name] = rel
        self.interface = (BUNDLE_DIR / SPEC["interface"]).read_text(encoding="utf-8")
        self.gt_a = {}   # no total reserve; the legacy results are used by the tripwire and the grader only
        bas = (BUNDLE_DIR / SPEC["r_file"]).read_text(encoding="utf-8")
        constants = {float(x) for x in NUM_IN_BAS.findall(bas)}
        own = {self.tripwire._sig6(c) for c in constants} | {self.tripwire._sig6(-c) for c in constants}
        self.answer_keys = self.tripwire.load_answer_keys([BUNDLE_DIR / SPEC["gt"]]) - own
        self.excluded_constants = sorted(constants)
        self.attempt = 0
        self.written_this_attempt = False
        self.last_notes = ""
        self.last_check: dict | None = None
        self.last_tests: dict | None = None
        self.last_check_text = ""
        self.last_tests_text = ""
        self.tests_dir = BUNDLE_DIR / "exercises" / "vba" / "tests"
        self.test_files = [self.tests_dir / n for n in ("conftest.py", "valuefree.py", "test_vba_premium.py")]
        self.test_digest = {}  # the exercise's tests are in the bundle, which changed_grader_files() covers
        self.n_tests_expected = len(self.hv.EXPECTED_IDS)  # 25: the suite is parametrised over the test inputs

    # -- compilation agent: tripwire, then the fenced runner on three smoke inputs --------------------------
    def check_and_run_translation(self, args: dict | None = None) -> str:
        src = self.translation_source()
        if src is None:
            self.last_check = {"status": "EXECUTION_FAILED", "reason": "no translation written",
                               "tripwire": None, "runner": None}
            self.last_check_text = "EXECUTION_FAILED\nNo translation has been written yet."
            return self.last_check_text
        trip = self.tripwire.scan(src, self.answer_keys)
        out_json = self.outdir / f"given_attempt{self.attempt}.json"
        summary = self.hv.run_vba_translation(str(self.translation_path), str(out_json), mode="given")
        outputs = json.loads(out_json.read_text(encoding="utf-8"))
        itf, scalar, table = outputs.get("interface", {}), outputs.get("scalar", {}), outputs.get("table", {})
        ok = (summary["status"] == "ok" and summary["import_ok"] and itf.get("has_mtpl_premium")
              and itf.get("has_premium_table") and all(scalar.get(c, {}).get("status") == "value" for c in ("S1", "S2"))
              and table.get("status") == "value")
        status = "EXECUTION_SUCCESS" if ok else "EXECUTION_FAILED"
        lines = [status, self.tripwire.summary_line(trip),
                 f"runner: {summary['status']}, {summary['seconds']:.1f} s"]
        if outputs.get("import_error"):
            d = outputs.get("import_detail") or {}
            lines.append(f"import FAILED: {outputs['import_error']}: {d.get('message', '')}")
            if d.get("traceback"):
                lines.append("traceback (tail):\n" + d["traceback"][-1500:])
        else:
            lines.append(f"interface: mtpl_premium {'found' if itf.get('has_mtpl_premium') else 'MISSING'} "
                         f"(parameters {itf.get('mtpl_premium_parameters')}), premium_table "
                         f"{'found' if itf.get('has_premium_table') else 'MISSING'}")
            for w in outputs.get("import_warnings", [])[:3]:
                lines.append(f"warning at import: {w}")
            for case in self.hv.SMOKE_CASES:
                r = scalar.get(case["case_id"])
                if r is None:
                    continue
                args_txt = ", ".join(repr(case[k]) for k in ("DrivAge", "VehPower", "BonusMalus", "Area", "Exposure"))
                if r.get("status") == "value":
                    lines.append(f"smoke {case['case_id']}: mtpl_premium({args_txt}) returned {r['value_type']} {r['value']!r}")
                else:
                    lines.append(f"smoke {case['case_id']}: mtpl_premium({args_txt}) raised {r.get('error_type')}: "
                                 f"{r.get('message', '')}")
                    if case["case_id"] != "S3" and r.get("traceback"):
                        lines.append("traceback (tail):\n" + r["traceback"][-1200:])
            if table:
                if table.get("status") == "value":
                    vals = table.get("values", {})
                    lines.append(f"premium_table on the 3 smoke rows: Series={table.get('is_series')}, index kept="
                                 f"{table.get('index_matches')}, dtype {table.get('dtype')}, values "
                                 + ", ".join(f"{k}: {v!r}" for k, v in vals.items()))
                else:
                    lines.append(f"premium_table raised {table.get('error_type')}: {table.get('message', '')}")
                    if table.get("traceback"):
                        lines.append("traceback (tail):\n" + table["traceback"][-1200:])
        if outputs.get("runner", {}).get("stderr_tail"):
            lines.append("stderr (tail):\n" + outputs["runner"]["stderr_tail"][-800:])
        if summary.get("fence_blocked"):
            lines.append(f"fence refused: {summary['fence_blocked'][:5]}")
        text = self.sanitise("\n".join(lines))
        if len(text) > TOOL_TEXT_LIMIT:
            text = text[:TOOL_TEXT_LIMIT] + "\n... [truncated]"
        errs = {r.get("error_type") for c, r in scalar.items() if r.get("status") == "error" and c != "S3"}
        if outputs.get("import_error"):
            errs.add(outputs["import_error"])
        self.last_check = {"status": status, "tripwire": trip, "runner": summary["status"],
                           "runner_seconds": summary["seconds"], "import_ok": summary["import_ok"],
                           "calls_ok": summary["calls_ok"], "calls_total": summary["calls_total"],
                           "error_types": sorted(e for e in errs if e), "total_reserve_A": None}
        self.last_check_text = text
        return text

    # -- test-runner agent: the fenced runner on the 218 test inputs, then the grader ----------------------
    def run_test_suite(self, args: dict | None = None) -> str:
        if self.translation_source() is None:
            self.last_tests = {"passed": False, "n_passed": 0, "n_tests": 0, "by_category": {}, "failures": []}
            self.last_tests_text = "TESTS_FAILED\nNo translation has been written yet."
            return self.last_tests_text
        out_json = self.outdir / f"all_attempt{self.attempt}.json"
        summary = self.hv.run_vba_translation(str(self.translation_path), str(out_json), mode="all")
        changed = changed_grader_files()
        if changed:  # the translation wrote into what the grader reads: grade nothing
            verdict, text = not_graded(changed, self.n_tests_expected)
            self.last_tests = {**verdict, "runner_status": summary["status"], "runner_seconds": summary["seconds"],
                               "seconds": round(summary["seconds"], 2), "total_reserve_A": None}
            self.last_tests_text = self.sanitise(text)
            return self.last_tests_text
        verdict = self.hv.grade_vba(str(out_json))
        outputs = json.loads(out_json.read_text(encoding="utf-8"))
        head = "TESTS_PASSED" if verdict["passed"] else "TESTS_FAILED"
        lines = [f"{head} {verdict['n_passed']}/{verdict['n_tests']}",
                 "by category: " + ", ".join(f"{c} {p}/{t}" for c, (p, t) in verdict["by_category"].items())]
        if not verdict["consistent"]:
            lines.append("grader: exit code, test ids and results file disagree; counted as a failure")
        if verdict["missing_ids"]:
            lines.append(f"tests that did not report: {len(verdict['missing_ids'])}")
        if verdict["failures"]:
            lines.append("failed tests (value-free messages):")
            lines += [f"- {f['id']} [{f['category']}]: {f['message']}" for f in verdict["failures"]]
        problems = []
        if outputs.get("import_error"):
            problems.append(f"import failed: {outputs['import_error']}")
        errors = Counter(r.get("error_type") for r in outputs.get("scalar", {}).values() if r.get("status") == "error")
        if errors:  # counts only: which inputs raise is what the edge-case tests report
            problems.append("mtpl_premium raised on some test inputs: "
                            + ", ".join(f"{k} x{v}" for k, v in sorted(errors.items())))
        if outputs.get("table", {}).get("status") == "error":
            problems.append(f"premium_table raised {outputs['table'].get('error_type')} on the test table")
        if summary["status"] != "ok":
            problems.append(f"runner status: {summary['status']}")
        if summary.get("fence_blocked"):
            problems.append(f"fence refused: {summary['fence_blocked'][:3]}")
        if problems:
            lines.append("notes from the runner:")
            lines += problems
        text = self.sanitise("\n".join(lines))
        if len(text) > TOOL_TEXT_LIMIT:
            text = text[:TOOL_TEXT_LIMIT] + "\n... [truncated]"
        self.last_tests = {**verdict, "runner_status": summary["status"], "runner_seconds": summary["seconds"],
                           "seconds": round(summary["seconds"] + verdict["seconds"], 2), "total_reserve_A": None}
        self.last_tests_text = text
        return text


def run_reference_solution() -> dict:
    """The exercise's reference solution through the fenced runner and the grader (no API)."""
    hv = adapter()
    with tempfile.TemporaryDirectory(prefix="cs4vba_") as tmp:
        out_json = Path(tmp) / "outputs.json"
        summary = hv.run_vba_translation(str(BUNDLE_DIR / "exercises" / "vba" / "reference_solution" / "mtpl_premium.py"),
                                         str(out_json), mode="all")
        verdict = hv.grade_vba(str(out_json))
    return {**verdict, "runner_status": summary["status"], "runner_seconds": summary["seconds"]}
