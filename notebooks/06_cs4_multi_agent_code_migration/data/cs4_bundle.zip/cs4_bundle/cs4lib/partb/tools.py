"""Part B: the computing tools and the results registry.

Every number an agent may put into the report is computed here, by pandas, numpy and scipy, and stored in
a registry under an ID such as `ow_VehAge.16-20.frequency`. The agents see rounded values and IDs; the
report contains only `{{ID}}` placeholders, which code fills in at the end. The registry lives outside
the LangGraph state (the state holds JSON only: IDs, plans, drafts, logs).

Tools:
  data_quality_scan()          rule-based checks on the delivered data (runs before planning)
  portfolio_summary()          exposure, claims, frequency, severity, pure premium
  one_way(factor)              the same by level of one rating factor, with 95% confidence intervals
  fit_poisson_glm(factors)     Poisson GLM with log-exposure offset, fitted on aggregated rating cells;
                               check_glm_choice() then tests the chosen factor set (likelihood-ratio tests)
  largest_claims(n)            the n largest claim amounts and how concentrated the amounts are
  check_hypothesis(spec)       a typed comparative statement, decided TRUE or FALSE by code
"""
from __future__ import annotations

import math
import re
from dataclasses import dataclass, field

import numpy as np
import pandas as pd
from scipy import sparse, stats

from .data import FACTORS, FACTOR_NAMES, NOMINAL_FACTORS, band

Z95 = stats.norm.ppf(0.975)

# Thresholds of the rule-based scan. They are the actuary's, stated up front, not the model's.
SCAN_RULES = {
    "block_min_run": 100,        # a run of >= 100 consecutive policies (by IDpol) that all have a claim
    "drivage_min": 18,
    "vehage_max": 50,
    "claimnb_cap": 4,
    "exposure_cap": 1.0,
    "outlier_low": 0.5,          # nominal level relativity outside [0.5, 2.0] ...
    "outlier_high": 2.0,
    "outlier_min_exposure": 500,  # ... with at least 500 exposure-years
}


# ---- The registry ----------------------------------------------------------------------------------
def fmt(value, kind: str) -> str:
    """How a registry value is displayed in the report. One function, so tests can check it."""
    if kind in ("label", "text", "verdict"):
        return str(value)
    if value is None or (isinstance(value, float) and not math.isfinite(value)):
        return "n/a"
    if kind == "count":
        return f"{int(round(value)):,}"
    if kind == "exposure":
        return f"{value:,.0f}"
    if kind == "frequency":
        return f"{value:.4f}"
    if kind == "relativity":
        return f"{value:.2f}"
    if kind == "share":
        return f"{100 * value:.1f}%"
    if kind == "eur":
        return f"EUR {value:,.0f}"
    if kind == "eur2":
        return f"EUR {value:,.2f}"
    if kind == "number":
        return f"{value:,.4g}"
    if kind == "stat":
        return f"{value:,.1f}"
    if kind == "pvalue":
        return "p < 0.001" if value < 0.001 else f"p = {value:.3f}"
    raise ValueError(kind)


# What a registry ID means, for the IDs whose name alone could be misread. The writer and the fact checker see
# these notes next to the values (first matching pattern wins).
NOTES = [
    (r"^dq\.claim_only_block\.policies$", "policies in the longest run of consecutive IDpol that all have a claim"),
    (r"^dq\.claim_only_block\.claims$", "claims held by the block's policies"),
    (r"^dq\.claim_only_block\.share_of_claims$", "block claims / all claims of the delivered data (duplicate rows counted once)"),
    (r"^dq\.claim_only_block\.share_without_amount$", "share of the block's policies that have no claim amount"),
    (r"^dq\.claim_only_block\.frequency_with_block$",
     "block included; rows that pass the other rules (duplicates once, exposure > 0, driver age >= 18, "
     "flagged levels left out); exposure and claims capped"),
    (r"^dq\.claim_only_block\.frequency_without_block$",
     "block excluded; rows that pass the other rules (duplicates once, exposure > 0, driver age >= 18, "
     "flagged levels left out); exposure and claims capped"),
    (r"^dq\.claims_without_amount\.policies$", "delivered policies with a claim but no row in freMTPL2sev"),
    (r"^dq\.claims_without_amount\.claims$", "claims of those policies (delivered data, before any treatment)"),
    (r"^dq\.claims_without_amount\.claims_in_block$", "claims without an amount inside the claim-only block"),
    (r"^dq\.claims_without_amount\.claims_outside_block$",
     "claims without an amount outside the block, before the other treatments"),
    (r"^dq\.claims_without_amount\.top_region_outside_block$",
     "region with the most claims without an amount outside the block"),
    (r"^dq\.claims_without_amount\.top_region_claims$", "claims without an amount in that region, outside the block"),
    (r"^dq\.amounts_without_policy\.rows$", "rows of freMTPL2sev whose IDpol is not in freMTPL2freq"),
    (r"^dq\.vehage_above_max\.rows_99_or_100$", "rows with VehAge 99 or 100 (see dq.vehage_above_max.code_values)"),
    (r"^dq\.vehage_above_max\.code_values$", "vehicle ages above the threshold that occur at least 10 times (likely codes)"),
    (r"^dq\.[a-z_]+\.rows$", "rows of the delivered policy table that break this rule"),
    (r"^dq\.[a-z_]+\.threshold$", "the rule's threshold"),
    (r"^dq\.level_outliers\.[A-Za-z]+\.[^.]+\.relativity$",
     "flagged level's frequency / portfolio frequency (delivered data outside the block)"),
    (r"others_(min|max)_relativity$", "range of the relativities of the factor's other levels (not flagged)"),
    (r"^dec\.policies_removed$", "delivered policy rows minus analysed policies (all treatments together)"),
    (r"^dec\.dropped_exact_duplicates$", "exact duplicate rows dropped"),
    (r"^dec\.dropped_invalid_rows$", "rows dropped for exposure <= 0 or driver age below 18"),
    (r"^dec\.excluded_block_policies$", "policies of the claim-only block excluded"),
    (r"^dec\.excluded_outlier_policies$", "policies of the flagged outlier levels excluded"),
    (r"^ps\.exposure$", "exposure-years of the analysis data"),
    (r"^ps\.claims_without_amount$", "claims of the analysis data without an amount row"),
    (r"^ps\.severity$", "mean claim amount per amount row"),
    (r"^ps\.pure_premium$", "claim amounts / exposure (EUR per exposure-year)"),
    (r"^ow_[A-Za-z]+\.frequency_spread$", "highest / lowest level frequency of this factor (one-way)"),
    (r"^ow_[A-Za-z]+\.[^.]+\.sev_ci_(low|high)$", "95% interval for the mean amount, log scale (never below zero)"),
    (r"^meta\.sev_ci_method$", "how the severity intervals are computed"),
    (r"^ow_[A-Za-z]+\.severity_spread$", "highest / lowest level severity of this factor, levels with >= 30 amounts"),
    (r"^ow_[A-Za-z]+\.(highest|lowest)_severity_level$", "among the levels with >= 30 amounts"),
    (r"^glm\d+\.cells$", "non-empty rating cells the GLM was fitted on"),
    (r"^glm\d+\.lr\.drop\.[A-Za-z]+\.statistic$",
     "likelihood-ratio statistic for dropping this chosen factor (deviance increase)"),
    (r"^glm\d+\.lr\.(add\.[A-Za-z]+|strongest_excluded)\.statistic$",
     "likelihood-ratio statistic for adding this left-out factor (deviance decrease)"),
    (r"^glm\d+\.lr\..+\.df$", "degrees of freedom of the likelihood-ratio test"),
    (r"^glm\d+\.lr\..+\.p_value$", "chi-square p-value of the likelihood-ratio test"),
    (r"^glm\d+\.lr\..+\.bic_gain$",
     "LR statistic - df x ln(policies analysed); positive: BIC also prefers the model WITH this factor"),
    (r"^glm\d+\.lr\.strongest_excluded\.factor$",
     "the left-out factor with the smallest likelihood-ratio p-value when added to the chosen set"),
    (r"^glm\d+\.lr\.chosen_supported$", "chosen factors whose likelihood-ratio test is significant at the test level"),
    (r"^glm\d+\.lr\.excluded_significant$",
     "left-out factors that would improve the fit significantly at the test level"),
    (r"^glm\d+\.lr\.agreement$",
     "code's verdict on the analyst's factor choice: agrees if every chosen factor is significant and no "
     "left-out factor is"),
    (r"^glm\d+\.[A-Za-z]+\.[^.]+\.relativity$", "GLM relativity against the factor's base level"),
    (r"^glm\d+\.[A-Za-z]+\.relativity_spread$", "highest / lowest GLM relativity of this factor"),
    (r"^lc\.n$", "how many of the largest claims are listed"),
    (r"^lc\.top_n_share$", "share of all claim amounts held by the lc.n largest claims"),
    (r"^lc\.count_above_threshold$", "claims with an amount >= lc.threshold"),
    (r"^lc\.share_above_threshold$", "share of all claim amounts held by the claims >= lc.threshold"),
    (r"^lc\.amount_rows$", "claim amounts linked to analysed policies"),
    (r"^S\d+\.rank$", "rank of the statement's group among the groups compared (1 = highest value)"),
    (r"^S\d+\.comparator_label$",
     "the level the statement's group is compared with (for highest: the highest other level)"),
    (r"^ranking\.frequency_spread\.\d+$",
     "factor with the k-th widest one-way frequency spread among the factors analysed"),
    (r"^ranking\.severity_spread\.\d+$",
     "factor with the k-th widest one-way severity spread among the factors analysed"),
    (r"^ranking\.glm\d+\.relativity_spread\.\d+$", "factor with the k-th widest GLM relativity spread in that GLM"),
]


def note_for(rid: str) -> str:
    for pattern, note in NOTES:
        if re.search(pattern, rid):
            return note
    return ""


@dataclass
class Registry:
    """ID -> {value, kind, display, source}. One registry per run; never inside the graph state."""
    entries: dict = field(default_factory=dict)

    def put(self, rid: str, value, kind: str, source: str) -> str:
        if isinstance(value, (np.floating, np.integer)):
            value = value.item()
        self.entries[rid] = {"value": value, "kind": kind, "display": fmt(value, kind), "source": source}
        note = note_for(rid)
        if note:
            self.entries[rid]["note"] = note
        return rid

    def display(self, rid: str) -> str:
        return self.entries[rid]["display"]

    def __contains__(self, rid: str) -> bool:
        return rid in self.entries

    def to_json(self) -> dict:
        return self.entries


# ---- Data quality scan (on the delivered data, before any treatment) -------------------------------
def longest_claim_run(freq: pd.DataFrame) -> tuple[int, int, int]:
    """(length, first IDpol, last IDpol) of the longest run of consecutive policies, in IDpol order,
    that all have at least one claim. Duplicated IDs count once."""
    ordered = freq.drop_duplicates("IDpol").sort_values("IDpol")
    has = (ordered.ClaimNb.to_numpy() > 0).astype(int)
    ids = ordered.IDpol.to_numpy()
    # Run lengths via the positions where the indicator changes.
    edges = np.flatnonzero(np.diff(np.r_[0, has, 0]))
    starts, ends = edges[0::2], edges[1::2]
    if len(starts) == 0:
        return 0, -1, -1
    lengths = ends - starts
    i = int(np.argmax(lengths))
    return int(lengths[i]), int(ids[starts[i]]), int(ids[ends[i] - 1])


def data_quality_scan(freq: pd.DataFrame, sev: pd.DataFrame, reg: Registry) -> dict:
    """Run every rule on the delivered data and register the results under dq.*."""
    r = SCAN_RULES
    out: dict = {}
    src = "data_quality_scan"
    amount_rows = sev.groupby("IDpol").size()
    n_amounts = freq.IDpol.map(amount_rows).fillna(0).astype(int)

    # Rule 1: the claim-only block.
    run_len, first_id, last_id = longest_claim_run(freq)
    in_block = freq.IDpol.between(first_id, last_id) if run_len >= r["block_min_run"] else pd.Series(False, index=freq.index)
    block = freq[in_block].drop_duplicates()
    rest = freq[~in_block & (freq.Exposure > 0)]

    def capped_freq(d):
        return d.ClaimNb.clip(upper=r["claimnb_cap"]).sum() / d.Exposure.clip(upper=r["exposure_cap"]).sum()

    block_claims = int(block.ClaimNb.sum())
    block_without_amount = int(((block.ClaimNb > 0) & (block.IDpol.map(amount_rows).fillna(0) == 0)).sum())
    out["claim_only_block"] = {
        "fired": run_len >= r["block_min_run"], "policies": run_len, "first_idpol": first_id, "last_idpol": last_id,
        "claims": block_claims, "share_of_claims": block_claims / freq.drop_duplicates().ClaimNb.sum(),
        "share_without_amount": block_without_amount / max(len(block), 1)}
    reg.put("dq.claim_only_block.policies", run_len, "count", src)
    reg.put("dq.claim_only_block.first_idpol", first_id, "count", src)
    reg.put("dq.claim_only_block.last_idpol", last_id, "count", src)
    reg.put("dq.claim_only_block.claims", block_claims, "count", src)
    reg.put("dq.claim_only_block.share_of_claims", out["claim_only_block"]["share_of_claims"], "share", src)
    reg.put("dq.claim_only_block.share_without_amount", out["claim_only_block"]["share_without_amount"], "share", src)
    reg.put("dq.claim_only_block.min_run", r["block_min_run"], "count", src)
    # (The block's effect on the frequency is measured after rule 9, on the rows that pass every other rule.)

    # Rule 2: claims without an amount row, and amount rows without a policy.
    uniq = freq.drop_duplicates()
    no_amount = (uniq.ClaimNb > 0) & (uniq.IDpol.map(amount_rows).fillna(0) == 0)
    uniq_in_block = uniq.IDpol.between(first_id, last_id) if run_len >= r["block_min_run"] else pd.Series(False, index=uniq.index)
    out["claims_without_amount"] = {
        "fired": bool(no_amount.any()), "policies": int(no_amount.sum()), "claims": int(uniq.ClaimNb[no_amount].sum()),
        "claims_in_block": int(uniq.ClaimNb[no_amount & uniq_in_block].sum()),
        "claims_outside_block": int(uniq.ClaimNb[no_amount & ~uniq_in_block].sum())}
    for key in ("policies", "claims", "claims_in_block", "claims_outside_block"):
        reg.put(f"dq.claims_without_amount.{key}", out["claims_without_amount"][key], "count", src)
    # Where do the claims without an amount sit, outside the block? (the top region)
    by_region = uniq[no_amount & ~uniq_in_block].groupby("Region").ClaimNb.sum().sort_values(ascending=False)
    if len(by_region):
        out["claims_without_amount"]["top_region_outside_block"] = str(by_region.index[0])
        out["claims_without_amount"]["top_region_claims"] = int(by_region.iloc[0])
        reg.put("dq.claims_without_amount.top_region_outside_block", str(by_region.index[0]), "label", src)
        reg.put("dq.claims_without_amount.top_region_claims", int(by_region.iloc[0]), "count", src)
    orphan = int((~sev.IDpol.isin(freq.IDpol)).sum())
    out["amounts_without_policy"] = {"fired": orphan > 0, "rows": orphan}
    reg.put("dq.amounts_without_policy.rows", orphan, "count", src)

    # Rules 3-8: field ranges and duplicates.
    checks = {
        "exposure_above_one": freq.Exposure > r["exposure_cap"],
        "exposure_not_positive": freq.Exposure <= 0,
        "claimnb_above_cap": freq.ClaimNb > r["claimnb_cap"],
        "drivage_below_min": freq.DrivAge < r["drivage_min"],
        "vehage_above_max": freq.VehAge > r["vehage_max"],
        "exact_duplicates": freq.duplicated(keep="first"),
        "duplicate_idpol": freq.IDpol.duplicated(keep="first"),
    }
    for name, mask in checks.items():
        out[name] = {"fired": bool(mask.any()), "rows": int(mask.sum())}
        reg.put(f"dq.{name}.rows", int(mask.sum()), "count", src)
    out["exposure_above_one"]["max"] = float(freq.Exposure.max())
    reg.put("dq.exposure_above_one.max", float(freq.Exposure.max()), "number", src)
    out["claimnb_above_cap"]["max"] = int(freq.ClaimNb.max())
    reg.put("dq.claimnb_above_cap.max", int(freq.ClaimNb.max()), "count", src)
    out["vehage_above_max"]["max"] = int(freq.VehAge.max())
    out["vehage_above_max"]["rows_99_or_100"] = int(freq.VehAge.isin([99, 100]).sum())
    reg.put("dq.vehage_above_max.max", int(freq.VehAge.max()), "count", src)
    reg.put("dq.vehage_above_max.rows_99_or_100", out["vehage_above_max"]["rows_99_or_100"], "count", src)
    # Values above the threshold that occur at least 10 times look like codes rather than ages.
    counts = freq.VehAge[freq.VehAge > r["vehage_max"]].value_counts()
    codes = sorted(int(v) for v in counts[counts >= 10].index)
    reg.put("dq.vehage_above_max.code_values", " and ".join(str(v) for v in codes) or "none", "text", src)
    out["drivage_below_min"]["min"] = int(freq.DrivAge.min())
    for name, value in (("drivage_below_min.threshold", r["drivage_min"]), ("vehage_above_max.threshold", r["vehage_max"]),
                        ("claimnb_above_cap.threshold", r["claimnb_cap"])):
        reg.put(f"dq.{name}", value, "count", src)
    reg.put("dq.exposure_above_one.threshold", r["exposure_cap"], "number", src)

    # Rule 9: nominal levels whose frequency lies far from the portfolio's (outside the block, positive exposure).
    outliers = []
    base = rest
    pf = capped_freq(base)
    for factor in NOMINAL_FACTORS:
        g = base.assign(N=base.ClaimNb.clip(upper=r["claimnb_cap"]), E=base.Exposure.clip(upper=r["exposure_cap"]))
        t = g.groupby(factor).agg(N=("N", "sum"), E=("E", "sum"))
        t["rel"] = t.N / t.E / pf
        flagged = t[(t.E >= r["outlier_min_exposure"]) & ((t.rel >= r["outlier_high"]) | (t.rel <= r["outlier_low"]))]
        natural = t.drop(index=flagged.index)
        for level, row in flagged.iterrows():
            outliers.append({"factor": factor, "level": str(level), "relativity": float(row.rel), "exposure": float(row.E)})
            reg.put(f"dq.level_outliers.{factor}.{level}.relativity", float(row.rel), "relativity", src)
            reg.put(f"dq.level_outliers.{factor}.{level}.exposure", float(row.E), "exposure", src)
            reg.put(f"dq.level_outliers.{factor}.{level}.label", str(level), "label", src)
        reg.put(f"dq.level_outliers.{factor}.others_min_relativity", float(natural.rel.min()), "relativity", src)
        reg.put(f"dq.level_outliers.{factor}.others_max_relativity", float(natural.rel.max()), "relativity", src)
    out["level_outliers"] = {"fired": bool(outliers), "levels": outliers}

    # The claim-only block's effect on the portfolio frequency, isolated from the other issues: on the rows that
    # pass every other rule (duplicates once, exposure > 0, driver age >= 18, flagged levels left out), capped.
    # Without the block this is the frequency the analysis will have if the actuary accepts every default.
    clean = freq.drop_duplicates()
    clean = clean[(clean.Exposure > 0) & (clean.DrivAge >= r["drivage_min"])]
    for o in outliers:
        clean = clean[clean[o["factor"]].astype(str) != o["level"]]
    clean_in_block = clean.IDpol.between(first_id, last_id) if run_len >= r["block_min_run"] else pd.Series(False, index=clean.index)
    out["claim_only_block"]["frequency_with_block"] = capped_freq(clean)
    out["claim_only_block"]["frequency_without_block"] = capped_freq(clean[~clean_in_block])
    reg.put("dq.claim_only_block.frequency_with_block", out["claim_only_block"]["frequency_with_block"], "frequency", src)
    reg.put("dq.claim_only_block.frequency_without_block", out["claim_only_block"]["frequency_without_block"], "frequency", src)
    reg.put("dq.level_outliers.count", len(outliers), "count", src)
    reg.put("dq.level_outliers.low", r["outlier_low"], "relativity", src)
    reg.put("dq.level_outliers.high", r["outlier_high"], "relativity", src)
    reg.put("dq.level_outliers.min_exposure", r["outlier_min_exposure"], "count", src)

    reg.put("dq.delivered.policy_rows", len(freq), "count", src)
    reg.put("dq.delivered.amount_rows", len(sev), "count", src)
    return out


# ---- The analysis data: the actuary's decisions applied --------------------------------------------
DEFAULT_DECISIONS = {
    "claim_only_block": "exclude",      # the decision shown at plan approval (keep | exclude)
    "level_outliers": "exclude",        # flagged nominal levels (keep | exclude)
    "invalid_rows": "drop",             # exposure <= 0 or driver age below 18 (keep | drop)
    "exact_duplicates": "drop",         # keep the first copy (keep | drop)
    "exposure_above_one": "cap",        # cap at one year (keep | cap)
    "claimnb_above_cap": "cap",         # cap at four claims (keep | cap)
    "vehage_above_max": "keep",         # vehicle ages above 50 stay, in band 21+ (keep only)
}


def apply_decisions(freq: pd.DataFrame, sev: pd.DataFrame, scan: dict, decisions: dict,
                    reg: Registry) -> tuple[pd.DataFrame, list]:
    """Return the analysis table: one row per policy with level labels, capped exposure E, capped claims N,
    and the claim amounts linked by IDpol (sum and number of amount rows)."""
    d = freq.copy()
    steps = []
    if decisions["exact_duplicates"] == "drop":
        before = len(d); d = d.drop_duplicates(keep="first"); steps.append(("exact duplicates dropped", before - len(d)))
    if decisions["invalid_rows"] == "drop":
        bad = (d.Exposure <= 0) | (d.DrivAge < SCAN_RULES["drivage_min"])
        steps.append(("invalid rows dropped", int(bad.sum()))); d = d[~bad]
    if decisions["claim_only_block"] == "exclude" and scan["claim_only_block"]["fired"]:
        blk = d.IDpol.between(scan["claim_only_block"]["first_idpol"], scan["claim_only_block"]["last_idpol"])
        steps.append(("claim-only block excluded", int(blk.sum()))); d = d[~blk]
    if decisions["level_outliers"] == "exclude":
        for o in scan["level_outliers"]["levels"]:
            m = d[o["factor"]] == o["level"]
            steps.append((f"{o['factor']} {o['level']} excluded", int(m.sum()))); d = d[~m]
    d = d[d.Exposure > 0].copy() if decisions["invalid_rows"] == "keep" else d.copy()  # a frequency needs E > 0
    d["E"] = d.Exposure.clip(upper=SCAN_RULES["exposure_cap"]) if decisions["exposure_above_one"] == "cap" else d.Exposure
    d["N"] = d.ClaimNb.clip(upper=SCAN_RULES["claimnb_cap"]) if decisions["claimnb_above_cap"] == "cap" else d.ClaimNb
    amounts = sev.groupby("IDpol").ClaimAmount.agg(["sum", "size"])
    d["amount_sum"] = d.IDpol.map(amounts["sum"]).fillna(0.0)
    d["amount_rows"] = d.IDpol.map(amounts["size"]).fillna(0).astype(int)
    for factor in FACTOR_NAMES:
        d[f"lvl_{factor}"] = band(d, factor)
    d = d.reset_index(drop=True)
    src = "apply_decisions"
    reg.put("dec.claim_only_block", "excluded" if decisions["claim_only_block"] == "exclude" else "kept", "text", src)
    flagged = ", ".join(f"{o['factor']} {o['level']}" for o in scan["level_outliers"]["levels"]) or "none"
    reg.put("dec.level_outliers", ("excluded pending investigation: " if decisions["level_outliers"] == "exclude"
                                   else "kept and flagged: ") + flagged, "text", src)
    reg.put("dec.exposure_cap", SCAN_RULES["exposure_cap"], "number", src)
    reg.put("dec.claimnb_cap", SCAN_RULES["claimnb_cap"], "count", src)
    reg.put("dec.policies_analysed", len(d), "count", src)
    reg.put("dec.policies_removed", len(freq) - len(d), "count", src)
    counts = dict(steps)
    reg.put("dec.dropped_exact_duplicates", counts.get("exact duplicates dropped", 0), "count", src)
    reg.put("dec.dropped_invalid_rows", counts.get("invalid rows dropped", 0), "count", src)
    reg.put("dec.excluded_block_policies", counts.get("claim-only block excluded", 0), "count", src)
    reg.put("dec.excluded_outlier_policies",
            sum(n for a, n in steps if a.endswith(" excluded") and a != "claim-only block excluded"), "count", src)
    reg.put("meta.ci_level", "95%", "text", src)
    reg.put("meta.sev_ci_method", SEV_CI_METHOD, "text", src)
    return d, steps


# ---- Portfolio summary and one-way tables ----------------------------------------------------------
def poisson_ci(n: np.ndarray, e: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Exact (Garwood) 95% interval for a Poisson rate n/e. Claim counts capped at 4 are still integers."""
    n = np.asarray(n, dtype=float)
    lo = np.where(n > 0, stats.chi2.ppf(0.025, 2 * n) / 2, 0.0) / e
    hi = stats.chi2.ppf(0.975, 2 * n + 2) / 2 / e
    return lo, hi


SEV_CI_METHOD = ("log scale (delta method): mean x exp(-/+ 1.96 x SE / mean), SE = standard deviation / "
                 "square root of the number of amounts; the bounds cannot go below zero")


def severity_ci(mean, sd, n):
    """95% interval for a mean claim amount, computed on the log scale with the delta method:
    SE(log mean) ~ SE(mean) / mean, so the interval is mean / k to mean * k with k = exp(z * SE / mean).
    Unlike the normal interval mean -/+ z * SE it is never negative and it is wider above the mean than below,
    as the amounts are right-skewed. A level with a single amount has no interval (NaN)."""
    mean, sd, n = (np.asarray(x, dtype=float) for x in (mean, sd, n))
    with np.errstate(divide="ignore", invalid="ignore"):
        k = np.exp(Z95 * (sd / np.sqrt(n)) / mean)
    return mean / k, mean * k


def _amount_table(d: pd.DataFrame, sev: pd.DataFrame, keys: pd.Series | None) -> pd.DataFrame:
    """Per level: number of amount rows, their sum, mean and standard deviation (individual amounts)."""
    rows = sev[sev.IDpol.isin(d.IDpol)]
    if keys is None:
        grp = pd.Series("all", index=rows.index)
    else:
        lookup = pd.Series(keys.to_numpy(), index=d.IDpol.to_numpy())
        grp = rows.IDpol.map(lookup[~lookup.index.duplicated()])
    return rows.groupby(grp).ClaimAmount.agg(n="size", total="sum", mean="mean", sd="std")


def portfolio_summary(d: pd.DataFrame, sev: pd.DataFrame, reg: Registry) -> dict:
    E, N = d.E.sum(), d.N.sum()
    lo, hi = poisson_ci(np.array([N]), np.array([E]))
    amt = _amount_table(d, sev, None).iloc[0]
    res = {"policies": len(d), "exposure": E, "claims": N, "frequency": N / E, "freq_ci_low": lo[0],
           "freq_ci_high": hi[0], "amount_rows": amt.n, "total_amount": amt.total, "severity": amt.total / amt.n,
           "pure_premium": amt.total / E,
           "claims_without_amount": int(d.N[(d.N > 0) & (d.amount_rows == 0)].sum())}
    kinds = {"policies": "count", "exposure": "exposure", "claims": "count", "frequency": "frequency",
             "freq_ci_low": "frequency", "freq_ci_high": "frequency", "amount_rows": "count", "total_amount": "eur",
             "severity": "eur", "pure_premium": "eur2", "claims_without_amount": "count"}
    for k, v in res.items():
        reg.put(f"ps.{k}", v, kinds[k], "portfolio_summary")
    return res


OW_KINDS = {"policies": "count", "exposure": "exposure", "exposure_share": "share", "claims": "count",
            "frequency": "frequency", "freq_ci_low": "frequency", "freq_ci_high": "frequency", "relativity": "relativity",
            "amount_rows": "count", "severity": "eur", "sev_ci_low": "eur", "sev_ci_high": "eur", "pure_premium": "eur2"}


def one_way_table(d: pd.DataFrame, sev: pd.DataFrame, factor: str) -> pd.DataFrame:
    col = f"lvl_{factor}"
    g = d.groupby(col).agg(policies=("E", "size"), exposure=("E", "sum"), claims=("N", "sum"))
    order = [lab for lab in FACTORS[factor]["labels"] if lab in g.index]
    g = g.loc[order]
    pf = d.N.sum() / d.E.sum()
    g["exposure_share"] = g.exposure / g.exposure.sum()
    g["frequency"] = g.claims / g.exposure
    g["freq_ci_low"], g["freq_ci_high"] = poisson_ci(g.claims.to_numpy(), g.exposure.to_numpy())
    g["relativity"] = g.frequency / pf
    a = _amount_table(d, sev, d[col]).reindex(order)
    g["amount_rows"] = a.n.fillna(0).astype(int)
    g["severity"] = a.total / a.n
    g["sev_ci_low"], g["sev_ci_high"] = severity_ci(g.severity, a.sd, a.n)
    g["pure_premium"] = a.total.fillna(0.0) / g.exposure
    return g


def one_way(d: pd.DataFrame, sev: pd.DataFrame, factor: str, reg: Registry) -> dict:
    g = one_way_table(d, sev, factor)
    src = f"one_way({factor})"
    for level, row in g.iterrows():
        reg.put(f"ow_{factor}.{level}.label", str(level), "label", src)
        for k, kind in OW_KINDS.items():
            reg.put(f"ow_{factor}.{level}.{k}", row[k], kind, src)
    top, bottom = g.frequency.idxmax(), g.frequency.idxmin()
    reg.put(f"ow_{factor}.highest_frequency_level", str(top), "label", src)
    reg.put(f"ow_{factor}.lowest_frequency_level", str(bottom), "label", src)
    reg.put(f"ow_{factor}.frequency_spread", g.frequency.max() / g.frequency.min(), "relativity", src)
    sev_ok = g[g.amount_rows >= 30]  # severity ranks only among levels with at least 30 amounts
    if len(sev_ok):
        reg.put(f"ow_{factor}.highest_severity_level", str(sev_ok.severity.idxmax()), "label", src)
        reg.put(f"ow_{factor}.lowest_severity_level", str(sev_ok.severity.idxmin()), "label", src)
        reg.put(f"ow_{factor}.severity_spread", sev_ok.severity.max() / sev_ok.severity.min(), "relativity", src)
    return {"factor": factor, "table": g, "highest": str(top), "lowest": str(bottom)}


# ---- Poisson GLM on aggregated rating cells ---------------------------------------------------------
LR_TEST_LEVEL = 0.05  # significance level of the likelihood-ratio tests that check the analyst's factor choice


def base_level(d: pd.DataFrame, factor: str) -> str:
    """The reference level: the level with the largest exposure (ties: dictionary order)."""
    e = d.groupby(f"lvl_{factor}").E.sum()
    order = [lab for lab in FACTORS[factor]["labels"] if lab in e.index]
    return max(order, key=lambda lab: (e[lab], -order.index(lab)))


def _exp(x: float) -> float:
    # A level without any claim (possible only if the actuary keeps invalid rows) has an estimate near minus
    # infinity and a huge standard error; its interval then overflows. Report infinity, displayed as n/a.
    try:
        return math.exp(x)
    except OverflowError:
        return float("inf")


def _cells(d: pd.DataFrame, factors: list[str]) -> pd.DataFrame:
    """Claims and exposure summed per non-empty combination of the factors' levels."""
    if not factors:
        return pd.DataFrame({"N": [d.N.sum()], "E": [d.E.sum()]})
    return d.groupby([f"lvl_{f}" for f in factors], observed=True).agg(N=("N", "sum"), E=("E", "sum")).reset_index()


def _design(cells: pd.DataFrame, factors: list[str], bases: dict) -> tuple[sparse.csr_matrix, list[str]]:
    """Sparse design matrix: an intercept and one indicator column per non-base level present in the cells."""
    n = len(cells)
    rows, cols, names = [np.arange(n)], [np.zeros(n, dtype=int)], ["const"]
    for f in factors:
        present = set(cells[f"lvl_{f}"])
        for lab in FACTORS[f]["labels"]:
            if lab != bases[f] and lab in present:
                idx = np.flatnonzero((cells[f"lvl_{f}"] == lab).to_numpy())
                rows.append(idx)
                cols.append(np.full(len(idx), len(names)))
                names.append(f"{f}={lab}")
    r, c = np.concatenate(rows), np.concatenate(cols)
    return sparse.csr_matrix((np.ones(len(r)), (r, c)), shape=(n, len(names))), names


def _poisson_newton(X: sparse.csr_matrix, y: np.ndarray, log_e: np.ndarray, max_iter: int = 100) -> dict:
    """Maximum likelihood for a Poisson GLM with log link and offset log(exposure), by Newton-Raphson
    (for the canonical link this is the same as IRLS) with step halving. Returns the estimates, their
    covariance (inverse Fisher information, as statsmodels reports it) and the log-likelihood kernel
    sum(y * x'b - E * exp(x'b)). The kernel differs from the row-level log-likelihood only by a constant that
    does not depend on the model, so kernels of models fitted on different cell aggregations can be compared."""
    beta = np.zeros(X.shape[1])
    beta[0] = math.log(y.sum() / np.exp(log_e).sum())

    def kernel(b):
        xb = X @ b
        return float(y @ xb - np.exp(xb + log_e).sum()), xb
    ll, xb = kernel(beta)
    converged, it = False, 0
    for it in range(1, max_iter + 1):
        mu = np.exp(xb + log_e)
        info = (X.T @ sparse.diags(mu) @ X).toarray()
        step = np.linalg.solve(info, X.T @ (y - mu))
        t = 1.0
        while True:
            new_ll, new_xb = kernel(beta + t * step)
            if new_ll >= ll - 1e-12 * abs(ll) or t < 1e-6:
                break
            t /= 2
        beta, xb = beta + t * step, new_xb
        change, ll = new_ll - ll, new_ll
        if np.max(np.abs(t * step)) < 1e-10 or abs(change) < 1e-13 * (abs(ll) + 1.0):
            converged = True
            break
    mu = np.exp(xb + log_e)
    info = (X.T @ sparse.diags(mu) @ X).toarray()
    return {"beta": beta, "cov": np.linalg.inv(info), "kernel": ll, "iterations": it, "converged": converged}


def _fit(d: pd.DataFrame, factors: list[str], bases: dict) -> dict:
    cells = _cells(d, factors)
    X, names = _design(cells, factors, bases)
    res = _poisson_newton(X, cells.N.to_numpy(dtype=float), np.log(cells.E.to_numpy(dtype=float)))
    return {**res, "names": names, "cells": len(cells), "parameters": len(names)}


def fit_poisson_glm(d: pd.DataFrame, factors: list[str], reg: Registry, gid: str) -> dict:
    """Claims ~ factors with offset log(exposure). Summing claims and exposure per combination of levels
    gives the same maximum-likelihood estimates and standard errors as the row-level fit (checked against a
    row-level statsmodels fit in ground_truth.py)."""
    bases = {f: base_level(d, f) for f in factors}
    fit = _fit(d, factors, bases)
    params = dict(zip(fit["names"], fit["beta"]))
    bse = dict(zip(fit["names"], np.sqrt(np.diag(fit["cov"]))))
    src = f"fit_poisson_glm({', '.join(factors)})"
    reg.put(f"{gid}.cells", fit["cells"], "count", src)
    reg.put(f"{gid}.parameters", fit["parameters"], "count", src)
    reg.put(f"{gid}.factors", ", ".join(factors), "text", src)
    out = {"gid": gid, "factors": factors, "bases": bases, "relativities": {}, "fit": fit}
    for f in factors:
        reg.put(f"{gid}.{f}.base_level", bases[f], "label", src)
        rels = {bases[f]: (1.0, 1.0, 1.0)}
        for lab in FACTORS[f]["labels"]:
            name = f"{f}={lab}"
            if name in params:
                b, se = params[name], bse[name]
                rels[lab] = (_exp(b), _exp(b - Z95 * se), _exp(b + Z95 * se))
        for lab, (rel, lo, hi) in rels.items():
            reg.put(f"{gid}.{f}.{lab}.relativity", rel, "relativity", src)
            reg.put(f"{gid}.{f}.{lab}.ci_low", lo, "relativity", src)
            reg.put(f"{gid}.{f}.{lab}.ci_high", hi, "relativity", src)
        top = max(rels, key=lambda k: rels[k][0])
        bottom = min(rels, key=lambda k: rels[k][0])
        reg.put(f"{gid}.{f}.highest_relativity_level", top, "label", src)
        reg.put(f"{gid}.{f}.lowest_relativity_level", bottom, "label", src)
        reg.put(f"{gid}.{f}.relativity_spread", rels[top][0] / rels[bottom][0], "relativity", src)
        out["relativities"][f] = rels
    return out


def _lr(big: dict, small: dict, n_policies: int) -> dict:
    stat = max(0.0, 2.0 * (big["kernel"] - small["kernel"]))
    df = big["parameters"] - small["parameters"]
    return {"statistic": stat, "df": df, "p_value": float(stats.chi2.sf(stat, df)),
            "log_p": float(stats.chi2.logsf(stat, df)), "bic_gain": stat - df * math.log(n_policies)}


def lr_summary(chosen: list[str], supported: list[str], strongest: str | None, strongest_test: dict | None) -> str:
    """One sentence, built by code, on what the likelihood-ratio tests say about the chosen factor set."""
    level = f"{100 * LR_TEST_LEVEL:.0f}%"
    text = f"at the {level} level the tests support {len(supported)} of {len(chosen)} chosen factors"
    weak = [f for f in chosen if f not in supported]
    if weak:
        text += " (not supported: " + ", ".join(weak) + ")"
    if strongest is None:
        return text + "; no factor was left out"
    t = strongest_test
    text += (f"; of the left-out factors, adding {strongest} would change the fit most "
             f"(LR {fmt(t['statistic'], 'stat')} on {t['df']} df, {fmt(t['p_value'], 'pvalue')}), which is "
             + ("significant, so the tests disagree with leaving it out" if t["p_value"] < LR_TEST_LEVEL
                else "not significant, so the tests agree with leaving it out")
             + ("; BIC also prefers adding it" if t["bic_gain"] > 0 else "; BIC prefers leaving it out"))
    return text


def check_glm_choice(d: pd.DataFrame, glm: dict, reg: Registry) -> dict:
    """Test the analyst's factor choice with likelihood-ratio tests on the same analysis data:
      - each chosen factor: the chosen model against the model without that factor (a drop test);
      - each left-out factor of the data dictionary: the chosen model plus that factor against the chosen model
        (an add test); the left-out factor with the smallest p-value is the strongest excluded factor.
    Each model is fitted on its own rating cells; the likelihood-ratio statistic is twice the difference of the
    log-likelihood kernels, which equals the row-level deviance difference. Registers everything under
    <gid>.lr.* and returns a JSON-safe summary for the run log."""
    gid, chosen, full = glm["gid"], list(glm["factors"]), glm["fit"]
    n = len(d)
    bases = {f: base_level(d, f) for f in FACTOR_NAMES}
    src = f"check_glm_choice({gid})"
    drops, adds = {}, {}
    for f in chosen:
        drops[f] = _lr(full, _fit(d, [g for g in chosen if g != f], bases), n)
    for g in [f for f in FACTOR_NAMES if f not in chosen]:
        adds[g] = _lr(_fit(d, chosen + [g], bases), full, n)
    level = f"{100 * LR_TEST_LEVEL:.0f}%"
    reg.put(f"{gid}.lr.level", level, "text", src)
    reg.put(f"{gid}.lr.policies", n, "count", src)
    for kind_, tests in (("drop", drops), ("add", adds)):
        for f, t in tests.items():
            p = f"{gid}.lr.{kind_}.{f}."
            reg.put(p + "statistic", t["statistic"], "stat", src)
            reg.put(p + "df", t["df"], "count", src)
            reg.put(p + "p_value", t["p_value"], "pvalue", src)
            reg.put(p + "bic_gain", t["bic_gain"], "stat", src)
            significant = t["p_value"] < LR_TEST_LEVEL
            if kind_ == "drop":
                verdict = (f"supported: dropping it worsens the fit significantly at the {level} level" if significant
                           else f"not supported: dropping it does not worsen the fit significantly at the {level} level")
            else:
                verdict = (f"adding it would improve the fit significantly at the {level} level" if significant
                           else f"adding it would not improve the fit significantly at the {level} level")
            reg.put(p + "verdict", verdict, "text", src)
    supported = [f for f in chosen if drops[f]["p_value"] < LR_TEST_LEVEL]
    strongest = (min(adds, key=lambda g: (adds[g]["log_p"], -adds[g]["statistic"], FACTOR_NAMES.index(g)))
                 if adds else None)
    reg.put(f"{gid}.lr.chosen_count", len(chosen), "count", src)
    reg.put(f"{gid}.lr.chosen_supported", len(supported), "count", src)
    reg.put(f"{gid}.lr.excluded_count", len(adds), "count", src)
    reg.put(f"{gid}.lr.excluded_significant", sum(t["p_value"] < LR_TEST_LEVEL for t in adds.values()), "count", src)
    reg.put(f"{gid}.lr.strongest_excluded.factor", strongest or "none", "label", src)
    if strongest:
        for k, kind_ in (("statistic", "stat"), ("df", "count"), ("p_value", "pvalue"), ("bic_gain", "stat")):
            reg.put(f"{gid}.lr.strongest_excluded.{k}", adds[strongest][k], kind_, src)
        reg.put(f"{gid}.lr.strongest_excluded.verdict", reg.entries[f"{gid}.lr.add.{strongest}.verdict"]["value"],
                "text", src)
    agrees = len(supported) == len(chosen) and (strongest is None or adds[strongest]["p_value"] >= LR_TEST_LEVEL)
    reg.put(f"{gid}.lr.agreement", "agrees with the analyst's choice" if agrees else "disagrees with the analyst's choice",
            "text", src)
    summary = lr_summary(chosen, supported, strongest, adds.get(strongest) if strongest else None)
    reg.put(f"{gid}.lr.summary", summary, "text", src)

    def clean(t):
        return {k: v for k, v in t.items() if k != "log_p"}
    return {"gid": gid, "chosen": chosen, "drops": {f: clean(t) for f, t in drops.items()},
            "adds": {g: clean(t) for g, t in adds.items()}, "strongest_excluded": strongest,
            "supported": supported, "agrees": agrees, "summary": summary}


# ---- Largest claims --------------------------------------------------------------------------------
def largest_claims(d: pd.DataFrame, sev: pd.DataFrame, n: int, reg: Registry) -> dict:
    n = int(max(1, min(n, 20)))
    rows = sev[sev.IDpol.isin(d.IDpol)].merge(d[["IDpol", "lvl_VehAge", "lvl_DrivAge", "Region"]], on="IDpol")
    rows = rows.sort_values(["ClaimAmount", "IDpol"], ascending=[False, True]).reset_index(drop=True)
    total = rows.ClaimAmount.sum()
    src = f"largest_claims({n})"
    for i in range(min(n, len(rows))):
        r = rows.iloc[i]
        reg.put(f"lc.{i + 1}.amount", r.ClaimAmount, "eur", src)
        reg.put(f"lc.{i + 1}.VehAge", r.lvl_VehAge, "label", src)
        reg.put(f"lc.{i + 1}.DrivAge", r.lvl_DrivAge, "label", src)
        reg.put(f"lc.{i + 1}.Region", r.Region, "label", src)
    reg.put("lc.n", n, "count", src)
    reg.put("lc.top_n_share", rows.ClaimAmount.head(n).sum() / total, "share", src)
    reg.put("lc.share_above_threshold", rows.ClaimAmount[rows.ClaimAmount >= 100_000].sum() / total, "share", src)
    reg.put("lc.threshold", 100_000, "eur", src)
    reg.put("lc.count_above_threshold", int((rows.ClaimAmount >= 100_000).sum()), "count", src)
    reg.put("lc.median_amount", rows.ClaimAmount.median(), "eur", src)
    reg.put("lc.amount_rows", len(rows), "count", src)
    return {"n": n, "top": rows.head(n)}


# ---- The typed hypothesis checker ------------------------------------------------------------------
METRICS = ["frequency", "severity", "pure_premium"]
RELATIONS = ["highest", "lowest", "above_portfolio", "below_portfolio", "higher_than", "lower_than"]


def validate_spec(spec: dict) -> list[str]:
    """Problems with a typed statement, as plain messages (empty list = valid)."""
    problems = []
    f = spec.get("factor")
    if f not in FACTORS:
        return [f"unknown factor {f!r}; use one of {FACTOR_NAMES}"]
    labels = FACTORS[f]["labels"]
    levels, others = spec.get("levels") or [], spec.get("other_levels") or []
    if not levels:
        problems.append("levels is empty")
    bad = [lv for lv in levels + others if lv not in labels]
    if bad:
        problems.append(f"unknown level(s) {bad} for {f}; valid: {labels}")
    if spec.get("metric") not in METRICS:
        problems.append(f"metric must be one of {METRICS}")
    rel = spec.get("relation")
    if rel not in RELATIONS:
        problems.append(f"relation must be one of {RELATIONS}")
    if rel in ("higher_than", "lower_than") and not others:
        problems.append(f"relation {rel} needs other_levels")
    if set(levels) & set(others):
        problems.append("levels and other_levels overlap")
    return problems


def group_metric(d: pd.DataFrame, sev: pd.DataFrame, factor: str, groups: dict[str, list[str]], metric: str) -> pd.DataFrame:
    """Metric per group, where each group merges one or more level labels."""
    col = f"lvl_{factor}"
    lab_to_group = {lab: g for g, labs in groups.items() for lab in labs}
    key = d[col].map(lab_to_group)
    sub = d[key.notna()]
    k = key[key.notna()]
    t = sub.groupby(k).agg(exposure=("E", "sum"), claims=("N", "sum"))
    a = _amount_table(sub, sev, k)
    t["amount_rows"] = a.n.reindex(t.index).fillna(0)
    t["amount_total"] = a.total.reindex(t.index).fillna(0.0)
    if metric == "frequency":
        t["value"] = t.claims / t.exposure
        t["ci_low"], t["ci_high"] = poisson_ci(t.claims.to_numpy(), t.exposure.to_numpy())
    elif metric == "severity":
        t["value"] = t.amount_total / t.amount_rows
        t["ci_low"], t["ci_high"] = severity_ci(t.value, a.sd.reindex(t.index), t.amount_rows)
    else:
        t["value"] = t.amount_total / t.exposure
        t["ci_low"] = t["ci_high"] = np.nan
    return t


METRIC_KIND = {"frequency": "frequency", "severity": "eur", "pure_premium": "eur2"}


def check_hypothesis(d: pd.DataFrame, sev: pd.DataFrame, spec: dict, hid: str, reg: Registry,
                     statement: str | None = None) -> dict:
    """Decide a typed statement TRUE or FALSE. The named levels are merged into one group; the other levels
    of the factor stay as they are (or are merged into one comparison group for higher_than/lower_than)."""
    problems = validate_spec(spec)
    if problems:
        return {"id": hid, "error": "; ".join(problems)}
    f, metric, rel = spec["factor"], spec["metric"], spec["relation"]
    labels = [lab for lab in FACTORS[f]["labels"] if lab in set(d[f"lvl_{f}"])]
    group_name = " + ".join(spec["levels"])
    if rel in ("higher_than", "lower_than"):
        groups = {group_name: spec["levels"], " + ".join(spec["other_levels"]): spec["other_levels"]}
    else:
        groups = {group_name: spec["levels"]} | {lab: [lab] for lab in labels if lab not in spec["levels"]}
    t = group_metric(d, sev, f, groups, metric)
    g = t.loc[group_name]
    all_rows = group_metric(d, sev, f, {"all": labels}, metric).loc["all"]
    portfolio = all_rows.value
    others = t.drop(index=group_name)
    if rel == "highest":
        comp = others.value.idxmax(); verdict = bool(g.value > others.value.max())
    elif rel == "lowest":
        comp = others.value.idxmin(); verdict = bool(g.value < others.value.min())
    elif rel == "above_portfolio":
        comp = "portfolio"; verdict = bool(g.value > portfolio)
    elif rel == "below_portfolio":
        comp = "portfolio"; verdict = bool(g.value < portfolio)
    else:
        comp = others.index[0]
        verdict = bool(g.value > others.value.iloc[0]) if rel == "higher_than" else bool(g.value < others.value.iloc[0])
    comp_value = portfolio if comp == "portfolio" else others.value[comp]
    ranked = t.value.sort_values(ascending=False)
    src = f"check_hypothesis({hid})"
    reg.put(f"{hid}.verdict", "SUPPORTED by the data" if verdict else "NOT SUPPORTED by the data", "verdict", src)
    if statement is not None:
        reg.put(f"{hid}.statement", statement, "text", src)
    reg.put(f"{hid}.group_label", group_name, "label", src)
    reg.put(f"{hid}.group_value", g.value, METRIC_KIND[metric], src)
    if metric != "pure_premium":
        reg.put(f"{hid}.group_ci_low", g.ci_low, METRIC_KIND[metric], src)
        reg.put(f"{hid}.group_ci_high", g.ci_high, METRIC_KIND[metric], src)
    reg.put(f"{hid}.comparator_label", comp, "label", src)
    reg.put(f"{hid}.comparator_value", comp_value, METRIC_KIND[metric], src)
    reg.put(f"{hid}.portfolio_value", portfolio, METRIC_KIND[metric], src)
    reg.put(f"{hid}.ratio_to_portfolio", g.value / portfolio, "relativity", src)
    reg.put(f"{hid}.rank", int(list(ranked.index).index(group_name)) + 1, "count", src)
    reg.put(f"{hid}.groups", len(t), "count", src)
    return {"id": hid, "verdict": "TRUE" if verdict else "FALSE", "factor": f, "metric": metric, "relation": rel,
            "group": group_name, "group_value": float(g.value), "comparator": comp, "comparator_value": float(comp_value),
            "portfolio_value": float(portfolio), "rank": int(list(ranked.index).index(group_name)) + 1,
            "groups": len(t)}


# ---- Rankings across factors -----------------------------------------------------------------------
def update_rankings(reg: Registry) -> None:
    """Order the factors analysed so far by their one-way frequency and severity spreads, and by their spread in
    each GLM, so that "the widest spread" or "the strongest association" can cite a ranking computed by code."""
    for metric in ("frequency_spread", "severity_spread"):
        spreads = {f: reg.entries[f"ow_{f}.{metric}"]["value"] for f in FACTOR_NAMES if f"ow_{f}.{metric}" in reg}
        order = sorted(spreads, key=lambda f: (-spreads[f], FACTOR_NAMES.index(f)))
        for k, f in enumerate(order, start=1):
            reg.put(f"ranking.{metric}.{k}", f, "label", "update_rankings")
        reg.put(f"ranking.{metric}.factors", ", ".join(order), "text", "update_rankings")
    gids = sorted({rid.split(".")[0] for rid in reg.entries if re.match(r"^glm\d+\.cells$", rid)})
    for gid in gids:
        factors = reg.entries[f"{gid}.factors"]["value"].split(", ")
        spreads = {f: reg.entries[f"{gid}.{f}.relativity_spread"]["value"] for f in factors}
        order = sorted(spreads, key=lambda f: (-spreads[f], FACTOR_NAMES.index(f)))
        for k, f in enumerate(order, start=1):
            reg.put(f"ranking.{gid}.relativity_spread.{k}", f, "label", "update_rankings")
