"""Part B: the agent loop of section 4 (run_agent), extended for structured outputs.

Part B's agents answer in JSON that a schema fixes (text_format), so this loop also parses the answer and
returns the conversation (transcript), which the analyst node continues. Everything else is as in section
4: store=False on every call; the cost ceiling is checked BEFORE every call (worst case = estimated input
tokens x input price + max_output_tokens x output price; a call that could break the run cap or the
session cap is refused); every call is booked (tokens incl. cached tokens, cache writes and reasoning
tokens, USD, seconds); it never raises and returns a status: ok, no_credit, api_error, over_budget,
max_rounds.

The notebook configures it with its own client, its ledger (book = log_usage), its caps and its
session_cost(): configure(client=..., book=..., run_cap_usd=..., session_cap_usd=..., session_cost=...).
"""
from __future__ import annotations

import json
import threading
import time
from datetime import datetime, timezone

import openai

# ---- Models, efforts, prices (as in the notebook's setup cell) ----------------------------------------
SOL, LUNA = "gpt-6-sol", "gpt-6-luna"
EFFORT = {SOL: "low", LUNA: "none"}
TEMPERATURE = 0  # accepted only at effort "none"
# USD per 1M tokens, standard processing, retrieved 22 September 2026: input, cached input, cache write, output.
PRICES = {LUNA: (0.10, 0.01, 0.125, 0.50), SOL: (2.00, 0.20, 2.50, 10.00)}

CONFIG = {"client": None, "book": None, "run_cap_usd": 0.40, "session_cap_usd": 1.00, "session_cost": None,
          "purpose": "Part B"}


def configure(**settings) -> None:
    """client, book (the notebook's log_usage), run_cap_usd, session_cap_usd, session_cost, purpose."""
    unknown = set(settings) - set(CONFIG)
    if unknown:
        raise KeyError(f"unknown settings: {sorted(unknown)}")
    CONFIG.update(settings)


def sampling_options(effort: str) -> dict:
    # GPT-6 accepts a temperature only at reasoning effort "none"; at any other effort it is left out.
    options = {"reasoning": {"effort": effort}}
    if effort == "none":
        options["temperature"] = TEMPERATURE
    return options


# ---- Ledger (per call, for the run cap; the notebook's LEDGER gets one row per call through `book`) --------
LEDGER: list[dict] = []
_LOCK = threading.Lock()


def session_cost() -> float:
    if CONFIG["session_cost"] is not None:
        return CONFIG["session_cost"]()
    return sum(r["usd"] for r in LEDGER)


def run_cost(run_id: str) -> float:
    return sum(r["usd"] for r in LEDGER if r["run_id"] == run_id)


def usage_row(model: str, usage) -> dict:
    """Tokens and cost of one response. cache_write_tokens is typed in openai 3.x and an untyped extra field
    in 2.x; if neither is present it counts as 0."""
    details = getattr(usage, "input_tokens_details", None)
    cached = (getattr(details, "cached_tokens", 0) or 0) if details else 0
    cache_write = getattr(details, "cache_write_tokens", None) if details else None
    if cache_write is None and details is not None:
        cache_write = (getattr(details, "model_extra", None) or {}).get("cache_write_tokens", 0)
    cache_write = cache_write or 0
    out_details = getattr(usage, "output_tokens_details", None)
    reasoning = (getattr(out_details, "reasoning_tokens", 0) or 0) if out_details else 0
    p_in, p_cached, p_write, p_out = PRICES[model]
    ordinary = usage.input_tokens - cached - cache_write
    usd = (ordinary * p_in + cached * p_cached + cache_write * p_write + usage.output_tokens * p_out) / 1e6
    # Comparison figure: every input token at the ordinary input price (no caching at all).
    usd_no_cache = (usage.input_tokens * p_in + usage.output_tokens * p_out) / 1e6
    return {"input_tokens": usage.input_tokens, "cached_tokens": cached, "cache_write_tokens": cache_write,
            "output_tokens": usage.output_tokens, "reasoning_tokens": reasoning, "usd": usd, "usd_no_cache": usd_no_cache}


def estimate_tokens(payload) -> int:
    """Rough input size for the pre-call check (o200k tokeniser if available, else characters / 3)."""
    text = json.dumps(payload, ensure_ascii=False, default=str)
    try:
        import tiktoken
        return len(tiktoken.get_encoding("o200k_base").encode(text))
    except Exception:
        return len(text) // 3


def dump_items(output) -> list[dict]:
    """Output items as plain dicts for the next request. by_alias=True because openai 3.x has alias fields
    (e.g. `async_` -> `async`); reasoning items keep their encrypted content, which store=False needs."""
    items = []
    for it in output:
        d = it.model_dump(by_alias=True, exclude_none=True)
        d.pop("parsed_arguments", None)
        items.append(d)
    return items


def _short(value, limit: int = 300) -> str:
    text = value if isinstance(value, str) else json.dumps(value, ensure_ascii=False, default=str)
    return text if len(text) <= limit else text[:limit] + f"... [{len(text) - limit} more characters]"


# ---- The agent loop --------------------------------------------------------------------------------
def run_agent(*, run_id: str, agent: str, model: str, instructions: str, input_items: list,
              tools: list | None = None, dispatch: dict | None = None, text_format: dict | None = None,
              max_output_tokens: int = 3000, max_tool_rounds: int = 1, parallel_tool_calls: bool = True,
              tool_choice=None, effort: str | None = None) -> dict:
    """Run one agent to completion. Returns {status, output_text, parsed, calls, tool_calls, usd, seconds, error,
    transcript}; transcript = the input items plus every output item, so that a caller can continue the conversation."""
    effort = effort or EFFORT[model]
    items = list(input_items)
    result = {"agent": agent, "model": model, "effort": effort, "status": "ok", "output_text": None, "parsed": None,
              "calls": [], "tool_calls": [], "usd": 0.0, "seconds": 0.0, "error": None, "transcript": items}
    t_start = time.time()
    client = CONFIG["client"]
    if client is None:
        result.update(status="no_credit", error="no OPENAI_API_KEY visible")
        return result
    p_in, _, _, p_out = PRICES[model]
    run_cap, session_cap = CONFIG["run_cap_usd"], CONFIG["session_cap_usd"]
    for round_no in range(max_tool_rounds + 1):
        # 1. Cost ceiling, checked before the call.
        est_in = estimate_tokens([instructions, items, tools, text_format])
        worst = (est_in * p_in + max_output_tokens * p_out) / 1e6
        if run_cost(run_id) + worst > run_cap or session_cost() + worst > session_cap:
            result.update(status="over_budget", error=(f"refused before the call: worst case USD {worst:.4f}; run so far "
                                                        f"{run_cost(run_id):.4f} (cap {run_cap}); session "
                                                        f"{session_cost():.4f} (cap {session_cap})"))
            break
        kwargs = dict(model=model, instructions=instructions, input=items, store=False,
                      max_output_tokens=max_output_tokens, include=["reasoning.encrypted_content"],
                      **sampling_options(effort))
        if tools:
            kwargs.update(tools=tools, parallel_tool_calls=parallel_tool_calls)
            # A forced tool choice applies to the first round only; afterwards the model may answer.
            if tool_choice is not None and round_no == 0:
                kwargs["tool_choice"] = tool_choice
        if text_format:
            kwargs["text"] = {"format": text_format}
        # 2. The call.
        t0 = time.time()
        try:
            response = client.responses.create(**kwargs)
        except openai.RateLimitError as exc:
            code = getattr(exc, "code", None) or (getattr(exc, "body", None) or {}).get("code")
            status = "no_credit" if code == "insufficient_quota" or "insufficient_quota" in str(exc) else "api_error"
            result.update(status=status, error=f"{type(exc).__name__}: {str(exc)[:200]}")
            break
        except openai.AuthenticationError as exc:   # missing, wrong or revoked key
            result.update(status="no_credit", error=f"{type(exc).__name__}: {str(exc)[:200]}")
            break
        except Exception as exc:  # returned as data, never raised
            result.update(status="api_error", error=f"{type(exc).__name__}: {str(exc)[:200]}")
            break
        seconds = round(time.time() - t0, 2)
        # 3. Book the call: here for the run cap, and in the notebook's ledger.
        row = {"run_id": run_id, "agent": agent, "model": model, "resolved_model": response.model, "effort": effort,
               "round": round_no, "seconds": seconds, "est_input_tokens": est_in, "worst_case_usd": round(worst, 6),
               "ts_utc": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"), "response_status": response.status,
               **usage_row(model, response.usage)}
        with _LOCK:
            LEDGER.append(row)
        if CONFIG["book"] is not None:
            CONFIG["book"](model, CONFIG["purpose"], row["input_tokens"], row["cached_tokens"], row["output_tokens"],
                           cache_write_tokens=row["cache_write_tokens"])
        result["calls"].append(row)
        # 4. Run the requested tools, if any, and loop.
        calls = [it for it in response.output if it.type == "function_call"]
        if not calls:
            items += dump_items(response.output)
            result["output_text"] = response.output_text
            if response.status == "incomplete":
                text = response.output_text or ""
                result.update(status="api_error", error=f"incomplete response: {response.incomplete_details}",
                              incomplete_head=text[:600], incomplete_tail=text[-600:])
            break
        if round_no == max_tool_rounds:
            result.update(status="max_rounds", error=f"still calling tools after {max_tool_rounds} rounds")
            break
        items += dump_items(response.output)
        for call in calls:
            try:
                args = json.loads(call.arguments)
                output = dispatch[call.name](args)
            except Exception as exc:  # a tool error goes back to the model as data
                args, output = call.arguments, f"ERROR: {type(exc).__name__}: {exc}"
            result["tool_calls"].append({"round": round_no, "name": call.name, "arguments": args,
                                         "result": _short(output, 600)})
            items.append({"type": "function_call_output", "call_id": call.call_id,
                          "output": output if isinstance(output, str) else json.dumps(output, default=str)})
    result["usd"] = round(sum(c["usd"] for c in result["calls"]), 6)
    result["seconds"] = round(time.time() - t_start, 2)
    if result["status"] == "ok" and text_format and result["output_text"]:
        try:
            result["parsed"] = json.loads(result["output_text"])
        except json.JSONDecodeError as exc:
            result.update(status="api_error", error=f"output is not valid JSON: {exc}")
    return result
