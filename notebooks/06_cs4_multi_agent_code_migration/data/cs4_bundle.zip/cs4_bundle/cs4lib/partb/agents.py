"""Part B: the verification gate, the nodes of the graph, the recording and the replay.

    profile (code) -> planner (Sol) -> approve_plan (actuary) -> analyst (Luna) -> writer (Luna)
      -> gate (code) -> fact_checker (Sol, advisory) -> sign_off (actuary)
    with up to 2 revisions: gate failure or checker notes send the draft back to the writer.

The notebook holds the four agents' prompts and models and builds the graph from the nodes below
(section 9); it hands them over with configure(prompts=..., models=..., approve_plan=..., sign_off=...,
decisions=...). The analyst's judgement: after the one-way tables it proposes the factor set of the
frequency GLM with a reason per factor; code fits that GLM and tests the choice (likelihood-ratio tests),
and the result goes into the registry, where the writer may cite it.

Routing is decided by code, never by a model. The LangGraph state holds JSON only (plans, drafts, logs,
registry IDs); the data, the analysis table and the results registry sit outside it in RUNTIME.
"""
from __future__ import annotations

import difflib
import hashlib
import json
import re
import time
from pathlib import Path
from typing import TypedDict

from . import llm
from .data import FACTORS, FACTOR_NAMES, load_raw, plant_issues
from .tools import (DEFAULT_DECISIONS, LR_TEST_LEVEL, METRICS, RELATIONS, SCAN_RULES, SEV_CI_METHOD, Registry,
                    apply_decisions, check_glm_choice, check_hypothesis, data_quality_scan, fit_poisson_glm,
                    largest_claims, one_way, portfolio_summary, update_rankings, validate_spec)

# ---- Set by the notebook (configure) -------------------------------------------------------------------
CONFIG = {
    "prompts": {},                                     # planner, analyst, writer, fact_checker
    "models": {"planner": llm.SOL, "analyst": llm.LUNA, "writer": llm.LUNA, "fact_checker": llm.SOL},
    "approve_plan": True,        # the actuary approves the plan (Run-all-safe default)
    "sign_off": True,            # the actuary signs off a report that passed the gate
    "decisions": dict(DEFAULT_DECISIONS),  # the actuary's treatments, shown at plan approval
    "print": print,              # where the live printout goes
}
MAX_REVISIONS = 2
MAX_FOLLOW_UPS = 3
MAX_CHECKER_CALLS = 2


def configure(**settings) -> None:
    unknown = set(settings) - set(CONFIG)
    if unknown:
        raise KeyError(f"unknown settings: {sorted(unknown)}")
    for key, value in settings.items():
        CONFIG[key] = dict(value) if isinstance(value, dict) else value


def _prompt(agent: str) -> str:
    if agent not in CONFIG["prompts"]:
        raise RuntimeError(f"no prompt for the {agent} agent: call configure(prompts=...) first")
    return CONFIG["prompts"][agent]


STATEMENTS = {
    "S1": "Vehicles over 15 years old have the highest claim frequency.",  # planted: false in the data
    "S2": "Drivers aged 18-20 have the highest claim frequency.",          # control: true in the data
}
BRIEF = (
    "Business question: which rating factors drive claim frequency and claim severity in this French motor "
    "third-party liability portfolio (freMTPL2freq, with the claim amounts in freMTPL2sev), and do the statements "
    "from last year's review still hold?\n\n"
    "Last year's review found:\n"
    + "".join(f'- {sid}: "{text}"\n' for sid, text in STATEMENTS.items())
    + "\nDeliverable: a short report for the pricing committee with the data-quality findings and the treatments "
    "applied, the main frequency and severity drivers (one-way views and a Poisson GLM for frequency), and a "
    "verdict on each statement from last year's review."
)

# Everything that is not JSON lives here, keyed by run id.
RUNTIME: dict[str, dict] = {}
DATA: dict = {}  # raw, delivered and severity tables, loaded once per process


def load_data(cache_dir: Path, reuse: dict | None = None) -> dict:
    if not DATA:
        freq, sev, provenance = load_raw(cache_dir, reuse)
        delivered, planted = plant_issues(freq)
        DATA.update(raw=freq, sev=sev, delivered=delivered, planted=planted, provenance=provenance)
    return DATA


# ---- Text the agents see ---------------------------------------------------------------------------
def dictionary_text() -> str:
    return "\n".join(f"- {f}: {spec['description']}; levels: {', '.join(spec['labels'])}" for f, spec in FACTORS.items())


TOOL_CATALOGUE = """Tools the analyst can run (deterministic code; every result is stored in a registry with IDs):
- portfolio_summary(): policies, exposure, claims, frequency with 95% CI, severity (mean claim amount), pure premium.
- one_way(factor): per level of one factor: exposure, claims, frequency with 95% CI, relativity to the portfolio,
  severity with 95% CI (log scale), pure premium.
- fit_poisson_glm(factors): Poisson GLM for claim counts with a log-exposure offset; relativities with 95% CIs
  against the level with the most exposure. The ANALYST chooses the factor set after reading the one-way views
  (with a reason per factor), and code tests the choice with likelihood-ratio tests. There is no severity GLM.
- largest_claims(n): the n largest claim amounts (n <= 20) and their share of all amounts.
- check_hypothesis(hypothesis_id): decides one typed hypothesis of the plan TRUE or FALSE."""


def profile_text(scan: dict, reg: Registry) -> str:
    d = lambda rid: reg.display(rid)
    lines = ["data_quality_scan on the delivered data (rule: result):"]
    b = scan["claim_only_block"]
    lines.append(f"- claim_only_block: {'FIRED' if b['fired'] else 'ok'}. {d('dq.claim_only_block.policies')} consecutive "
                 f"policies (IDpol {d('dq.claim_only_block.first_idpol')} to {d('dq.claim_only_block.last_idpol')}) all "
                 f"have a claim; they hold {d('dq.claim_only_block.claims')} claims "
                 f"({d('dq.claim_only_block.share_of_claims')} of all claims) and "
                 f"{d('dq.claim_only_block.share_without_amount')} of them have no claim amount. Portfolio frequency "
                 f"{d('dq.claim_only_block.frequency_with_block')} with the block, "
                 f"{d('dq.claim_only_block.frequency_without_block')} without it (on the rows that pass the other "
                 f"rules, flagged levels left out; capped).")
    c = scan["claims_without_amount"]
    lines.append(f"- claims_without_amount: {'FIRED' if c['fired'] else 'ok'}. {c['policies']:,} policies with "
                 f"{c['claims']:,} claims have no row in freMTPL2sev ({c['claims_in_block']:,} inside the block, "
                 f"{c['claims_outside_block']:,} outside; most outside the block in {c.get('top_region_outside_block')}).")
    a = scan["amounts_without_policy"]
    lines.append(f"- amounts_without_policy: {'FIRED' if a['fired'] else 'ok'}. {a['rows']:,} amount rows have no policy.")
    for rule, text in (("exposure_above_one", "exposure above one year"), ("exposure_not_positive", "exposure <= 0"),
                       ("claimnb_above_cap", "more than 4 claims"), ("drivage_below_min", "driver age below 18"),
                       ("vehage_above_max", "vehicle age above 50"), ("exact_duplicates", "exact duplicate rows"),
                       ("duplicate_idpol", "duplicated IDpol")):
        r = scan[rule]
        extra = f", max {r['max']}" if "max" in r else ""
        lines.append(f"- {rule}: {'FIRED' if r['fired'] else 'ok'}. {r['rows']:,} rows with {text}{extra}.")
    lo = scan["level_outliers"]
    found = "; ".join(f"{o['factor']} {o['level']} relativity {o['relativity']:.2f} on {o['exposure']:,.0f} exposure-years"
                      for o in lo["levels"]) or "none"
    lines.append(f"- level_outliers: {'FIRED' if lo['fired'] else 'ok'}. Nominal levels (Region, VehBrand, Area) with "
                 f"frequency relativity outside [0.5, 2.0] and >= 500 exposure-years, outside the block: {found}. "
                 f"Other regions lie between {d('dq.level_outliers.Region.others_min_relativity')} and "
                 f"{d('dq.level_outliers.Region.others_max_relativity')}.")
    return "\n".join(lines)


def compact_one_way(factor: str, reg: Registry) -> str:
    rows = [f"one_way({factor}) -> IDs ow_{factor}.<level>.<metric>",
            "level | exposure | claims | frequency (95% CI) | relativity | amount_rows | severity EUR (95% CI, log scale) "
            "| pure_premium EUR"]
    for lab in FACTORS[factor]["labels"]:
        p = f"ow_{factor}.{lab}."
        if p + "frequency" not in reg:
            continue
        g = lambda m: reg.display(p + m)
        rows.append(f"{lab} | {g('exposure')} | {g('claims')} | {g('frequency')} ({g('freq_ci_low')}-{g('freq_ci_high')}) | "
                    f"{g('relativity')} | {g('amount_rows')} | {g('severity')} ({g('sev_ci_low')}-{g('sev_ci_high')}) | "
                    f"{g('pure_premium')}")
    rows.append(f"highest frequency: {reg.display(f'ow_{factor}.highest_frequency_level')}; lowest: "
                f"{reg.display(f'ow_{factor}.lowest_frequency_level')}; spread (max/min): {reg.display(f'ow_{factor}.frequency_spread')}")
    return "\n".join(rows)


def compact_glm(gid: str, factors: list[str], reg: Registry) -> str:
    rows = [f"fit_poisson_glm({', '.join(factors)}) -> IDs {gid}.<factor>.<level>.relativity|ci_low|ci_high",
            f"rating cells {reg.display(gid + '.cells')}; parameters {reg.display(gid + '.parameters')}"]
    for f in factors:
        parts = []
        for lab in FACTORS[f]["labels"]:
            p = f"{gid}.{f}.{lab}."
            if p + "relativity" in reg:
                parts.append(f"{lab} {reg.display(p + 'relativity')} ({reg.display(p + 'ci_low')}-{reg.display(p + 'ci_high')})")
        rows.append(f"{f} (base {reg.display(f'{gid}.{f}.base_level')}): " + "; ".join(parts))
    if f"{gid}.lr.summary" in reg:
        rows.append(f"CODE'S CHECK OF THE FACTOR CHOICE (likelihood-ratio tests, level {reg.display(gid + '.lr.level')}; "
                    f"IDs {gid}.lr.drop.<factor>.* and {gid}.lr.add.<factor>.*): {reg.display(gid + '.lr.summary')}")
        for f in factors:
            q = f"{gid}.lr.drop.{f}."
            rows.append(f"  drop {f}: LR {reg.display(q + 'statistic')} on {reg.display(q + 'df')} df, "
                        f"{reg.display(q + 'p_value')}, BIC gain {reg.display(q + 'bic_gain')} -> {reg.display(q + 'verdict')}")
        for f in FACTOR_NAMES:
            q = f"{gid}.lr.add.{f}."
            if q + "statistic" in reg:
                rows.append(f"  add {f}: LR {reg.display(q + 'statistic')} on {reg.display(q + 'df')} df, "
                            f"{reg.display(q + 'p_value')}, BIC gain {reg.display(q + 'bic_gain')} -> {reg.display(q + 'verdict')}")
        rows.append(f"  overall: the tests {reg.display(gid + '.lr.agreement')} ({gid}.lr.agreement)")
    return "\n".join(rows)


def compact_hypothesis(hid: str, res: dict, reg: Registry) -> str:
    if "error" in res:
        return f"ERROR: {res['error']}"
    g = lambda k: reg.display(f"{hid}.{k}")
    return (f"{hid}: {res['verdict']} ({g('verdict')}). Group {g('group_label')} {res['metric']} {g('group_value')}, rank "
            f"{g('rank')} of {g('groups')}; comparator {g('comparator_label')} {g('comparator_value')}; portfolio "
            f"{g('portfolio_value')}; ratio to portfolio {g('ratio_to_portfolio')}. IDs: {hid}.verdict, {hid}.statement, "
            f"{hid}.group_label, {hid}.group_value, {hid}.comparator_label, {hid}.comparator_value, {hid}.portfolio_value, "
            f"{hid}.ratio_to_portfolio, {hid}.rank, {hid}.groups")


def catalogue(reg: Registry) -> str:
    """Every registry entry, grouped so that the writer sees ID -> displayed value compactly."""
    lines, done = [], set()
    ow_metrics = ["label", "policies", "exposure", "exposure_share", "claims", "frequency", "freq_ci_low", "freq_ci_high",
                  "relativity", "amount_rows", "severity", "sev_ci_low", "sev_ci_high", "pure_premium"]
    for f in FACTOR_NAMES:
        if f"ow_{f}.highest_frequency_level" not in reg:
            continue
        lines.append(f"[one_way {f}] ID pattern ow_{f}.<level>.<metric>; columns: " + " | ".join(ow_metrics)
                     + "   # relativity = level frequency / portfolio frequency; severity = mean amount per amount row")
        for lab in FACTORS[f]["labels"]:
            p = f"ow_{f}.{lab}."
            if p + "frequency" in reg:
                lines.append(f"  {lab}: " + " | ".join(reg.display(p + m) for m in ow_metrics))
                done.update(p + m for m in ow_metrics)
    for rid, e in reg.entries.items():
        if rid not in done:
            lines.append(f"{rid} = {e['display']}" + (f"   # {e['note']}" if e.get("note") else ""))
    return "\n".join(lines)


# ---- JSON schemas (strict structured outputs) ------------------------------------------------------
ALL_LABELS = sorted({lab for spec in FACTORS.values() for lab in spec["labels"]})
ISSUES = ["claim_only_block", "claims_without_amount", "amounts_without_policy", "exposure_above_one",
          "exposure_not_positive", "claimnb_above_cap", "drivage_below_min", "vehage_above_max", "exact_duplicates",
          "duplicate_idpol", "level_outliers"]
TOOLS_ENUM = ["portfolio_summary", "one_way", "fit_poisson_glm", "largest_claims", "check_hypothesis"]


def _typed(extra: dict) -> dict:
    return {"type": "object", "additionalProperties": False,
            "properties": {**extra,
                           "factor": {"type": "string", "enum": FACTOR_NAMES},
                           "levels": {"type": "array", "items": {"type": "string", "enum": ALL_LABELS}},
                           "metric": {"type": "string", "enum": METRICS},
                           "relation": {"type": "string", "enum": RELATIONS},
                           "other_levels": {"type": "array", "items": {"type": "string", "enum": ALL_LABELS}}},
            "required": list(extra) + ["factor", "levels", "metric", "relation", "other_levels"]}


PLAN_SCHEMA = {"type": "json_schema", "name": "analysis_plan", "strict": True, "schema": {
    "type": "object", "additionalProperties": False,
    "required": ["objective", "treatment_proposals", "steps", "hypotheses", "report_outline"],
    "properties": {
        "objective": {"type": "string"},
        "treatment_proposals": {"type": "array", "items": {
            "type": "object", "additionalProperties": False, "required": ["issue", "proposal", "reason"],
            "properties": {"issue": {"type": "string", "enum": ISSUES},
                           "proposal": {"type": "string", "enum": ["exclude", "drop", "cap", "keep", "keep_and_flag"]},
                           "reason": {"type": "string"}}}},
        "steps": {"type": "array", "items": {
            "type": "object", "additionalProperties": False,
            "required": ["step", "tool", "factor", "factors", "n", "hypothesis_id", "purpose"],
            "properties": {"step": {"type": "integer"}, "tool": {"type": "string", "enum": TOOLS_ENUM},
                           "factor": {"anyOf": [{"type": "string", "enum": FACTOR_NAMES}, {"type": "null"}]},
                           "factors": {"anyOf": [{"type": "array", "items": {"type": "string", "enum": FACTOR_NAMES}},
                                                 {"type": "null"}]},
                           "n": {"anyOf": [{"type": "integer"}, {"type": "null"}]},
                           "hypothesis_id": {"anyOf": [{"type": "string", "enum": list(STATEMENTS)}, {"type": "null"}]},
                           "purpose": {"type": "string"}}}},
        "hypotheses": {"type": "array", "items": _typed({
            "id": {"type": "string", "enum": list(STATEMENTS)}, "source_quote": {"type": "string"},
            "typing_note": {"type": "string"}})},
        "report_outline": {"type": "array", "items": {"type": "string"}}}}}

FINDINGS_SCHEMA = {"type": "json_schema", "name": "analyst_findings", "strict": True, "schema": {
    "type": "object", "additionalProperties": False, "required": ["findings", "follow_up_summary"],
    "properties": {
        "findings": {"type": "array", "items": {
            "type": "object", "additionalProperties": False, "required": ["topic", "text", "evidence_ids"],
            "properties": {"topic": {"type": "string", "enum": ["data_quality", "frequency_driver", "severity_driver",
                                                                  "statement_check", "glm_vs_one_way", "glm_choice",
                                                                  "limitation"]},
                           "text": {"type": "string"}, "evidence_ids": {"type": "array", "items": {"type": "string"}}}}},
        "follow_up_summary": {"type": "string"}}}}

_FACTOR_REASONS = {"type": "array", "items": {
    "type": "object", "additionalProperties": False, "required": ["factor", "reason"],
    "properties": {"factor": {"type": "string", "enum": FACTOR_NAMES}, "reason": {"type": "string"}}}}
GLM_PROPOSAL_SCHEMA = {"type": "json_schema", "name": "glm_proposal", "strict": True, "schema": {
    "type": "object", "additionalProperties": False, "required": ["factors", "left_out"],
    "properties": {"factors": _FACTOR_REASONS, "left_out": _FACTOR_REASONS}}}

REPORT_SCHEMA = {"type": "json_schema", "name": "report_draft", "strict": True, "schema": {
    "type": "object", "additionalProperties": False, "required": ["markdown", "claims"],
    "properties": {"markdown": {"type": "string"},
                   "claims": {"type": "array", "items": _typed({"id": {"type": "string"}})}}}}

CHECK_SCHEMA = {"type": "json_schema", "name": "fact_check", "strict": True, "schema": {
    "type": "object", "additionalProperties": False, "required": ["overall", "issues"],
    "properties": {"overall": {"type": "string", "enum": ["ok", "revise"]},
                   "issues": {"type": "array", "items": {
                       "type": "object", "additionalProperties": False,
                       "required": ["quote", "problem", "explanation", "suggestion"],
                       "properties": {"quote": {"type": "string"},
                                      "problem": {"type": "string", "enum": ["causal_wording", "unsupported", "overstated",
                                                                             "missing_caveat", "inconsistent", "other"]},
                                      "explanation": {"type": "string"}, "suggestion": {"type": "string"}}}}}}}


# ---- The gate --------------------------------------------------------------------------------------
PLACEHOLDER = re.compile(r"\{\{\s*([^{}\s]+)\s*\}\}")
CLAIM_TAG = re.compile(r"\[\[\s*(C\d+)\s*\]\]")
COMPARATIVE = re.compile(r"\b(highest|lowest|largest|smallest|strongest|weakest|widest|narrowest|higher than|"
                         r"lower than|greater than|"
                         r"less than|exceeds?|above (?:the )?(?:portfolio|average)|below (?:the )?(?:portfolio|average))\b",
                         re.IGNORECASE)
RANKING_ID = re.compile(r"(highest|lowest|strongest|\.rank$|^ranking\.|^lc\.)")
PLAIN_NUMBER_LABELS = {f: [lab for lab in spec["labels"] if lab.isdigit()] for f, spec in FACTORS.items()}


def strip_allowed(text: str, claim_ids: set[str]) -> str:
    """Remove every digit-bearing token the rules allow; what is left must contain no digit."""
    t = text.replace("–", "-").replace("—", "-").replace("−", "-")
    t = PLACEHOLDER.sub(" ", t)
    t = CLAIM_TAG.sub(" ", t)
    t = re.sub(r"(?m)^(\s*)\d+[.)]\s", r"\1", t)                       # list numbering
    t = re.sub(r"(?m)^(#+\s*)\d+(\.\d+)*\.?\s", r"\1", t)              # numbered headings
    t = re.sub(r"freMTPL2(freq|sev)?", " ", t)
    for f, labs in PLAIN_NUMBER_LABELS.items():
        if labs:
            t = re.sub(rf"\b{f}\s+(?:level\s+|band\s+|class\s+)?({'|'.join(labs)})\b", " ", t)
    labels = {lab for spec in FACTORS.values() for lab in spec["labels"] if not lab.isdigit()}

    def keep_or_drop(m):
        return " " if m.group(0) in labels else m.group(0)
    t = re.sub(r"(?<![\w.])(?:R\d{2}|B\d{1,2}|\d+-\d+|\d+\+|<18)(?![\w])", keep_or_drop, t)
    t = re.sub(r"\b(S\d+)\b", lambda m: " " if m.group(1) in STATEMENTS else m.group(1), t)
    t = re.sub(r"\b(C\d+)\b", lambda m: " " if m.group(1) in claim_ids else m.group(1), t)
    return t


def sentences(markdown: str, keep_all: bool = False) -> list[str]:
    """Sentences of the prose. With keep_all, headings and table rows are kept (one "sentence" each) and list or
    heading numbers at the start of a line are removed first."""
    out = []
    for line in markdown.splitlines():
        s = line.strip()
        if keep_all:
            s = re.sub(r"^(#+\s*)\d+(\.\d+)*\.?\s", r"\1", re.sub(r"^\d+[.)]\s", "", s))
            if s.startswith("#") or s.startswith("|"):
                out.append(s)
                continue
        if not s or s.startswith("#") or s.startswith("|"):
            continue  # headings and table rows are not sentences
        out += [p for p in re.split(r"(?<=[.!?])\s+(?=[A-Z*_\[])", s) if p.strip()]
    return out


def run_gate(draft: dict, plan: dict, rt: dict) -> dict:
    reg: Registry = rt["registry"]
    md, claims = draft.get("markdown", ""), draft.get("claims", [])
    errors = []
    ids = PLACEHOLDER.findall(md)
    unknown = sorted({i for i in ids if i not in reg})
    for i in unknown:
        near = difflib.get_close_matches(i, list(reg.entries), n=2)
        errors.append(f"unknown placeholder {{{{{i}}}}}" + (f"; did you mean {', '.join('{{' + n + '}}' for n in near)}?" if near else ""))
    claim_ids = {c.get("id") for c in claims}
    rest = strip_allowed(md, claim_ids)
    stray = sorted(set(re.findall(r"\S*\d\S*", rest)))
    # Feedback the writer can act on: the sentence, the offending tokens and how to repair them.
    for sentence in sentences(md, keep_all=True):
        tokens = re.findall(r"\S*\d\S*", strip_allowed(sentence, claim_ids))
        if not tokens:
            continue
        # Only a bare number (e.g. "50", "level 50") can be a level label; "5%" or "2.4x" cannot.
        digits = {re.sub(r"[^\w]", "", t) for t in tokens if re.fullmatch(r"\W*\d+\W*", t) and "%" not in t}
        owners = [f for f, labs in PLAIN_NUMBER_LABELS.items() for d in digits if d in labs]
        hint = (f"a plain-number level label must directly follow its factor name (e.g. '{owners[0]} "
                f"{next(d for d in digits if d in PLAIN_NUMBER_LABELS[owners[0]])}') or be written with its label "
                f"placeholder; otherwise " if owners else "") + "replace the number with a registry placeholder or rephrase without it"
        errors.append(f"digit(s) {tokens} outside a placeholder in: {sentence[:170]!r}. Fix: {hint}.")
    if stray and not any(e.startswith("digit(s)") for e in errors):
        # Safety net: the whole-text scan found digits that the sentence-by-sentence scan did not locate.
        errors.append(f"digit(s) {stray[:10]} outside a placeholder; replace them with registry placeholders")
    missing =[h["id"] for h in plan["hypotheses"] if f"{{{{{h['id']}.verdict}}}}" not in md.replace(" ", "")]
    for h in missing:
        errors.append(f"statement {h} has no verdict: add {{{{{h}.verdict}}}}")
    tags = set(CLAIM_TAG.findall(md))
    for c in sorted(tags - claim_ids):
        errors.append(f"claim tag [[{c}]] has no entry in claims")
    for c in sorted(claim_ids - tags):
        errors.append(f"claim {c} is listed but not tagged in the text")
    results = []
    for c in claims:
        cid = c.get("id", "?")
        if cid in STATEMENTS or not re.fullmatch(r"C\d+", str(cid)):
            errors.append(f"claim id {cid!r} must look like C1, C2, ...")
            continue
        spec = {k: c.get(k) for k in ("factor", "levels", "metric", "relation", "other_levels")}
        res = check_hypothesis(rt["data"], DATA["sev"], spec, cid, reg)
        results.append({"id": cid, **spec, "verdict": res.get("verdict"), "error": res.get("error")})
        if "error" in res:
            errors.append(f"claim {cid} is not valid: {res['error']}")
        elif res["verdict"] == "FALSE":
            errors.append(f"claim {cid} is false: the data do not show that {' + '.join(spec['levels'])} "
                          f"{spec['relation'].replace('_', ' ')} for {spec['factor']} ({spec['metric']}); see "
                          f"{{{{{cid}.comparator_label}}}} and {{{{{cid}.comparator_value}}}}. Remove or rewrite the sentence.")
    untagged = []
    for s in sentences(md):
        if COMPARATIVE.search(s) and not CLAIM_TAG.search(s):
            cited = PLACEHOLDER.findall(s)
            if not any(RANKING_ID.search(i) or i.split(".")[0] in STATEMENTS for i in cited):
                untagged.append(s[:160])
    for s in untagged[:8]:
        errors.append(f"comparative sentence without a claim tag or ranking ID: {s!r}. Fix: end it with a typed claim "
                      f"tag [[C#]] listed in claims, or cite a ranking ID computed by code, e.g. "
                      f"{{{{ow_<factor>.highest_frequency_level}}}} or {{{{ranking.frequency_spread.1}}}}, or rephrase "
                      f"without the comparison.")
    return {"passed": not errors, "errors": errors, "placeholders": len(ids), "distinct_ids": len(set(ids)),
            "unknown_ids": unknown, "stray_digits": sorted(set(stray)), "missing_verdicts": missing,
            "claims": results, "untagged_comparatives": untagged}


def render(markdown: str, reg: Registry) -> str:
    text = PLACEHOLDER.sub(lambda m: reg.display(m.group(1)) if m.group(1) in reg else f"[unknown {m.group(1)}]", markdown)
    return re.sub(r"\s*" + CLAIM_TAG.pattern, lambda m: f" *({m.group(1)}: checked by code)*", text)


# ---- Graph state and helpers -----------------------------------------------------------------------
class PartBState(TypedDict, total=False):
    run_id: str
    brief: str
    profile: str
    plan: dict
    plan_problems: list
    decisions: dict
    treatment_log: list
    analysis: dict
    drafts: list
    gates: list
    checks: list
    revisions: int
    feedback: list
    status: str
    final_report: str
    final_draft: int
    revision_failed: str
    signed_off: bool
    log: list
    t0: float


def _say(run_id: str, line: str) -> None:
    """One line of the live printout. It is also kept for the recording, so a replay prints the same lines."""
    RUNTIME[run_id].setdefault("printout", []).append(line)
    CONFIG["print"](line)


def _log(state: PartBState, node: str, res: dict | None = None, **info) -> list:
    entry = {"node": node, "elapsed_s": round(time.time() - state["t0"], 2), **info}
    if res is not None:
        entry.update(agent_status=res["status"], model=res["model"], effort=res["effort"], usd=res["usd"],
                     seconds=res["seconds"], error=res["error"], calls=res["calls"], tool_calls=res["tool_calls"])
    line = f"[{entry['elapsed_s']:6.1f}s] {node:<13}"
    if res is not None:
        line += f" {res['model']}/{res['effort']:<5} USD {res['usd']:.4f} {res['status']:<6}"
    line += " " + info.get("summary", "")
    if info.get("route"):
        line += f" -> route: {info['route']}"
    _say(state["run_id"], line)
    return state.get("log", []) + [entry]



def _merge(results: list[dict]) -> dict:
    """Several run_agent results of one node, booked as one log entry."""
    last = results[-1]
    return dict(last, usd=round(sum(r["usd"] for r in results), 6), calls=[c for r in results for c in r["calls"]],
                tool_calls=[t for r in results for t in r["tool_calls"]],
                seconds=round(sum(r["seconds"] for r in results), 2))


# ---- Nodes -----------------------------------------------------------------------------------------
def node_profile(state: PartBState) -> dict:
    rt = RUNTIME[state["run_id"]]
    reg = rt["registry"]
    rt["scan"] = data_quality_scan(DATA["delivered"], DATA["sev"], reg)
    fired = [k for k, v in rt["scan"].items() if v["fired"]]
    text = profile_text(rt["scan"], reg)
    return {"profile": text, "log": _log(state, "profile", summary=f"scan: {len(fired)} of {len(rt['scan'])} rules fired",
                                           route="planner", fired=fired, scan=rt["scan"])}


def validate_plan(plan: dict) -> list[str]:
    problems = []
    hyps = plan.get("hypotheses", [])
    by_id = {}
    for h in hyps:
        if h["id"] in by_id:
            problems.append(f"statement {h['id']} has more than one hypothesis")
        by_id[h["id"]] = h
        norm = lambda s: re.sub(r"[^a-z0-9]+", " ", s.lower()).strip()
        if norm(h["source_quote"]) not in norm(STATEMENTS[h["id"]]):
            problems.append(f"{h['id']}: source_quote is not the statement's wording")
        problems += [f"{h['id']}: {p}" for p in validate_spec(h)]
    for sid in STATEMENTS:
        if sid not in by_id:
            problems.append(f"statement {sid} has no typed hypothesis")
    steps = plan.get("steps", [])
    if len(steps) > 14:
        problems.append(f"{len(steps)} steps; at most 14")
    glm_steps = [s for s in steps if s["tool"] == "fit_poisson_glm"]
    if len(glm_steps) != 1:
        problems.append(f"{len(glm_steps)} fit_poisson_glm steps; exactly one is needed, with factors null "
                        f"(the analyst chooses the factors after the one-way views)")
    for s in steps:
        t = s["tool"]
        if t == "one_way" and s.get("factor") not in FACTORS:
            problems.append(f"step {s['step']}: one_way needs a factor")
        if t == "largest_claims" and not (isinstance(s.get("n"), int) and 1 <= s["n"] <= 20):
            problems.append(f"step {s['step']}: largest_claims needs 1 <= n <= 20")
        if t == "check_hypothesis" and s.get("hypothesis_id") not in by_id:
            problems.append(f"step {s['step']}: check_hypothesis needs the id of a typed hypothesis")
    return problems


def node_planner(state: PartBState) -> dict:
    user = (f"BRIEF\n{state['brief']}\n\nDATA DICTIONARY\n{dictionary_text()}\n\nDATA-QUALITY SCAN\n{state['profile']}")
    items = [{"role": "user", "content": user}]
    plan, problems, results, ignored = None, [], [], []
    for attempt in (1, 2):  # one re-plan if code finds the plan invalid
        res = llm.run_agent(run_id=state["run_id"], agent="planner", model=CONFIG["models"]["planner"], instructions=_prompt("planner"),
                            input_items=items, text_format=PLAN_SCHEMA, max_output_tokens=8000)
        results.append(res)
        if res["status"] != "ok":
            break
        plan = res["parsed"]
        # The GLM factor set is the analyst's choice; a factor list from the planner is not used.
        for s in plan.get("steps", []):
            if s["tool"] == "fit_poisson_glm" and s.get("factors"):
                ignored.append(s["factors"])
                s["factors"] = None
        problems = validate_plan(plan)
        if not problems:
            break
        items = items + [{"role": "assistant", "content": res["output_text"]},
                         {"role": "user", "content": "Code found these problems in the plan; return a corrected plan:\n- "
                                                     + "\n- ".join(problems)}]
    res = results[-1]
    merged = _merge(results)
    if res["status"] != "ok":
        return {"status": f"aborted_{res['status']}", "log": _log(state, "planner", merged, summary=res["error"] or "",
                                                                   route="finish")}
    ok = not problems
    summary = (f"plan: {len(plan['steps'])} steps, {len(plan['hypotheses'])} typed hypotheses"
               f" ({'valid' if ok else 'INVALID: ' + '; '.join(problems)[:120]}), planner calls {len(results)}"
               + (f"; planner's GLM factor list not used (the analyst chooses): {ignored[-1]}" if ignored else ""))
    return {"plan": plan, "plan_problems": problems,
            "log": _log(state, "planner", merged, summary=summary, route="approve_plan" if ok else "finish",
                        planner_glm_factors_ignored=ignored)}


# How each decision is shown at plan approval. The keys are DECISIONS' values.
DECISION_TEXT = {
    "claim_only_block": {"exclude": "EXCLUDE", "keep": "KEEP"},
    "level_outliers": {"exclude": "EXCLUDE pending investigation", "keep": "KEEP and flag"},
    "invalid_rows": {"drop": "drop the rows", "keep": "keep the rows"},
    "exact_duplicates": {"drop": "drop the copies", "keep": "keep the copies"},
    "exposure_above_one": {"cap": "cap at one year", "keep": "keep"},
    "claimnb_above_cap": {"cap": "cap at four claims", "keep": "keep"},
    "vehage_above_max": {"keep": "keep (band 21+)"},
}


def approval_rows(scan: dict, reg: Registry, plan: dict, decisions: dict) -> list[dict]:
    """One row per fired rule: what the scan found, the planner's proposal with its reason, and the actuary's
    decision (the default unless DECISIONS was changed). The numbers are the registry's displays."""
    d = reg.display
    prop = {p["issue"]: p for p in plan["treatment_proposals"]}

    def planner(*issues):
        found = [prop[i] for i in issues if i in prop]
        return (" / ".join(p["proposal"].replace("_", " ") for p in found) or "-",
                " / ".join(p["reason"] for p in found) or "(no proposal)")

    def decided(key):
        text = DECISION_TEXT[key][decisions[key]]
        return text + (" (default)" if decisions[key] == DEFAULT_DECISIONS[key] else " (changed by the actuary)")
    rows = []
    b = scan["claim_only_block"]
    if b["fired"]:
        rows.append({"issue": "claim-only block", "finding": (
            f"{d('dq.claim_only_block.policies')} policies (IDpol {d('dq.claim_only_block.first_idpol')} to "
            f"{d('dq.claim_only_block.last_idpol')}) with {d('dq.claim_only_block.claims')} claims = "
            f"{d('dq.claim_only_block.share_of_claims')} of all claims; {d('dq.claim_only_block.share_without_amount')} "
            f"without an amount; frequency {d('dq.claim_only_block.frequency_with_block')} with the block, "
            f"{d('dq.claim_only_block.frequency_without_block')} without"),
            **dict(zip(("planner", "reason"), planner("claim_only_block"))), "decision": decided("claim_only_block")})
    for o in scan["level_outliers"]["levels"]:
        f, lv = o["factor"], o["level"]
        rows.append({"issue": f"{f} {lv} (frequency outlier)", "finding": (
            f"frequency relativity {d(f'dq.level_outliers.{f}.{lv}.relativity')} on "
            f"{d(f'dq.level_outliers.{f}.{lv}.exposure')} exposure-years; the other levels of {f} lie between "
            f"{d(f'dq.level_outliers.{f}.others_min_relativity')} and {d(f'dq.level_outliers.{f}.others_max_relativity')}"),
            **dict(zip(("planner", "reason"), planner("level_outliers"))), "decision": decided("level_outliers")})
    if scan["exposure_not_positive"]["fired"] or scan["drivage_below_min"]["fired"]:
        rows.append({"issue": "invalid rows", "finding": (
            f"{d('dq.exposure_not_positive.rows')} rows with exposure <= 0; {d('dq.drivage_below_min.rows')} rows "
            f"with driver age below {d('dq.drivage_below_min.threshold')}"),
            **dict(zip(("planner", "reason"), planner("exposure_not_positive", "drivage_below_min"))),
            "decision": decided("invalid_rows")})
    if scan["exact_duplicates"]["fired"]:
        rows.append({"issue": "exact duplicate rows", "finding": (
            f"{d('dq.exact_duplicates.rows')} exact copies; {d('dq.duplicate_idpol.rows')} duplicated IDpol"),
            **dict(zip(("planner", "reason"), planner("exact_duplicates", "duplicate_idpol"))),
            "decision": decided("exact_duplicates")})
    for key, label, finding in (
            ("exposure_above_one", f"exposure above {d('dq.exposure_above_one.threshold')} year",
             f"{d('dq.exposure_above_one.rows')} rows, max {d('dq.exposure_above_one.max')}"),
            ("claimnb_above_cap", f"more than {d('dq.claimnb_above_cap.threshold')} claims",
             f"{d('dq.claimnb_above_cap.rows')} rows, max {d('dq.claimnb_above_cap.max')}"),
            ("vehage_above_max", f"vehicle age above {d('dq.vehage_above_max.threshold')}",
             f"{d('dq.vehage_above_max.rows')} rows, max {d('dq.vehage_above_max.max')}; "
             f"{d('dq.vehage_above_max.rows_99_or_100')} rows at {d('dq.vehage_above_max.code_values')}")):
        if scan[key]["fired"]:
            rows.append({"issue": label, "finding": finding,
                         **dict(zip(("planner", "reason"), planner(key))), "decision": decided(key)})
    if scan["claims_without_amount"]["fired"]:
        rows.append({"issue": "claims without an amount", "finding": (
            f"{d('dq.claims_without_amount.policies')} policies with {d('dq.claims_without_amount.claims')} claims "
            f"({d('dq.claims_without_amount.claims_in_block')} of them inside the block)"),
            **dict(zip(("planner", "reason"), planner("claims_without_amount"))),
            "decision": "fixed: counted for frequency; severity uses the amounts that exist"})
    if scan["amounts_without_policy"]["fired"]:
        rows.append({"issue": "amounts without a policy", "finding": f"{d('dq.amounts_without_policy.rows')} amount rows",
                     **dict(zip(("planner", "reason"), planner("amounts_without_policy"))),
                     "decision": "fixed: not linked, so not used"})
    return rows


def node_approve_plan(state: PartBState) -> dict:
    """The actuary's step. Shows the plan and, side by side, the planner's proposal and the actuary's decision for
    every data-quality finding (the claim-only block and the outlier region first), then applies the decisions.
    With APPROVE_PLAN = True (Run-all mode) it approves the defaults."""
    rt = RUNTIME[state["run_id"]]
    reg, scan, plan = rt["registry"], rt["scan"], state["plan"]
    decisions = dict(CONFIG["decisions"])
    rows = approval_rows(scan, reg, plan, decisions)
    say = lambda line: _say(state["run_id"], line)
    say("          PLAN APPROVAL (actuary)")
    for s in plan["steps"]:
        args = s.get("factor") or s.get("factors") or s.get("n") or s.get("hypothesis_id") or ""
        if s["tool"] == "fit_poisson_glm":
            args = "factors chosen by the analyst after the one-way views"
        say(f"            step {s['step']:>2}: {s['tool']}({args if not isinstance(args, list) else ', '.join(args)})")
    for h in plan["hypotheses"]:
        say(f"            {h['id']}: {h['factor']} {h['levels']} {h['metric']} {h['relation']}"
            + (f" vs {h['other_levels']}" if h["other_levels"] else ""))
    w1 = max(len("issue"), *(len(r["issue"]) for r in rows))
    w2 = max(len("planner proposes"), *(len(r["planner"]) for r in rows))
    say("            data-quality findings: the planner's proposal and the actuary's decision, side by side")
    say(f"            {'issue':<{w1}} | {'planner proposes':<{w2}} | actuary decides")
    say(f"            {'-' * w1}-+-{'-' * w2}-+-{'-' * 40}")
    for r in rows:
        say(f"            {r['issue']:<{w1}} | {r['planner']:<{w2}} | {r['decision']}")
    for k, r in enumerate(rows, start=1):
        say(f"            [{k}] {r['issue']}: {r['finding']}")
        say(f"                planner's reason: {r['reason']}")
    if not CONFIG["approve_plan"]:
        return {"decisions": decisions, "status": "plan_rejected",
                "log": _log(state, "approve_plan", summary="plan rejected by the actuary", route="finish",
                            approval_rows=rows)}
    rt["data"], steps = apply_decisions(DATA["delivered"], DATA["sev"], scan, decisions, reg)
    for h in plan["hypotheses"]:
        reg.put(f"{h['id']}.statement", STATEMENTS[h["id"]].rstrip("."), "text", "brief")
    summary = (f"approved{' automatically (APPROVE_PLAN = True)' if CONFIG['approve_plan'] else ''}; {len(rt['data']):,} "
               f"policies analysed after: " + "; ".join(f"{a} {n:,}" for a, n in steps))
    proposals = {p["issue"]: p["proposal"] for p in plan["treatment_proposals"]}
    return {"decisions": decisions, "treatment_log": [list(s) for s in steps],
            "log": _log(state, "approve_plan", summary=summary, route="analyst", approval_rows=rows,
                        proposals=proposals)}


def _analyst_tools(phase: str) -> list[dict]:
    """phase "plan": the plan's tools except the GLM (with plan_step); phase "findings": follow-up tools only."""
    reason = {"reason": {"type": "string", "description": "Why this call is needed (one sentence)."}}
    step = {"plan_step": {"type": ["integer", "null"], "description": "The plan step this call executes; null for a follow-up."}}

    def tool(name, desc, props, extra):
        return {"type": "function", "name": name, "description": desc, "strict": True,
                "parameters": {"type": "object", "additionalProperties": False, "properties": {**props, **extra},
                               "required": list(props) + list(extra)}}
    one_way_tool = ("one_way", "Per level of one factor: exposure, claims, frequency (95% CI), relativity, severity "
                               "(95% CI, log scale), pure premium.", {"factor": {"type": "string", "enum": FACTOR_NAMES}})
    if phase == "plan":
        extra = {**step, **reason}
        return [
            tool("portfolio_summary", "Exposure, claims, frequency with 95% CI, severity and pure premium of the analysis "
                                      "data.", {}, extra),
            tool(*one_way_tool, extra),
            tool("largest_claims", "The n largest claim amounts (n <= 20) and their share of all amounts.",
                 {"n": {"type": "integer"}}, extra),
            tool("check_hypothesis", "Decide one typed hypothesis of the approved plan TRUE or FALSE.",
                 {"hypothesis_id": {"type": "string", "enum": list(STATEMENTS)}}, extra),
        ]
    return [
        tool(*one_way_tool, reason),
        tool("fit_poisson_glm", "A further Poisson frequency GLM on another factor set (a follow-up); code fits it and "
                                "tests the choice with likelihood-ratio tests, as for your first proposal.",
             {"factors": {"type": "array", "items": {
                 "type": "object", "additionalProperties": False, "required": ["factor", "reason"],
                 "properties": {"factor": {"type": "string", "enum": FACTOR_NAMES}, "reason": {"type": "string"}}}}},
             reason),
    ]


def validate_glm_proposal(proposal: dict | None) -> list[str]:
    if not proposal:
        return ["no proposal"]
    chosen = [x["factor"] for x in proposal.get("factors", [])]
    left = [x["factor"] for x in proposal.get("left_out", [])]
    problems = []
    if len(chosen) < 2:
        problems.append("choose at least two factors")
    if len(set(chosen)) != len(chosen):
        problems.append("a factor is listed twice in factors")
    both = sorted(set(chosen) & set(left))
    if both:
        problems.append(f"chosen and left out at the same time: {', '.join(both)}")
    short = [x["factor"] for x in proposal.get("factors", []) + proposal.get("left_out", []) if len(x["reason"].strip()) < 10]
    if short:
        problems.append(f"give a short reason for: {', '.join(short)}")
    return problems


def make_dispatch(run_id: str, plan: dict) -> tuple[dict, dict]:
    """Tool functions for the analyst. They compute, register results, and return compact text."""
    rt = RUNTIME[run_id]
    reg, d, sev = rt["registry"], rt["data"], DATA["sev"]
    steps = {s["step"]: s for s in plan["steps"]}
    hyps = {h["id"]: h for h in plan["hypotheses"]}
    book = {"follow_ups": [], "plan_calls": [], "refused": [], "cache": {}, "glms": {}, "glm_checks": []}

    def classify(tool, args):
        step = steps.get(args.get("plan_step"))
        if step is not None and step["tool"] == tool:
            book["plan_calls"].append(step["step"])
            return True
        if len(book["follow_ups"]) >= MAX_FOLLOW_UPS:
            book["refused"].append({"tool": tool, "args": args})
            return None
        book["follow_ups"].append({"tool": tool, "args": {k: v for k, v in args.items() if k != "reason"},
                                   "reason": args.get("reason", "")})
        return False

    def cached(key, fn):
        if key in book["cache"]:
            return book["cache"][key] + "\n(already computed; same IDs)"
        book["cache"][key] = fn()
        return book["cache"][key]

    def run_glm(chosen: list[dict], origin: str) -> str:
        """Fit the GLM on the chosen factors and test the choice (code); chosen = [{"factor", "reason"}]."""
        factors = [x["factor"] for x in chosen]
        key = tuple(sorted(factors))
        if key in book["glms"]:
            return compact_glm(book["glms"][key], factors, reg) + "\n(already fitted and tested; same IDs)"
        gid = f"glm{len(book['glms']) + 1}"
        book["glms"][key] = gid
        t0 = time.time()
        glm = fit_poisson_glm(d, factors, reg, gid)
        check = check_glm_choice(d, glm, reg)
        book["glm_checks"].append({"gid": gid, "origin": origin, "reasons": chosen, "seconds": round(time.time() - t0, 2),
                                   **check})
        return compact_glm(gid, factors, reg)

    def follow_up_glm(args):
        chosen = args.get("factors") or []
        names = [x["factor"] for x in chosen]
        if len(names) < 1 or len(set(names)) != len(names):
            return "ERROR: give distinct factors, each with a reason"
        return run_glm(chosen, origin="analyst follow-up")

    def wrap(tool, key_fn, fn):
        def run(args):
            kind = classify(tool, args)
            if kind is None:
                return f"ERROR: the follow-up budget of {MAX_FOLLOW_UPS} calls is used up; finish with your findings."
            return cached(key_fn(args), lambda: fn(args))
        return run

    dispatch = {
        "portfolio_summary": wrap("portfolio_summary", lambda a: ("ps",), lambda a: (
            portfolio_summary(d, sev, reg), "portfolio_summary -> IDs ps.<metric>: " + "; ".join(
                f"{k.split('.', 1)[1]} {e['display']}" for k, e in reg.entries.items() if k.startswith("ps.")))[1]),
        "one_way": wrap("one_way", lambda a: ("ow", a["factor"]),
                        lambda a: (one_way(d, sev, a["factor"], reg), compact_one_way(a["factor"], reg))[1]),
        "fit_poisson_glm": wrap("fit_poisson_glm",
                                lambda a: ("glm", tuple(sorted(x["factor"] for x in a.get("factors") or []))),
                                follow_up_glm),
        "largest_claims": wrap("largest_claims", lambda a: ("lc", a["n"]), lambda a: (
            largest_claims(d, sev, a["n"], reg), "largest_claims -> IDs lc.<rank>.amount|VehAge|DrivAge|Region, "
            "lc.top_n_share, lc.count_above_threshold, lc.share_above_threshold, lc.threshold, lc.median_amount: " + "; ".join(
                f"{k} {e['display']}" for k, e in reg.entries.items() if k.startswith("lc.") and not k.endswith(("VehAge", "DrivAge", "Region"))))[1]),
        "check_hypothesis": wrap("check_hypothesis", lambda a: ("h", a["hypothesis_id"]), lambda a: compact_hypothesis(
            a["hypothesis_id"], check_hypothesis(d, sev, hyps[a["hypothesis_id"]], a["hypothesis_id"], reg,
                                                 STATEMENTS[a["hypothesis_id"]].rstrip(".")), reg)),
    }
    book["run_glm"] = run_glm
    return dispatch, book


def node_analyst(state: PartBState) -> dict:
    """Three parts: (1) the analyst runs the plan's steps (Luna, tool loop); (2) after the one-way tables it proposes
    the GLM factor set with a reason per factor, and code fits it and tests the choice; (3) the analyst reads the
    test results, may make follow-up calls, and returns its findings."""
    run_id, plan = state["run_id"], state["plan"]
    rt = RUNTIME[run_id]
    reg = rt["registry"]
    dispatch, book = make_dispatch(run_id, plan)
    glm_step = next(s for s in plan["steps"] if s["tool"] == "fit_poisson_glm")
    decisions = "; ".join(f"{k}: {v}" for k, v in state["decisions"].items())
    user = (f"APPROVED PLAN\n{json.dumps({k: plan[k] for k in ('objective', 'steps', 'hypotheses')}, indent=1)}\n\n"
            f"ACTUARY'S DECISIONS (already applied to the analysis data)\n{decisions}\n\nDATA-QUALITY SCAN\n{state['profile']}\n\n"
            f"Do parts 1 and 2 now: run the plan's steps except step {glm_step['step']} (fit_poisson_glm), then return "
            f"your GLM factor proposal as JSON.")
    results = []
    res = llm.run_agent(run_id=run_id, agent="analyst", model=CONFIG["models"]["analyst"], instructions=_prompt("analyst"),
                        input_items=[{"role": "user", "content": user}], tools=_analyst_tools("plan"), dispatch=dispatch,
                        text_format=GLM_PROPOSAL_SCHEMA, max_output_tokens=3000, max_tool_rounds=8)
    results.append(res)
    if res["status"] != "ok":
        return {"status": f"aborted_{res['status']}",
                "log": _log(state, "analyst", _merge(results), summary=res["error"] or "", route="finish")}
    # Code makes sure every plan step ran, whatever the model did (an "orchestration miss" otherwise).
    misses = []
    for s in plan["steps"]:
        if s["step"] in book["plan_calls"] or s["tool"] == "fit_poisson_glm":
            continue
        args = {"plan_step": s["step"], "reason": "run by code: the analyst skipped this plan step"}
        if s["tool"] == "one_way": args["factor"] = s["factor"]
        if s["tool"] == "largest_claims": args["n"] = s["n"]
        if s["tool"] == "check_hypothesis": args["hypothesis_id"] = s["hypothesis_id"]
        dispatch[s["tool"]](args)
        misses.append({"step": s["step"], "tool": s["tool"]})
    # Part 2: the analyst's GLM factor proposal; one correction round if code finds it unusable.
    transcript, proposal = res["transcript"], res["parsed"]
    problems = validate_glm_proposal(proposal)
    if problems:
        res2 = llm.run_agent(run_id=run_id, agent="analyst", model=CONFIG["models"]["analyst"], instructions=_prompt("analyst"),
                             input_items=transcript + [{"role": "user", "content": "Code found problems in your GLM "
                                                        "proposal; return a corrected proposal as JSON:\n- " + "\n- ".join(problems)}],
                             text_format=GLM_PROPOSAL_SCHEMA, max_output_tokens=2000)
        results.append(res2)
        if res2["status"] == "ok":
            transcript, proposal = res2["transcript"], res2["parsed"]
            problems = validate_glm_proposal(proposal)
    origin = "analyst proposal"
    if problems:  # still unusable: code falls back to the factors of the planned one-way views
        planned = list(dict.fromkeys(s["factor"] for s in plan["steps"] if s["tool"] == "one_way"))
        proposal = {"factors": [{"factor": f, "reason": "chosen by code: the analyst's proposal was not usable"}
                                for f in planned], "left_out": []}
        origin = "code fallback"
        misses.append({"step": glm_step["step"], "tool": "fit_poisson_glm", "note": "; ".join(problems)})
    chosen_names = [x["factor"] for x in proposal["factors"]]
    unexplained = [f for f in FACTOR_NAMES if f not in chosen_names and f not in {x["factor"] for x in proposal["left_out"]}]
    book["plan_calls"].append(glm_step["step"])
    glm_text = book["run_glm"](proposal["factors"], origin)
    first = book["glm_checks"][0]
    _say(run_id, f"            GLM factor choice ({origin}): " + "; ".join(
        f"{x['factor']} ({x['reason']})" for x in proposal["factors"]))
    if proposal["left_out"] or unexplained:
        _say(run_id, "            left out: " + "; ".join([f"{x['factor']} ({x['reason']})" for x in proposal["left_out"]]
                                                          + [f"{f} (no reason given)" for f in unexplained]))
    _say(run_id, f"            code's check ({first['gid']}, likelihood-ratio tests, {first['seconds']:.1f} s): "
                 f"{reg.display(first['gid'] + '.lr.summary')}")
    # Part 3: findings, after the test results.
    left = MAX_FOLLOW_UPS - len(book["follow_ups"])
    msg = (f"CODE FITTED YOUR GLM (plan step {glm_step['step']}) AND TESTED YOUR FACTOR CHOICE\n{glm_text}\n\n"
           f"Now part 3. You have {left} follow-up call{'s' if left != 1 else ''} left (for example fit_poisson_glm with "
           f"another factor set, with a reason per factor). Then return your findings as JSON, including one finding "
           f"with topic glm_choice.")
    res3 = llm.run_agent(run_id=run_id, agent="analyst", model=CONFIG["models"]["analyst"], instructions=_prompt("analyst"),
                         input_items=transcript + [{"role": "user", "content": msg}], tools=_analyst_tools("findings"),
                         dispatch=dispatch, text_format=FINDINGS_SCHEMA, max_output_tokens=4000, max_tool_rounds=4)
    results.append(res3)
    for extra in book["glm_checks"][1:]:
        _say(run_id, f"            follow-up GLM {extra['gid']} ({', '.join(extra['chosen'])}): "
                     f"{reg.display(extra['gid'] + '.lr.summary')}")
    findings = res3["parsed"] if res3["status"] == "ok" else None
    unknown_evidence = sorted({i for f in (findings or {}).get("findings", []) for i in f["evidence_ids"] if i not in reg})
    analysis = {"findings": findings, "glm_proposal": {**proposal, "origin": origin, "left_out_without_reason": unexplained,
                                                       "problems_before_fallback": problems},
                "glm_checks": book["glm_checks"], "follow_ups": book["follow_ups"], "refused_follow_ups": book["refused"],
                "orchestration_misses": misses, "glm_ids": {", ".join(k): v for k, v in book["glms"].items()},
                "unknown_evidence_ids": unknown_evidence, "tool_calls": sum(len(r["tool_calls"]) for r in results),
                "agent_calls": sum(len(r["calls"]) for r in results)}
    route = "writer" if res3["status"] == "ok" else "finish"
    summary = (f"{analysis['tool_calls']} tool calls, {len(book['follow_ups'])} follow-ups, {len(misses)} orchestration "
               f"misses, GLM {first['gid']} on {len(chosen_names)} factors ({origin}; tests "
               f"{'agree' if first['agrees'] else 'disagree'}), {len((findings or {}).get('findings', []))} findings")
    out = {"analysis": analysis, "log": _log(state, "analyst", _merge(results), summary=summary, route=route)}
    if res3["status"] != "ok":
        out["status"] = f"aborted_{res3['status']}"
    return out


def node_writer(state: PartBState) -> dict:
    run_id = state["run_id"]
    rt = RUNTIME[run_id]
    plan = state["plan"]
    drafts = state.get("drafts", [])
    if not drafts:
        update_rankings(rt["registry"])  # cross-factor rankings over everything the analyst computed
        a = state["analysis"]
        prop = a["glm_proposal"]
        glm_lines = [f"- chosen ({prop['origin']}): " + "; ".join(f"{x['factor']}: {x['reason']}" for x in prop["factors"]),
                     "- left out: " + ("; ".join([f"{x['factor']}: {x['reason']}" for x in prop["left_out"]]
                                                 + [f"{f}: no reason given" for f in prop["left_out_without_reason"]]) or "none")]
        glm_lines += [f"- code's likelihood-ratio check of {c['gid']} ({', '.join(c['chosen'])}; {c['origin']}): see "
                      f"{c['gid']}.lr.summary and {c['gid']}.lr.* in the registry" for c in a["glm_checks"]]
        user = (f"BRIEF\n{state['brief']}\n\nAPPROVED PLAN (hypotheses and outline)\n"
                f"{json.dumps({'hypotheses': plan['hypotheses'], 'report_outline': plan['report_outline']}, indent=1)}\n\n"
                f"ACTUARY'S DECISIONS\n{json.dumps(state['decisions'])}\nTreatments applied, in this order (their counts are "
                f"the registry's dec.* IDs): {', '.join(a_ for a_, _ in state['treatment_log'])}\n\nDATA DICTIONARY\n{dictionary_text()}\n\n"
                f"ANALYST'S GLM FACTOR CHOICE (the analyst's reasons, in words)\n" + "\n".join(glm_lines) + "\n\n"
                f"ANALYST'S FINDINGS\n{json.dumps(a['findings'], indent=1)}\n\n"
                f"RESULTS REGISTRY (ID = displayed value)\n{catalogue(rt['registry'])}")
        rt["writer_items"] = [{"role": "user", "content": user}]
    else:
        rt["writer_items"] = rt["writer_items"] + [
            {"role": "assistant", "content": json.dumps(drafts[-1])},
            {"role": "user", "content": "Feedback on your draft; return the complete corrected report as JSON:\n- "
                                        + "\n- ".join(state["feedback"])}]
    res = llm.run_agent(run_id=run_id, agent="writer", model=CONFIG["models"]["writer"], instructions=_prompt("writer"),
                        input_items=rt["writer_items"], text_format=REPORT_SCHEMA, max_output_tokens=5000)
    if res["status"] != "ok":
        passed = [i for i, g in enumerate(state.get("gates", [])) if g["passed"]]
        diag = {k: res[k] for k in ("incomplete_head", "incomplete_tail") if k in res}
        if passed and res["status"] == "api_error":
            # A failed revision does not lose the work: the last draft that passed the gate goes to sign-off,
            # and the report header says that the revision failed.
            return {"revision_failed": f"the last revision failed ({res['error']})",
                    "log": _log(state, "writer", res, summary=f"revision failed ({res['error']}); falling back to "
                                f"draft {passed[-1] + 1}, which passed the gate", route="sign_off", **diag)}
        return {"status": f"aborted_{res['status']}",
                "log": _log(state, "writer", res, summary=res["error"] or "", route="finish", **diag)}
    draft = res["parsed"]
    # Registry IDs never contain spaces, so code removes whitespace inside {{ }} (e.g. "{{glm1.X .relativity}}").
    fixed = [0]

    def squeeze(m):
        inner = re.sub(r"\s+", "", m.group(1))
        fixed[0] += inner != m.group(1).strip()
        return "{{" + inner + "}}"
    draft["markdown"] = re.sub(r"\{\{([^{}]*)\}\}", squeeze, draft["markdown"])
    n = len(PLACEHOLDER.findall(draft["markdown"]))
    return {"drafts": drafts + [draft], "log": _log(state, "writer", res, draft=len(drafts) + 1, placeholders_normalised=fixed[0],
                                                    summary=f"draft {len(drafts) + 1}: {n} placeholders, "
                                                            f"{len(draft['claims'])} typed claims"
                                                            + (f", {fixed[0]} placeholders normalised" if fixed[0] else ""),
                                                    route="gate")}


def node_gate(state: PartBState) -> dict:
    rt = RUNTIME[state["run_id"]]
    result = run_gate(state["drafts"][-1], state["plan"], rt)
    revisions = state.get("revisions", 0)
    passed_before = [i for i, g in enumerate(state.get("gates", [])) if g["passed"]]
    if result["passed"]:
        route = "fact_checker"
    elif revisions < MAX_REVISIONS:
        route = "writer"
    elif passed_before:
        route = "sign_off"  # the revision was optional (asked for by the advisory checker); keep the passing draft
    else:
        route = "finish"
    summary = ("PASS" if result["passed"] else f"FAIL ({len(result['errors'])} problems)") + \
              f": {result['placeholders']} placeholders, {len(result['claims'])} claims " \
              f"({sum(c['verdict'] == 'TRUE' for c in result['claims'])} true)"
    out = {"gates": state.get("gates", []) + [result],
           "log": _log(state, "gate", summary=summary, route=route, errors=result["errors"])}
    if not result["passed"]:
        if route == "writer":
            out.update(feedback=result["errors"], revisions=revisions + 1)
            for e in result["errors"][:6]:
                _say(state["run_id"], f"            gate: {e[:150]}")
        elif route == "sign_off":
            first = result["errors"][0]
            out["revision_failed"] = f"the last revision failed the gate ({first[:120]}{'...' if len(first) > 120 else ''})"
        else:
            out["status"] = "escalated_gate_failed"
    return out


def node_fact_checker(state: PartBState) -> dict:
    rt = RUNTIME[state["run_id"]]
    reg = rt["registry"]
    draft, gate = state["drafts"][-1], state["gates"][-1]
    cited = sorted(set(PLACEHOLDER.findall(draft["markdown"])))
    user = (f"REPORT (numbers filled in by code)\n{render(draft['markdown'], reg)}\n\n"
            f"TYPED CLAIMS CHECKED BY CODE\n{json.dumps(gate['claims'])}\n\n"
            f"STATEMENT VERDICTS BY CODE\n" + "\n".join(f"{h['id']}: {reg.display(h['id'] + '.verdict')}"
                                                        for h in state["plan"]["hypotheses"]) +
            f"\n\nACTUARY'S DECISIONS\n{json.dumps(state['decisions'])}\n\n"
            f"CITED REGISTRY ENTRIES (ID = value   # what it means)\n" + "\n".join(
                f"{i} = {reg.display(i)}" + (f"   # {reg.entries[i]['note']}" if i in reg and reg.entries[i].get("note") else "")
                for i in cited))
    res = llm.run_agent(run_id=state["run_id"], agent="fact_checker", model=CONFIG["models"]["fact_checker"], instructions=_prompt("fact_checker"),
                        input_items=[{"role": "user", "content": user}], text_format=CHECK_SCHEMA, max_output_tokens=4000)
    checks = state.get("checks", [])
    if res["status"] != "ok":
        # Advisory: a failed checker call does not block; the actuary is told.
        check = {"overall": "not_run", "issues": [], "error": res["error"], "draft": len(state["drafts"])}
        return {"checks": checks + [check],
                "log": _log(state, "fact_checker", res, summary=f"not run: {res['error']}", route="sign_off")}
    check = dict(res["parsed"], draft=len(state["drafts"]))
    revisions = state.get("revisions", 0)
    n_calls = len(checks) + 1
    if check["overall"] == "revise" and revisions < MAX_REVISIONS and n_calls < MAX_CHECKER_CALLS:
        route = "writer"
    else:
        route = "sign_off"
    out = {"checks": checks + [check],
           "log": _log(state, "fact_checker", res, summary=f"{check['overall']}: {len(check['issues'])} notes "
                       f"({', '.join(sorted({i['problem'] for i in check['issues']}))}) on draft {check['draft']}",
                       route=route)}
    if route == "writer":
        out.update(revisions=revisions + 1,
                   feedback=[f"fact checker ({i['problem']}): \"{i['quote']}\" - {i['explanation']} Suggestion: {i['suggestion']}"
                             for i in check["issues"]])
    return out


LIMIT_STATEMENT = ("The gate proves provenance, not meaning: it checks that every number comes from the results "
                   "registry and that every sentence with one of its comparison words (\"highest\", \"lower than\", "
                   "\"above the portfolio\" and a few others) carries a typed claim checked by code or cites a ranking "
                   "or a statement check computed by code. Comparisons worded otherwise (\"rises sharply\", \"close to "
                   "its base level\", \"higher in A than in B\") are not checked, and neither is whether the right ID "
                   "was chosen or the words around a number are right. The fact checker's open notes and the "
                   "actuary's reading cover that.")


def node_sign_off(state: PartBState) -> dict:
    """The actuary's sign-off. The open fact-checker notes on the signed draft are listed first; in Run-all mode
    (SIGN_OFF = True) the report is signed automatically and the notes are printed, not hidden."""
    run_id = state["run_id"]
    rt = RUNTIME[run_id]
    reg = rt["registry"]
    idx = max(i for i, g in enumerate(state["gates"]) if g["passed"])
    reviewed = [c for c in state.get("checks", []) if c.get("draft") == idx + 1]
    check = reviewed[-1] if reviewed else {"overall": "not_run", "issues": [], "error": "no check of this draft"}
    notes = check.get("issues", [])
    draft, gate = state["drafts"][idx], state["gates"][idx]
    body = render(draft["markdown"], reg)
    cost = llm.run_cost(run_id)
    sign_off = CONFIG["sign_off"]
    status = "signed_off" if sign_off else "awaiting_sign_off"
    verdicts = ", ".join(f"{h['id']} {reg.display(h['id'] + '.verdict')}" for h in state["plan"]["hypotheses"])
    checker = (f"{check['overall']}, {len(notes)} open note{'s' if len(notes) != 1 else ''}"
               + (", listed at the end" if notes else "") if check["overall"] != "not_run"
               else f"not run ({check.get('error')})")
    sign_line = (f"Signed off automatically (Run-all mode, SIGN_OFF = True) with {len(notes)} open fact-checker "
                 f"note{'s' if len(notes) != 1 else ''}." if sign_off else "Awaiting the actuary's sign-off (SIGN_OFF = False).")
    header = [f"> Run {run_id} | gate: PASS ({gate['placeholders']} placeholders, {len(gate['claims'])} typed claims "
              f"checked) | statements: {verdicts}",
              f"> revisions: {state.get('revisions', 0)} | fact checker (advisory): {checker} | cost USD {cost:.4f} | "
              f"{time.time() - state['t0']:.0f} s",
              "> Every number below was filled in by code from the results registry; the agents wrote only placeholders.",
              f"> {LIMIT_STATEMENT}",
              f"> {sign_line}"]
    if state.get("revision_failed"):
        header.insert(2, f"> NOTE: {state['revision_failed']}; this is draft {idx + 1}, which passed the gate.")
    if notes:
        tail = (f"\n\n---\n**Open fact-checker notes at sign-off ({len(notes)}; advisory, not resolved by code):**\n"
                + "\n".join(f"{k}. {i['problem']}: \"{i['quote']}\" - {i['explanation']}" for k, i in enumerate(notes, 1)))
    else:
        tail = "\n\n---\n**Open fact-checker notes at sign-off:** none."
    final = "\n".join(header) + "\n\n" + body + tail
    say = lambda line: _say(run_id, line)
    say("          SIGN-OFF (actuary)")
    say(f"            report: draft {idx + 1}, gate PASS; {verdicts}")
    if check["overall"] == "not_run":
        say(f"            fact checker not run on this draft ({check.get('error')}); no notes to show")
    elif notes:
        say(f"            open fact-checker notes (advisory): {len(notes)}")
        for k, i in enumerate(notes, 1):
            say(f"              {k}. {i['problem']}: \"{i['quote'][:140]}\" - {i['explanation'][:220]}")
    else:
        say("            open fact-checker notes: none")
    say(f"            limit: {LIMIT_STATEMENT}")
    say(f"            {sign_line}")
    return {"final_report": final, "signed_off": sign_off, "status": status, "final_draft": idx,
            "log": _log(state, "sign_off", summary=status, route="END", open_notes=notes, auto_sign_off=sign_off,
                        checker_overall=check["overall"])}


def node_finish(state: PartBState) -> dict:
    status = state.get("status") or "escalated"
    return {"status": status, "signed_off": False,
            "log": _log(state, "finish", summary=f"not signed off: {status}", route="END")}


# ---- One run (the notebook builds the graph from the nodes above) --------------------------------------
RECURSION_LIMIT = 30


def start_run(run_id: str, cache_dir: Path) -> dict:
    """Load the data (once), open a registry for the run and return the initial JSON-only state."""
    load_data(cache_dir)
    RUNTIME[run_id] = {"registry": Registry(), "printout": []}
    return {"run_id": run_id, "brief": BRIEF, "t0": time.time(), "log": [], "revisions": 0}


def run_partb(graph, run_id: str, cache_dir: Path) -> tuple[dict, dict]:
    """One complete live run through a compiled graph. Returns (final JSON state, runtime objects incl. the
    registry and the printout)."""
    state = graph.invoke(start_run(run_id, cache_dir), {"recursion_limit": RECURSION_LIMIT})
    json.dumps(state)  # the state must be JSON-only; this raises if it is not
    return state, RUNTIME[run_id]


def analyst_tools(phase: str) -> list[dict]:
    return _analyst_tools(phase)


def fingerprint() -> str:
    """sha256 of everything that shapes the agents' behaviour: prompts, brief, schemas, tool definitions, settings
    (as recorded with the five Part B runs of 23 September 2026)."""
    p = CONFIG["prompts"]
    parts = [p.get("planner", ""), p.get("analyst", ""), p.get("writer", ""), p.get("fact_checker", ""), BRIEF,
             json.dumps([PLAN_SCHEMA, GLM_PROPOSAL_SCHEMA, FINDINGS_SCHEMA, REPORT_SCHEMA, CHECK_SCHEMA,
                         _analyst_tools("plan"), _analyst_tools("findings")]),
             json.dumps([llm.EFFORT, llm.PRICES, CONFIG["decisions"], MAX_REVISIONS, MAX_FOLLOW_UPS, MAX_CHECKER_CALLS,
                         LR_TEST_LEVEL, SEV_CI_METHOD, SCAN_RULES])]
    return hashlib.sha256("\n".join(parts).encode("utf-8")).hexdigest()


S1_LEVELS = {"16-20", "21+"}  # "over 15 years old" in the dictionary's VehAge bands


def score(state: dict, reg: Registry) -> dict:
    """Did the run catch S1 (false) and confirm S2 (true)? Decided from the state and the registry only."""
    hyps = {h["id"]: h for h in (state.get("plan") or {}).get("hypotheses", [])}
    final_md = state["drafts"][state["final_draft"]]["markdown"] if state.get("final_draft") is not None else ""
    out = {}
    for sid, expected in (("S1", "FALSE"), ("S2", "TRUE")):
        verdict_id = f"{sid}.verdict"
        verdict = None
        if verdict_id in reg:
            verdict = "TRUE" if reg.display(verdict_id).startswith("SUPPORTED") else "FALSE"
        in_report = f"{{{{{verdict_id}}}}}" in final_md.replace(" ", "")
        signed = state.get("status") == "signed_off"
        good = verdict == expected and in_report and signed
        out[sid] = {"expected": expected, "code_verdict": verdict, "verdict_in_signed_report": in_report and signed,
                    "result": ("caught" if sid == "S1" else "confirmed") if good else "missed"}
    return out


# ---- Replay (no API key, or no credit) -------------------------------------------------------------
def load_recording(path: Path, run_id: str | None = None) -> tuple[dict, dict]:
    """(meta, run) of one recorded run; the first run if run_id is None."""
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    runs = {r["run_id"]: r for r in data["runs"]}
    return data["meta"], runs[run_id] if run_id else data["runs"][0]


def replay_run(meta: dict, run: dict, show_report: bool = True, print_fn=print) -> str:
    """Print a recorded run exactly as it was printed live, then its signed report. No API call."""
    print_fn(f"[recorded run {run['run_id']}, {run['started_utc']} UTC; planner and fact checker "
             f"{meta['models']['planner']}, analyst and writer {meta['models']['analyst']}; USD {run['usd']:.4f}, "
             f"{run['seconds']:.0f} s when recorded]")
    for line in run.get("printout", []):
        print_fn(line)
    report = run["state"].get("final_report") or f"(no report: {run['status']})"
    if show_report:
        print_fn("\n" + report)
    return report
