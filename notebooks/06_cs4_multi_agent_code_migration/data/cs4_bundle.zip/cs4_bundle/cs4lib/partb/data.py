"""Part B: the data, the data dictionary and the planted issues.

  1. downloads freMTPL2freq and freMTPL2sev from OpenML once into _local/ (notebook 04's download()
     pattern) and checks their sha256;
  2. defines the data dictionary: rating factors, their bands and the level labels the agents may use;
  3. plants four issue classes that do not occur in the raw data (fixed seed), and keeps a register of
     what was planted, separate from the register of the issues the raw data already has.

Nothing here calls a language model.
"""
from __future__ import annotations

import hashlib
import json
import os
import urllib.request
from pathlib import Path

import numpy as np
import pandas as pd

# ---- Where the data come from ----------------------------------------------------------------------
# OpenML datasets 41214 (policies) and 41215 (claim amounts). They are downloaded at run time and never
# committed: OpenML lists them as CC0, while the CASdatasets R package they come from is GPL.
FREQ_URL = "https://data.openml.org/datasets/0004/41214/dataset_41214.pq"
SEV_URL = "https://data.openml.org/datasets/0004/41215/dataset_41215.pq"
FREQ_SHA256 = "aead80a9ac68baf2c78fc1beaa287441d88d06cc11be60a1f226784d164c6dd7"  # 7,469,711 bytes
SEV_SHA256 = "c721d570c42eeaf4a70cc12f4c1e04095a6046f6cdbc01fad919274879783e60"   # 277,195 bytes

PLANT_SEED = 20261002  # the seminar date; every planted issue depends only on this seed

BROWSER_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/140.0 Safari/537.36"
}


def ends_look_right(path: Path, head: bytes, tail: bytes) -> bool:
    # A complete parquet file starts and ends with PAR1.
    if not path.exists() or path.stat().st_size < 1024:
        return False
    with path.open("rb") as handle:
        start = handle.read(len(head))
        handle.seek(-1024, os.SEEK_END)
        end = handle.read()
    return start == head and tail in end


def download(url: str, path: Path, head: bytes = b"PAR1", tail: bytes = b"PAR1") -> str:
    """Download once and keep the file with a note of its URL and checksum (notebook 04's pattern)."""
    note = path.with_name(path.name + ".json")
    if note.exists() and ends_look_right(path, head, tail):
        if json.loads(note.read_text(encoding="utf-8")).get("url") == url:
            return "read from cache"
    request = urllib.request.Request(url, headers=BROWSER_HEADERS)
    with urllib.request.urlopen(request, timeout=300) as response:
        content = response.read()
    partial = path.with_name(path.name + ".part")
    partial.write_bytes(content)
    if not ends_look_right(partial, head, tail):
        partial.unlink()
        raise ValueError(f"{url} did not return a complete {path.suffix} file")
    os.replace(partial, path)
    digest = hashlib.sha256(content).hexdigest()
    note.write_text(json.dumps({"url": url, "sha256": digest, "bytes": len(content)}, indent=2) + "\n",
                    encoding="utf-8", newline="\n")
    return "downloaded now"


def sha256_of(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_raw(cache_dir: Path, reuse: dict[str, Path] | None = None) -> tuple[pd.DataFrame, pd.DataFrame, dict]:
    """Return (policies, claim amounts, provenance). `reuse` may point to local copies made earlier;
    they are used only if their sha256 matches the OpenML files."""
    cache_dir.mkdir(parents=True, exist_ok=True)
    provenance = {}
    paths = {}
    for name, url, expected in (("freMTPL2freq", FREQ_URL, FREQ_SHA256), ("freMTPL2sev", SEV_URL, SEV_SHA256)):
        candidate = (reuse or {}).get(name)
        if candidate is not None and candidate.exists() and sha256_of(candidate) == expected:
            path, source = candidate, "reused a local copy"
        else:
            path = cache_dir / f"{name}.parquet"
            if path.exists() and sha256_of(path) == expected:
                source = "read from cache"  # also a copy placed there by hand, without download()'s note
            else:
                source = download(url, path)
        digest = sha256_of(path)
        provenance[name] = {"url": url, "sha256": digest, "bytes": path.stat().st_size, "source": source,
                            "checksum": "PASS" if digest == expected else "ATTENTION: checksum differs"}
        paths[name] = path
    freq = pd.read_parquet(paths["freMTPL2freq"])
    sev = pd.read_parquet(paths["freMTPL2sev"])
    # IDpol arrives as a float; it is an identifier, so make it an integer.
    freq["IDpol"] = freq["IDpol"].astype("int64")
    sev["IDpol"] = sev["IDpol"].astype("int64")
    for column in ("Area", "VehBrand", "Region"):
        freq[column] = freq[column].astype(str)
    freq["ClaimNb"] = freq["ClaimNb"].astype("int64")
    for column in ("VehPower", "VehAge", "DrivAge", "BonusMalus"):
        freq[column] = freq[column].astype("int64")
    return freq, sev, provenance


# ---- The data dictionary ---------------------------------------------------------------------------
# Every rating factor the tools accept, how it is banded, and the level labels in their natural order.
# The labels are the only digit-bearing words the report writer may use outside a placeholder.
INF = float("inf")
FACTORS: dict[str, dict] = {
    "VehAge": {"description": "vehicle age in years", "edges": [-INF, 0, 2, 5, 10, 15, 20, INF],
               "labels": ["0", "1-2", "3-5", "6-10", "11-15", "16-20", "21+"]},
    "DrivAge": {"description": "driver age in years", "edges": [-INF, 17, 20, 25, 30, 40, 50, 60, 70, 80, INF],
                "labels": ["<18", "18-20", "21-25", "26-30", "31-40", "41-50", "51-60", "61-70", "71-80", "81+"]},
    "BonusMalus": {"description": "bonus-malus level (50 = best, 100 = neutral)",
                   "edges": [-INF, 50, 60, 70, 80, 100, 125, INF],
                   "labels": ["50", "51-60", "61-70", "71-80", "81-100", "101-125", "126+"]},
    "VehPower": {"description": "vehicle power class", "edges": [-INF, 4, 5, 6, 7, 8, 10, INF],
                 "labels": ["4", "5", "6", "7", "8", "9-10", "11+"]},
    "Density": {"description": "inhabitants per square kilometre of the driver's town",
                "edges": [-INF, 50, 200, 1000, 5000, INF],
                "labels": ["1-50", "51-200", "201-1000", "1001-5000", "5001+"]},
    "Area": {"description": "area code, A (rural) to F (urban centre)", "labels": list("ABCDEF")},
    "VehGas": {"description": "fuel type", "labels": ["Diesel", "Regular"]},
    "Region": {"description": "French region code (pre-2016 regions)",
               "labels": ["R11", "R21", "R22", "R23", "R24", "R25", "R26", "R31", "R41", "R42", "R43", "R52",
                          "R53", "R54", "R72", "R73", "R74", "R82", "R83", "R91", "R93", "R94"]},
    "VehBrand": {"description": "vehicle brand code (anonymised)",
                 "labels": ["B1", "B2", "B3", "B4", "B5", "B6", "B10", "B11", "B12", "B13", "B14"]},
}
FACTOR_NAMES = list(FACTORS)
NOMINAL_FACTORS = ["Region", "VehBrand", "Area"]  # checked by the level-outlier rule


def band(frame: pd.DataFrame, factor: str) -> pd.Series:
    """The level label of every row for one factor (banded factors are cut at the dictionary's edges)."""
    spec = FACTORS[factor]
    if "edges" in spec:
        return pd.cut(frame[factor], bins=spec["edges"], labels=spec["labels"], right=True).astype(str)
    return frame[factor].astype(str)


# ---- Planted issues --------------------------------------------------------------------------------
# Only classes that are absent from the raw data are planted (checked: no exposure <= 0, no driver under
# 18, no duplicated IDpol, and every region's frequency relativity lies between 0.72 and 1.27 once the
# claim-only block is removed). The rows used as templates are "ordinary" rows, so that planting does
# not change any count of the native issues. No planted issue adds or removes a claim, so every claim
# count of the scan (the claim-only block's 27.5% of all claims, the claims without an amount) is the
# native one.
PLANT = {
    "spike_region": "R25",          # an exposure feed that loaded only part of the year for one region
    "spike_target_relativity": 2.4,  # the scan's threshold is 2.0; the natural maximum is 1.27
    "n_exposure_not_positive": 24,   # 12 rows with exposure 0, 12 with a negative exposure
    "n_drivage_below_18": 16,        # ages 0 (a missing-value code), 16 and 17
    "n_exact_duplicates": 40,        # rows repeated with every column equal, IDpol included
    "new_idpol_start": 7_000_001,    # appended rows get new IDs above the raw maximum (6,114,330)
}


def _spike_factor(outside: pd.DataFrame, scaled: pd.Series, target: float) -> float:
    """The factor c in (0, 1] that brings the region's capped frequency relativity (outside the block) to
    the target when the exposure of the `scaled` rows is multiplied by c. Solved by bisection, rounded to
    3 decimals (the relativity then lies within 0.01 of the target)."""
    n_cap = outside.ClaimNb.clip(upper=4)
    region = outside.Region == PLANT["spike_region"]

    def relativity(c: float) -> float:
        e = outside.Exposure.where(~scaled, outside.Exposure * c).clip(upper=1)
        return (n_cap[region].sum() / e[region].sum()) / (n_cap.sum() / e.sum())
    lo, hi = 1e-3, 1.0  # relativity(c) falls as c rises
    for _ in range(60):
        mid = (lo + hi) / 2
        lo, hi = (mid, hi) if relativity(mid) > target else (lo, mid)
    return round(lo, 3)


def plant_issues(freq: pd.DataFrame, seed: int = PLANT_SEED) -> tuple[pd.DataFrame, dict]:
    """Return the delivered policy table (raw + planted issues) and the register of planted issues."""
    rng = np.random.default_rng(seed)
    raw = freq.copy()
    ordinary = raw[(raw.IDpol > 30_000) & (raw.Exposure > 0) & (raw.Exposure <= 1) & (raw.ClaimNb <= 4)
                   & (raw.VehAge <= 50) & (raw.DrivAge >= 18) & (raw.Region != PLANT["spike_region"])]

    # 1. Region spike: the exposure of one region's policies (outside the IDpol block, exposure <= 1, so that
    #    no native count such as "exposure above one year" changes) is multiplied by a factor c < 1, as if the
    #    feed had loaded only part of the year. Claim counts stay as they are; the region's frequency
    #    relativity rises to the target.
    region = PLANT["spike_region"]
    outside = raw[raw.IDpol > 30_000]
    scaled = (outside.Region == region) & (outside.Exposure <= 1)
    target = PLANT["spike_target_relativity"]
    c = _spike_factor(outside, scaled, target)
    spiked = outside.index[scaled]
    raw.loc[spiked, "Exposure"] = raw.loc[spiked, "Exposure"] * c

    # 2. Exposure <= 0, 3. DrivAge < 18: copies of ordinary rows with new IDs, claim counts set to 0
    #    (so that they add no claims), and one field broken.
    next_id = PLANT["new_idpol_start"]
    n_exp = PLANT["n_exposure_not_positive"]
    bad_exposure = ordinary.loc[rng.choice(ordinary.index, size=n_exp, replace=False)].copy()
    bad_exposure["Exposure"] = np.r_[np.zeros(n_exp // 2), -np.round(rng.uniform(0.05, 1.0, n_exp - n_exp // 2), 2)]
    bad_exposure["ClaimNb"] = 0
    bad_exposure["IDpol"] = np.arange(next_id, next_id + n_exp)
    next_id += n_exp

    n_age = PLANT["n_drivage_below_18"]
    bad_age = ordinary.loc[rng.choice(ordinary.index, size=n_age, replace=False)].copy()
    bad_age["DrivAge"] = rng.choice([0, 16, 17], size=n_age)
    bad_age["ClaimNb"] = 0
    bad_age["IDpol"] = np.arange(next_id, next_id + n_age)

    # 4. Exact duplicates: ordinary rows repeated unchanged, IDpol included.
    n_dup = PLANT["n_exact_duplicates"]
    duplicates = ordinary.loc[rng.choice(ordinary.index, size=n_dup, replace=False)].copy()

    delivered = (pd.concat([raw, bad_exposure, bad_age, duplicates], ignore_index=True)
                 .sort_values("IDpol", kind="stable").reset_index(drop=True))

    # What the scan should find, measured on the delivered table itself.
    d_outside = delivered[(delivered.IDpol > 30_000) & (delivered.Exposure > 0)]
    dn, de = d_outside.ClaimNb.clip(upper=4), d_outside.Exposure.clip(upper=1)
    rel_after = (dn[d_outside.Region == region].sum() / de[d_outside.Region == region].sum()) / (dn.sum() / de.sum())
    changed = sorted(int(i) for i in raw.loc[spiked, "IDpol"])
    register = {
        "seed": seed,
        "level_outlier": {"factor": "Region", "level": region,
                          "mechanism": "exposure multiplied by exposure_factor on the region's policies with "
                                       "IDpol > 30,000 and exposure <= 1; claim counts unchanged",
                          "exposure_factor": c, "policies_changed": len(changed),
                          "exposure_before": float(freq.loc[spiked, "Exposure"].sum()),
                          "exposure_after": float(raw.loc[spiked, "Exposure"].sum()),
                          "policies_changed_sha256": hashlib.sha256(json.dumps(changed).encode()).hexdigest(),
                          "claims_added": 0,
                          "relativity_after_planting": float(rel_after)},
        "exposure_not_positive": {"rows": n_exp, "idpol": [int(i) for i in bad_exposure.IDpol]},
        "drivage_below_18": {"rows": n_age, "idpol": [int(i) for i in bad_age.IDpol],
                             "values": sorted(int(v) for v in bad_age.DrivAge)},
        "exact_duplicates": {"rows": n_dup, "idpol": sorted(int(i) for i in duplicates.IDpol)},
        "not_planted": "a x100 unit error in claim amounts: 42 genuine amounts are already >= 100,000, "
                       "so no rule could tell a planted one apart",
    }
    return delivered, register
