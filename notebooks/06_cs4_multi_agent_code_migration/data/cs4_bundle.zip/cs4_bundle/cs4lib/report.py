"""The migration report and the one-line RESULT, rendered by code.

The report agent writes only the narrative (sections 1, 2 and 4). The header (status, attempts, tests,
total against R, cost, time), the agent execution log (section 3), the test table (section 5) and the
list of files (section 6) come from the run log, not from a model. numbers_check() flags any number in
the narrative that does not appear in the run log (advisory: it reports, it does not block).
"""
from __future__ import annotations

import hashlib
import html
import json
import re
from collections import Counter

from .workspace import EXAMPLES, r_total


def short(value, limit: int = 300) -> str:
    """A string no longer than `limit` characters."""
    text = value if isinstance(value, str) else json.dumps(value, ensure_ascii=False, default=str)
    return text if len(text) <= limit else text[:limit] + f" ... [{len(text) - limit} more characters]"


def fmt_seconds(s: float) -> str:
    m, sec = divmod(int(round(s)), 60)
    return f"{m} min {sec} s" if m else f"{sec} s"


def cost_by_agent(rows: list[dict]) -> dict:
    """USD, calls and tokens (incl. cached, cache writes, reasoning) per agent, from per-call rows."""
    out: dict = {}
    for r in rows:
        a = out.setdefault(r["agent"], {"calls": 0, "usd": 0.0, "usd_no_cache": 0.0, "input_tokens": 0,
                                        "cached_tokens": 0, "cache_write_tokens": 0, "output_tokens": 0,
                                        "reasoning_tokens": 0, "seconds": 0.0})
        a["calls"] += 1
        for k in ("usd", "usd_no_cache", "input_tokens", "cached_tokens", "cache_write_tokens",
                  "output_tokens", "reasoning_tokens", "seconds"):
            a[k] += r[k]
    for a in out.values():
        a["usd"], a["usd_no_cache"], a["seconds"] = round(a["usd"], 6), round(a["usd_no_cache"], 6), round(a["seconds"], 2)
    return out


def final_tests(state) -> dict | None:
    for a in reversed(state.get("attempt_results", [])):
        if a.get("tests"):
            return a["tests"]
    return None


def total_vs_r(state, ws) -> dict:
    got = (ws.last_tests or {}).get("total_reserve_A")
    if got is None:
        got = (ws.last_check or {}).get("total_reserve_A")
    if state["example"] not in EXAMPLES:  # the VBA exercise has no total reserve
        return {"translation": None, "r": None, "rel_error": None}
    r = r_total(state["example"], ws.gt_a)
    return {"translation": got, "r": r, "rel_error": (abs(got - r) / abs(r)) if isinstance(got, (int, float)) else None}


def render_header(state, ws, seconds: float, usd: float, max_attempts: int) -> str:
    t = final_tests(state)
    tv = total_vs_r(state, ws)
    tests = "not run" if not t else (f"{t['n_passed']}/{t['n_tests']} ("
                                     + ", ".join(f"{c} {p}/{n}" for c, (p, n) in t["by_category"].items()) + ")")
    trip = "-"
    for a in reversed(state.get("attempt_results", [])):
        if a.get("compilation") and a["compilation"].get("tripwire"):
            trip = ws.tripwire.summary_line(a["compilation"]["tripwire"]).replace("tripwire: ", "")
            break
    total = ("not available" if tv["translation"] is None
             else f"{tv['translation']:,.6f} (R: {tv['r']:,.6f})")
    r_name = ws.spec["r_file"].split("/")[-1]
    rows = [f"# Migration Report: `{r_name}` to `{ws.spec['module']}`", "",
            "| Item | Value |", "|---|---|",
            f"| Status | {state['status'].upper()}" + (f" ({state['reason']})" if state.get("reason") else "") + " |",
            f"| Attempts | {state['attempts']} of at most {max_attempts} |",
            f"| Tests (last attempt) | {tests} |"]
    if tv["r"] is not None:
        rows.append(f"| Total reserve on the given data | {total} |")
    rows.append(f"| Tripwire (last attempt) | {trip} |")
    if state.get("approvals"):
        rows.append("| Human approval | " + "; ".join(f"attempt {a['attempt']}: {a['decision']}"
                                                     for a in state["approvals"]) + " |")
    rows += [f"| Orchestration misses | {len(state['misses'])} |",
             f"| Cost | USD {usd:.4f} at list prices |",
             f"| Time | {fmt_seconds(seconds)} |",
             f"| Run | {state['run_id']} ({state['variant']}) |", ""]
    return "\n".join(rows)


def render_code_sections(state, ws, calls: list[dict], agents: dict, max_attempts: int,
                         report_invoked: bool = False) -> tuple[str, str]:
    """Sections 3 (agent execution log) and 5 + 6 (test results, files), rendered by code. `calls` are the
    per-call rows of this run; `agents` the agent settings (for the model and effort columns)."""
    by_agent = cost_by_agent(calls)
    inv = Counter(e["node"] for e in state["node_log"])
    if report_invoked:  # the report node renders this before its own log entry exists
        inv["report"] += 1
    s3 = ["## 3. Agent Execution Log", "",
          "| Agent | Invocations | Model (effort) | API calls | Input tokens (cached) | Output tokens (reasoning) | USD |",
          "|---|---|---|---|---|---|---|"]
    for name in agents:
        a = by_agent.get(name)
        if not a and not inv.get(name):
            continue
        a = a or {"calls": 0, "input_tokens": 0, "cached_tokens": 0, "output_tokens": 0, "reasoning_tokens": 0, "usd": 0}
        spec = agents[name]
        s3.append(f"| {name} | {inv.get(name, 0)} | {spec['model']} ({spec['effort']}) | {a['calls']} | "
                  f"{a['input_tokens']:,} ({a['cached_tokens']:,}) | {a['output_tokens']:,} ({a['reasoning_tokens']:,}) | "
                  f"{a['usd']:.4f} |")
    s3 += ["", f"- Attempts: {state['attempts']} of at most {max_attempts}",
           f"- Orchestration misses: {len(state['misses'])}"
           + ("".join(f"\n  - {m['node']} (attempt {m['attempt']}): {m['what']}; {m['handled_by']}" for m in state["misses"])), ""]
    t = final_tests(state)
    s5 = ["## 5. Test Results", ""]
    if t:
        s5 += ["| Category | Passed | Total |", "|---|---|---|"]
        s5 += [f"| {c} | {p} | {n} |" for c, (p, n) in t["by_category"].items()]
        s5 += ["", f"Total: {t['n_passed']}/{t['n_tests']}."]
        if t["failures"]:
            s5 += ["", "Failed tests (value-free messages):"]
            s5 += [f"- `{f['id']}` [{f['category']}]: {f['message']}" for f in t["failures"]]
    else:
        s5 += ["The test suite did not run in this run."]
    src = ws.translation_source()
    s6 = ["", "## 6. Files Produced", "", "| Path | Description |", "|---|---|"]
    if src:
        s6.append(f"| {ws.module_rel} | the translation ({src.count(chr(10))} lines, sha256 "
                  f"{hashlib.sha256(src.encode('utf-8')).hexdigest()[:12]}) |")
    s6.append("| migration report | this report (header and sections 3, 5, 6 rendered by code) |")
    return "\n".join(s3), "\n".join(s5 + s6) + "\n"


NUM_RE = re.compile(r"(?<![\w.])[-+]?\d[\d,]*(?:\.\d+)?(?:[eE][-+]?\d+)?(?![\w])")


def _numbers(text: str, drop_numbering: bool) -> list[str]:
    if drop_numbering:  # headings "## 4." and list numbering "1. " are structure, not claims
        text = re.sub(r"(?m)^\s*(#+\s*)?\d+\.\s", "", text)
    return [m.group(0) for m in NUM_RE.finditer(text)]


def numbers_check(narrative: str, allowed_text: str) -> dict:
    """Flag every number in the narrative that does not appear in the run log (a decimal number may be a
    rounding of a logged number to the digits shown). Advisory: it reports, it does not block."""
    allowed_raw = {n.replace(",", "") for n in _numbers(allowed_text, False)}
    allowed_vals = []
    for s in allowed_raw:
        try:
            allowed_vals.append(float(s))
        except ValueError:
            pass
    found, flagged = _numbers(narrative or "", True), []
    for tok in found:
        s = tok.replace(",", "")
        if s in allowed_raw or s.lstrip("+-") in allowed_raw:
            continue
        try:
            x = float(s)
        except ValueError:
            flagged.append(tok)
            continue
        if "." in s and "e" not in s.lower():
            d = len(s.split(".")[1])
            if any(round(v, d) == x for v in allowed_vals):
                continue
        flagged.append(tok)
    return {"n_numbers": len(found), "flagged": sorted(set(flagged))}


def build_run_log(state, ws, max_attempts: int) -> dict:
    """What the report agent sees: value-free test results, diagnoses, notes, the analysis, the code."""
    detail = []
    for a in state.get("attempt_results", []):
        c, t = a.get("compilation") or {}, a.get("tests") or {}
        detail.append({
            "attempt": a["attempt"], "translator_notes": a.get("translator_notes", ""),
            "compilation": {"status": c.get("status"), "error_types": c.get("error_types"),
                            "tripwire": ws.tripwire.summary_line(c["tripwire"]) if c.get("tripwire") else None,
                            "agent": short(c.get("agent_text", ""), 800)} if c else None,
            "tests": {"n_passed": t.get("n_passed"), "n_tests": t.get("n_tests"), "by_category": t.get("by_category"),
                      "failures": [f["message"] for f in t.get("failures", [])],
                      "agent": short(t.get("agent_text", ""), 800)} if t else None})
    src = ws.translation_source() or ""
    return {"r_script": ws.spec["r_file"].split("/")[-1], "python_module": ws.module_rel,
            "status": state["status"], "reason": state.get("reason"), "attempts": state["attempts"],
            "max_attempts": max_attempts, "attempts_detail": detail, "orchestration_misses": state["misses"],
            "human_approvals": state.get("approvals", []),
            "analysis": short(state.get("analysis", ""), 3000),
            "final_translation": src if len(src) <= 14000 else src[:14000] + "\n# ... [truncated]"}


def result_line(state, ws, seconds: float, usd: float, max_attempts: int) -> str:
    t = final_tests(state)
    tv = total_vs_r(state, ws)
    tests = "tests not run" if not t else f"tests {t['n_passed']}/{t['n_tests']}"
    total = ("total n/a" if tv["translation"] is None
             else f"total {tv['translation']:,.6f} (R {tv['r']:,.6f})")
    status = {"passed": "PASSED", "escalated": "ESCALATED to a human"}.get(state["status"], state["status"].upper())
    total_part = f" | {total}" if tv["r"] is not None else ""
    return (f"RESULT {status} | attempt {state['attempts']} of {max_attempts} | {tests}{total_part} | "
            f"USD {usd:.4f} | {fmt_seconds(seconds)}")


def test_table(state) -> str:
    t = final_tests(state)
    if not t:
        return "(no test results)"
    rows = [f"{'category':<12} {'passed':>6} {'total':>5}"]
    rows += [f"{c:<12} {p:>6} {n:>5}" for c, (p, n) in t["by_category"].items()]
    rows.append(f"{'all':<12} {t['n_passed']:>6} {t['n_tests']:>5}")
    return "\n".join(rows)


def report_details_html(report: str, summary: str = "Migration report (click to open)") -> str:
    """The report collapsed in an HTML details block (for the notebook)."""
    return (f"<details><summary>{html.escape(summary)}</summary>\n\n<pre>"
            + html.escape(report) + "</pre></details>")
