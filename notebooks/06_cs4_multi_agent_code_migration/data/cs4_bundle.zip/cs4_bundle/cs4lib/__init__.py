"""cs4lib: the plumbing of notebook 06_cs4_multi_agent_code_migration (Case Study 4).

What participants read and change lives in the notebook's cells: the agent loop run_agent(), the file
tools, the five system prompts, the graph and its routing, the live printout, Part B's agents and
graph, and the exercises. This package holds the long plumbing the cells call:

    workspace   the agent workspace (set-up, the fenced check and test tools, the leak variant)
    tasks       what code shows each agent (its task message)
    report      the migration report rendered by code, the numbers check, the RESULT line
    recording   fingerprints, recordings, the path check and the replay of a recorded run
    drawing     the graph drawn with matplotlib from LangGraph's own nodes and edges
    scoring     scoring a module against the article's suites and the new suites (mutant demo)
    vba         exercise (b): the VBA workspace and its fenced tools
    partb       Part B: data, tools and registry, the verification gate and the nodes

The harness it relies on (runner, audit-hook fence, grader, tripwire) is in ../harness/, next to this
package in the same bundle. Nothing here calls a language model except partb.llm, which the notebook
configures with its own client, ledger and caps.

Parts of this package are adapted from the article's Case Study 4 (Hatzesberger and Nonneman 2026,
European Actuarial Journal 16(2):481-523); the article's code, data, tests and prompts are
Copyright (c) 2025 International Actuarial Association, MIT licence (see data/README.md).
"""
from pathlib import Path

BUNDLE_DIR = Path(__file__).resolve().parent.parent   # the unzipped bundle: cs4lib/ lives inside it
__version__ = "2026-09-23"
