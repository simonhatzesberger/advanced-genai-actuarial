"""The migration graph drawn with matplotlib from LangGraph's own nodes and edges.

No grandalf and no network (draw_mermaid_png() would call mermaid.ink): the boxes and arrows come from
app.get_graph().nodes and .edges, so the picture shows the graph that actually runs.
"""
from __future__ import annotations


def draw_graph(app, agents: dict, max_attempts: int, sol_model: str = "gpt-6-sol", title: str | None = None):
    """Draw the compiled graph. `agents` gives each agent node its model and effort (colour and label)."""
    import matplotlib.pyplot as plt
    from matplotlib.patches import FancyArrowPatch, FancyBboxPatch

    g = app.get_graph()
    order = ["__start__", "analysis", "translation", "compilation", "test_runner", "approval", "report", "__end__"]
    order = [n for n in order if n in g.nodes]
    pos = {n: (i * 2.0, 0.0) for i, n in enumerate(order)}
    width = 2.0 * (len(order) - 1)
    human = "approval" in g.nodes
    top_margin = 2.45 if human else 1.9
    fig, ax = plt.subplots(figsize=(12.5 * (width + 1.6) / 13.6, 3.9 * (top_margin + 2.3) / 4.2))
    ax.set_xlim(-0.8, width + 0.8)
    ax.set_ylim(-2.3, top_margin)
    ax.axis("off")
    colours = {"sol": "#1f5f8b", "luna": "#4a8c5c", "human": "#8c6d1f", "end": "#555555"}
    for nid in g.nodes:
        x, y = pos.get(nid, (0, 0))
        if nid in ("__start__", "__end__"):
            ax.add_patch(plt.Circle((x, y), 0.32, color=colours["end"]))
            ax.text(x, y, "START" if nid == "__start__" else "END", ha="center", va="center", color="white", fontsize=8)
            continue
        spec = agents.get(nid, {})
        kind = "human" if nid == "approval" else ("sol" if spec.get("model") == sol_model else "luna")
        ax.add_patch(FancyBboxPatch((x - 0.78, y - 0.42), 1.56, 0.84, boxstyle="round,pad=0.02,rounding_size=0.12",
                                    facecolor=colours[kind], edgecolor="none"))
        label = nid.replace("_", " ")
        if spec:
            label += f"\n{spec['model'].replace('gpt-6-', '')} ({spec['effort']})"
        elif nid == "approval":
            label += "\nhuman, interrupt()"
        ax.text(x, y, label, ha="center", va="center", color="white", fontsize=9)

    def arrow(a, b, side=None, rad=0.0, style="-", colour="#333333", dx_start=0.0, dx_end=0.0):
        """side=None: straight, box edge to box edge; side="top"/"bottom": an arc between the tops or the
        bottoms of the two boxes."""
        (x1, y1), (x2, y2) = pos[a], pos[b]
        if side is None:
            start = (x1 + (0.34 if a == "__start__" else 0.8), y1)
            end = (x2 - (0.34 if b == "__end__" else 0.8), y2)
        else:
            off = 0.45 if side == "top" else -0.45
            start, end = (x1 + dx_start, y1 + off), (x2 + dx_end, y2 + off)
        ax.add_patch(FancyArrowPatch(start, end, arrowstyle="-|>", mutation_scale=12, linestyle=style,
                                     connectionstyle=f"arc3,rad={rad}", color=colour, linewidth=1.3))

    # arcs back to the translator (top) and on to the report (bottom): (peak height, x offset at start, at end)
    top = {"compilation": (0.45, -0.2, 0.35), "test_runner": (1.0, -0.2, -0.1), "approval": (1.55, -0.2, -0.35)}
    bottom = {"compilation": (0.35, 0.1, -0.3), "translation": (0.7, 0.1, 0.05), "analysis": (1.05, 0.1, 0.4),
              "test_runner": (0.18, 0.1, -0.55)}
    for e in g.edges:
        a, b = e.source, e.target
        style = "--" if e.conditional else "-"
        adjacent = order.index(b) == order.index(a) + 1
        if b == "translation" and a in top:
            h, d0, d1 = top[a]
            dist = abs(pos[a][0] + d0 - pos[b][0] - d1)
            arrow(a, b, side="top", rad=2 * h / dist, style=style, colour="#b35900", dx_start=d0, dx_end=d1)
        elif b == "report" and a in bottom and not adjacent:
            h, d0, d1 = bottom[a]
            dist = abs(pos[b][0] + d1 - pos[a][0] - d0)
            arrow(a, b, side="bottom", rad=2 * h / dist, style=style, colour="#8b1f1f", dx_start=d0, dx_end=d1)
        else:
            arrow(a, b, style=style)
    ax.text(5.0, 1.02, "fail: retry", ha="center", fontsize=7.5, color="#b35900")
    ax.text(6.0, 1.58, f"fail, attempts < {max_attempts}: retry", ha="center", fontsize=7.5, color="#b35900")
    if human:
        ax.text(7.0, 2.12, "rejected by the reviewer: retry", ha="center", fontsize=7.5, color="#b35900")
    ax.text(width / 2, -1.8, "after the last attempt: escalate; API error, no credit or over budget: abort",
            ha="center", fontsize=7.5, color="#8b1f1f")
    ax.text(-0.7, -2.2, "Solid: fixed edge. Dashed: route decided in code from tool results. "
            "Blue: GPT-6 Sol; green: GPT-6 Luna" + ("; brown: a human decision." if "approval" in g.nodes else "."),
            fontsize=7.5, color="#333333")
    if title:
        ax.set_title(title, fontsize=10)
    fig.tight_layout()
    return fig
