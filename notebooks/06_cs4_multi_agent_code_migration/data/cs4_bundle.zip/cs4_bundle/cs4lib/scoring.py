"""Scoring a module against both test suites, without any API call (the mutant demonstration).

* The new suites (tests/): the module runs in the fenced runner (harness/runner.py), then the grader
  (harness/grade.py) compares its outputs with R's in a separate pytest process.
* The article's suites (tests_article/, changed only in their paths): they import the module under test
  into the pytest process, as the article did, so they run only on code that has been read (the bundle's
  mutants), never on fresh model output. A new-interface module is reached through the adapter in
  mutants/article_adapter/, which maps the article's calls onto it and does no arithmetic.
* The tripwire (harness/tripwire.py) scans the module's source, with triangle A's results as the
  reference for hardcoded numbers.
"""
from __future__ import annotations

import json
import math
import tempfile
from pathlib import Path

import numpy as np

from . import BUNDLE_DIR
from .workspace import EXAMPLES, harness_modules


def score_article_suite(example: str, module_path) -> dict:
    """The article's suite on a new-interface module (through the adapter)."""
    _, grade, _ = harness_modules()
    return grade.run_article_suite(example, str(BUNDLE_DIR / "mutants" / "article_adapter"), str(BUNDLE_DIR),
                                   adaptee=str(module_path))


def score_new_suite(example: str, module_path) -> dict:
    """The new suite: the fenced runner on every test input, then the grader."""
    runner, grade, _ = harness_modules()
    with tempfile.TemporaryDirectory(prefix="cs4score_") as tmp:
        out_json = Path(tmp) / "outputs.json"
        summary = runner.run_translation(example, str(module_path), str(BUNDLE_DIR), str(out_json), mode="all")
        verdict = grade.run_grader(example, str(out_json), str(BUNDLE_DIR))
    return {**verdict, "runner_status": summary["status"], "runner_seconds": summary["seconds"]}


def tripwire_report(example: str, source: str) -> dict:
    _, _, tripwire = harness_modules()
    keys = tripwire.load_answer_keys([BUNDLE_DIR / EXAMPLES[example]["gt_a"]])
    return tripwire.scan(source, keys)


def score(example: str, module_path, article: bool = True) -> dict:
    """Both suites and the tripwire for one module file."""
    src = Path(module_path).read_text(encoding="utf-8")
    out = {"new": score_new_suite(example, module_path), "tripwire": tripwire_report(example, src),
           "lines": src.count("\n")}
    if article:
        out["article"] = score_article_suite(example, module_path)
    return out


# ---- identical to R? (a translation re-run through the fenced runner) --------------------------------------
def _gt(name: str) -> dict:
    return json.loads((BUNDLE_DIR / "ground_truth" / f"{name}.json").read_text(encoding="utf-8"))


def _rel(a, e, floor=0.0) -> float:
    a, e = np.asarray(a, dtype=float), np.asarray(e, dtype=float)
    if a.shape != e.shape or np.any(np.isnan(a) != np.isnan(e)):
        return math.inf
    keep = ~(np.isnan(a) & np.isnan(e))
    a, e = a[keep], e[keep]
    if a.size == 0:
        return 0.0
    return float(np.max(np.abs(a - e) / np.maximum(np.abs(e), floor)))


def _val(call, key):
    v = call.get("values", {}).get(key, {})
    if v.get("kind") == "number":
        return v["value"]
    if v.get("kind") == "array":
        return v["values"]
    return v


def _col(call, key, column):
    return call.get("values", {}).get(key, {}).get("frame", {}).get("data", {}).get(column)


def chain_ladder_vs_r(source: str) -> dict:
    """Run a chain-ladder translation on every test input and compare six quantities with R's (relative
    error; 0.0 means bit-identical), plus the gap triangle and the printed total."""
    runner, _, _ = harness_modules()
    a, b = _gt("chain_ladder_A")["runs"], _gt("chain_ladder_B")["runs"]["tail_1.00"]
    with tempfile.TemporaryDirectory(prefix="cs4ident_") as tmp:
        mod = Path(tmp) / "chain_ladder.py"
        mod.write_text(source, encoding="utf-8", newline="\n")
        out_json = Path(tmp) / "out.json"
        summary = runner.run_translation("chain_ladder", str(mod), str(BUNDLE_DIR), str(out_json), mode="all")
        out = json.loads(out_json.read_text(encoding="utf-8"))
    c = out["calls"]
    res = {
        "total on A": _rel(_val(c["A"], "total_reserve"), a["tail_1.00"]["total_reserve"]),
        "factors on A": _rel(_val(c["A"], "dev_factors"), a["tail_1.00"]["dev_factors"]),
        "reserves by origin on A": _rel(_col(c["A"], "results", "unpaid_claims_reserve"),
                                        a["tail_1.00"]["unpaid_claims_reserve"], 1.0),
        "total on A with tail 1.05": _rel(_val(c["A_tail105"], "total_reserve"), a["tail_1.05"]["total_reserve"]),
        "total on B": _rel(_val(c["B"], "total_reserve"), b["total_reserve"]),
        "reserves by origin on B": _rel(_col(c["B"], "results", "unpaid_claims_reserve"), b["unpaid_claims_reserve"], 1.0),
    }
    tail = (c["main"].get("stdout_tail") or "").splitlines()
    printed = next((ln for ln in reversed(tail) if "Total Unpaid Claims Reserve" in ln), "").strip()
    return {"relative_errors": res,
            "gap_raises_ValueError": (not c["gap"].get("ok")) and c["gap"].get("error_type") == "ValueError",
            "printed_total_line": printed,
            "printed_total_equals_R": printed.endswith(f"{a['tail_1.00']['printed_total']:.2f}"),
            "runner_status": summary["status"], "runner_seconds": summary["seconds"]}
