# cs4_bundle: the files of notebook 06_cs4_multi_agent_code_migration

The notebook downloads this archive once, checks every file against `cs4_bundle_manifest.json` and unzips it
into `_local/cs4_bundle/`. Nothing in it calls a language model except `cs4lib/partb/llm.py`, which the notebook
configures with its own client, ledger and caps.

| Folder | What it holds |
|---|---|
| `legacy/` | the article's two R scripts and their data (LF line endings; `chain_ladder.R` was CRLF in the article's repository) |
| `inputs/` | the hidden triangles B and the gap triangle (inputs only, no results) |
| `ground_truth/` | R 4.5.2's results, one JSON per triangle, and R's printed transcripts |
| `harness/` | the runner, the audit-hook fence, the grader, the tripwire and the two interface texts |
| `tests/` | the new suites (16 tests each) with the value-free check helper |
| `tests_article/` | the article's suites, changed only in their paths (`CHANGES.md` has the diff) |
| `mutants/` | the honest references (m0), five deliberately wrong translations (m1 to m5), m2b (the 5-line stub of the notebook's section 7.6, written for the article's interface) and the adapter for the article's suites |
| `exercises/` | exercise (a): the R script with an injected comment; exercise (b): the VBA module, its interface, inputs, Excel ground truth, tests and adapter |
| `tools/` | how the inputs, the mutants and the ground truth were made (generators and the R harness) |
| `cs4lib/` | the notebook's plumbing: workspace and fenced tools, task messages, report, recordings, drawing, scoring, the VBA exercise, and Part B (data, tools and registry, gate and nodes) |

The article's R code, data, tests and the prompts adapted from it: Copyright (c) 2025 International Actuarial
Association, MIT licence. The notebook's `data/README.md` has the full notice and the provenance of every file.
