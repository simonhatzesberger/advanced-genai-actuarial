"""Adapter: the article's chain-ladder calls, answered by a NEW-interface module.

The article's suite calls ``run_chain_ladder(path)`` with a CSV path. The
mutants follow the new interface, ``run_chain_ladder(triangle_dataframe,
tail_factor)``. This adapter loads the module named by the environment
variable ``CS4_ADAPTEE`` and translates the call. It contains no actuarial
logic: it reads the CSV the way the interface says and passes the result on.
"""

import importlib.util
import os

import pandas as pd

_spec = importlib.util.spec_from_file_location("adaptee_chain_ladder", os.environ["CS4_ADAPTEE"])
_mod = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_mod)


def run_chain_ladder(path=None, tail_factor=1.0):
    return _mod.run_chain_ladder(pd.read_csv(path, index_col=0), tail_factor)


def main(path="triangle.csv"):
    return _mod.main(path)
