"""Adapter: the article's GLM calls, answered by a NEW-interface module.

The article's suite uses its own function signatures:
``load_claims_triangle(path)``, ``fit_odp_glm(data)`` returning a dict with
``model`` and ``phi``, ``predict_reserves(model, n_rows, n_cols)``,
``bootstrap_reserves(model, glm_data, triangle, n_boot, phi, seed)`` and
``run_analysis(csv, db, n_boot, seed)``. The mutants follow the new interface,
in which ``predict_reserves`` and ``bootstrap_reserves`` take the whole fit
dict. This adapter loads the module named by ``CS4_ADAPTEE`` and translates
the calls; it remembers which fit dict each model object came from. It
contains no actuarial logic.
"""

import importlib.util
import os

import pandas as pd

_spec = importlib.util.spec_from_file_location("adaptee_reserving_glm", os.environ["CS4_ADAPTEE"])
_mod = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_mod)
_FITS = {}  # id(model) -> the fit dict it belongs to


def load_claims_triangle(csv_path):
    return pd.read_csv(csv_path, index_col=0)


def load_policy_data(db_path):
    return _mod.load_policy_data(db_path)


def prepare_glm_data(triangle):
    return _mod.prepare_glm_data(triangle)


def fit_odp_glm(data):
    fit = _mod.fit_odp_glm(data)
    _FITS[id(fit["model"])] = fit
    return fit


def predict_reserves(model, n_rows, n_cols):
    return _mod.predict_reserves(_FITS[id(model)], n_rows, n_cols)


def bootstrap_reserves(model, glm_data, triangle, n_boot=100, phi=None, seed=42):
    n_rows, n_cols = triangle.shape
    return _mod.bootstrap_reserves(glm_data, _FITS[id(model)], n_rows, n_cols, n_boot=n_boot, seed=seed)


def run_analysis(claims_csv, db_path, n_boot=1000, seed=42):
    return _mod.run_analysis(claims_csv, db_path, n_boot=n_boot, seed=seed)
