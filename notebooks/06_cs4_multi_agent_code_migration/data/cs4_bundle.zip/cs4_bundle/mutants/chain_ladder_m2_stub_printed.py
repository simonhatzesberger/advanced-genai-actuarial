"""MUTANT 2 (chain ladder): a stub. No actuarial computation at all.

It returns the numbers R PRINTS for the given triangle (factors to 6 decimals,
amounts to 2 decimals, total 15,316.33), hardcoded, whatever triangle it is
given. Written by hand for the "does a suite have teeth?" demonstration.
"""

import numpy as np
import pandas as pd

ORIGINS = [str(y) for y in range(2010, 2020)]
DEVS = [f"dev_{k}" for k in range(1, 11)]
FACTORS = [1.805725, 1.294846, 1.150109, 1.098201, 1.049115, 1.032106, 1.021741, 1.011623, 1.006114]
CDF = [3.325405, 1.84159, 1.422247, 1.23662, 1.126041, 1.073324, 1.039936, 1.017808, 1.006114, 1.0]
LATEST = [3456.0, 3789.0, 4185.0, 4699.0, 5277.0, 5611.0, 5654.0, 5341.0, 4543.0, 2804.0]
ULTIMATE = [3456.0, 3812.16, 4259.52, 4886.66, 5663.93, 6318.21, 6991.85, 7596.22, 8366.34, 9324.44]
RESERVE = [0.0, 23.16, 74.52, 187.66, 386.93, 707.21, 1337.85, 2255.22, 3823.34, 6520.44]
NA = float("nan")
CUMULATIVE = [
    [1001.0, 1855.0, 2423.0, 2788.0, 3068.0, 3220.0, 3324.0, 3396.0, 3435.0, 3456.0],
    [1113.0, 2056.0, 2668.0, 3076.0, 3382.0, 3550.0, 3665.0, 3745.0, 3789.0, NA],
    [1265.0, 2293.0, 2988.0, 3441.0, 3781.0, 3968.0, 4096.0, 4185.0, NA, NA],
    [1490.0, 2674.0, 3450.0, 3961.0, 4344.0, 4555.0, 4699.0, NA, NA, NA],
    [1725.0, 3092.0, 3993.0, 4587.0, 5032.0, 5277.0, NA, NA, NA, NA],
    [1889.0, 3429.0, 4442.0, 5110.0, 5611.0, NA, NA, NA, NA, NA],
    [2105.0, 3801.0, 4918.0, 5654.0, NA, NA, NA, NA, NA, NA],
    [2318.0, 4141.0, 5341.0, NA, NA, NA, NA, NA, NA, NA],
    [2536.0, 4543.0, NA, NA, NA, NA, NA, NA, NA, NA],
    [2804.0, NA, NA, NA, NA, NA, NA, NA, NA, NA],
]


def run_chain_ladder(triangle, tail_factor=1.0):
    results = pd.DataFrame({
        "origin_year": ORIGINS,
        "latest_dev_period": DEVS[::-1],
        "latest_observed": LATEST,
        "cdf_to_ultimate": CDF[::-1],
        "ultimate": ULTIMATE,
        "unpaid_claims_reserve": RESERVE,
    })
    return {
        "cumulative": pd.DataFrame(CUMULATIVE, index=ORIGINS, columns=DEVS),
        "dev_factors": np.array(FACTORS),
        "n_pairs": np.arange(9, 0, -1),
        "cdf_to_ultimate": np.array(CDF),
        "results": results,
        "total_reserve": 15316.33,
    }


def main(path="triangle.csv"):
    out = run_chain_ladder(pd.read_csv(path, index_col=0))
    print(out["results"].to_string())
    print(f"\nTotal Unpaid Claims Reserve: {out['total_reserve']:.2f}")
    return out
