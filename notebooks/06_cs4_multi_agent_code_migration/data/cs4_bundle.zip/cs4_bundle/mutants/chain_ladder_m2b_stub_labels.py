"""MUTANT 2b (chain ladder): the 5-line stub from the design review.

Written for the ARTICLE's interface (run_chain_ladder(path)). It performs no
computation and returns only the row labels of the results table.
"""
import pandas as pd
def run_chain_ladder(path=None):
    """Stub: performs NO actuarial computation, only emits the expected labels."""
    return {"results": pd.DataFrame({"origin_year": [str(y) for y in range(2010, 2020)],
                                     "latest_dev_period": [f"dev_{k}" for k in range(10, 0, -1)]})}
