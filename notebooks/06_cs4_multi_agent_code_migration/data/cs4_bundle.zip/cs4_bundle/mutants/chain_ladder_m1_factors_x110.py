"""MUTANT 1 (chain ladder): every development factor is 10% too high.
One changed line in run_chain_ladder, marked '# MUTANT'. Otherwise the reference translation.

The reference translation's docstring follows.

Chain-ladder reserving: a hand-written reference translation of chain_ladder.R.

Written for Case Study 4 as the honest baseline against which the tests and
the mutants are calibrated. It follows the R script step by step:

1. read the incremental triangle and validate it (``stop()`` in R becomes
   ``ValueError`` here, ``warning()`` becomes ``warnings.warn``);
2. build the cumulative triangle;
3. volume-weighted age-to-age factors, using only rows where both ages are
   observed;
4. cumulative development factors to ultimate, starting from the tail factor;
5. ultimate claims and reserves per origin year.

All returned numbers are unrounded. Only ``main()`` rounds, for display, as
R's script does when it prints its tables.
"""

from __future__ import annotations

import warnings

import numpy as np
import pandas as pd


def _row_is_contiguous(row: np.ndarray) -> bool:
    """True if the observed cells of a row are dev_1..dev_k with no gaps (R's helper)."""
    obs = np.flatnonzero(~np.isnan(row))
    if obs.size == 0:
        return False
    return bool(np.array_equal(obs, np.arange(obs.max() + 1)))


def run_chain_ladder(triangle: pd.DataFrame, tail_factor: float = 1.0) -> dict:
    """Chain-ladder reserves for an incremental triangle.

    ``triangle``: incremental amounts, one row per origin period (the index
    holds the origin labels), one column per development period, NaN where
    not yet observed, as returned by ``pd.read_csv(path, index_col=0)``.
    """
    tri_inc = triangle.to_numpy(dtype=float)
    origin_years = [str(x) for x in triangle.index]
    dev_periods = [str(c) for c in triangle.columns]
    n_origin, n_dev = tri_inc.shape

    # ---- validation, in the order of the R script ----
    if n_origin == 0 or n_dev < 2:
        raise ValueError("Triangle must have at least 1 origin period and 2 development periods.")
    if any(pd.isna(x) or str(x) == "" for x in triangle.index):
        raise ValueError("Origin period names are missing.")
    if np.any((~np.isnan(tri_inc)).sum(axis=1) == 0):
        raise ValueError("At least one origin period has no observed data.")
    bad_rows = [i for i in range(n_origin) if not _row_is_contiguous(tri_inc[i])]
    if bad_rows:
        raise ValueError(
            "Triangle has internal missing values or does not start at development period 1 "
            f"for row(s): {', '.join(origin_years[i] for i in bad_rows)}. "
            "Clean the input triangle before reserving."
        )
    observed = tri_inc[~np.isnan(tri_inc)]
    if np.any(observed < 0):
        warnings.warn("Negative incremental values detected. Simple chain-ladder on cumulative data "
                      "may be unstable; review recoveries/re-openings.", UserWarning, stacklevel=2)

    # ---- cumulative triangle ----
    tri_cum = np.full((n_origin, n_dev), np.nan)
    for i in range(n_origin):
        obs = np.flatnonzero(~np.isnan(tri_inc[i]))
        tri_cum[i, obs] = np.cumsum(tri_inc[i, obs])
    for i in range(n_origin):
        obs = np.flatnonzero(~np.isnan(tri_cum[i]))
        if obs.size > 1 and np.any(np.diff(tri_cum[i, obs]) < 0):
            warnings.warn(f"Cumulative claims decrease for origin period {origin_years[i]}. "
                          "Review input data.", UserWarning, stacklevel=2)

    # ---- volume-weighted age-to-age factors ----
    dev_factors = np.full(n_dev - 1, np.nan)
    n_pairs = np.zeros(n_dev - 1, dtype=int)
    for j in range(n_dev - 1):
        valid = ~np.isnan(tri_cum[:, j]) & ~np.isnan(tri_cum[:, j + 1])
        n_pairs[j] = int(valid.sum())
        if n_pairs[j] == 0:
            raise ValueError(f"No observed pairs available to calculate development factor for "
                             f"{dev_periods[j]} -> {dev_periods[j + 1]}.")
        denom = tri_cum[valid, j].sum()
        if denom <= 0:
            raise ValueError(f"Non-positive denominator when calculating development factor for "
                             f"{dev_periods[j]} -> {dev_periods[j + 1]}.")
        dev_factors[j] = 1.10 * tri_cum[valid, j + 1].sum() / denom  # MUTANT: 10% too high
        if dev_factors[j] < 1:
            warnings.warn(f"Selected development factor for {dev_periods[j]} -> {dev_periods[j + 1]} "
                          f"is {dev_factors[j]:.4f} (< 1). Review whether simple chain-ladder is "
                          "appropriate.", UserWarning, stacklevel=2)

    # ---- cumulative development factors to ultimate (unrounded factors) ----
    cdf = np.full(n_dev, np.nan)
    cdf[n_dev - 1] = float(tail_factor)
    for j in range(n_dev - 2, -1, -1):
        cdf[j] = dev_factors[j] * cdf[j + 1]

    # ---- ultimates and reserves ----
    latest_idx = np.array([np.flatnonzero(~np.isnan(tri_cum[i])).max() for i in range(n_origin)])
    latest_observed = tri_cum[np.arange(n_origin), latest_idx]
    ultimate = latest_observed * cdf[latest_idx]
    reserve = ultimate - latest_observed

    results = pd.DataFrame({
        "origin_year": origin_years,
        "latest_dev_period": [dev_periods[k] for k in latest_idx],
        "latest_observed": latest_observed,
        "cdf_to_ultimate": cdf[latest_idx],
        "ultimate": ultimate,
        "unpaid_claims_reserve": reserve,
    })
    return {
        "cumulative": pd.DataFrame(tri_cum, index=triangle.index, columns=triangle.columns),
        "dev_factors": dev_factors,
        "n_pairs": n_pairs,
        "cdf_to_ultimate": cdf,
        "results": results,
        "total_reserve": float(reserve.sum()),
    }


def main(path: str = "triangle.csv") -> dict:
    """Read the CSV, print R's four tables (rounded for display) and return the results."""
    triangle = pd.read_csv(path, index_col=0)
    out = run_chain_ladder(triangle)
    dev = [str(c) for c in triangle.columns]
    with pd.option_context("display.width", 120, "display.max_columns", 20):
        print("Cumulative Triangle:")
        print(out["cumulative"].to_string(float_format=lambda v: f"{v:.0f}"))
        print("\nDevelopment Factors (volume-weighted):")
        print(pd.DataFrame({"from_dev": dev[:-1], "to_dev": dev[1:], "n_pairs": out["n_pairs"],
                            "factor": np.round(out["dev_factors"], 6)}).to_string())
        print("\nCDF to Ultimate:")
        print(pd.DataFrame({"dev_period": dev,
                            "cdf_to_ultimate": np.round(out["cdf_to_ultimate"], 6)}).to_string())
        shown = out["results"].copy()
        for col, digits in (("latest_observed", 2), ("cdf_to_ultimate", 6), ("ultimate", 2),
                            ("unpaid_claims_reserve", 2)):
            shown[col] = np.round(shown[col], digits)
        print("\nUltimate Claims by Origin Year:")
        print(shown.to_string())
    # Like R: the printed total is the sum of the ROUNDED reserves.
    printed_total = round(float(np.round(out["results"]["unpaid_claims_reserve"], 2).sum()), 2)
    print(f"\nTotal Unpaid Claims Reserve: {printed_total:.2f}")
    return out


if __name__ == "__main__":
    main()
