"""MUTANT 4 (GLM): bootstrap_reserves returns a constant: the point estimate of the
total reserve, n_boot times. The mean is right; there is no spread at all.
Two added lines at the top of bootstrap_reserves, marked '# MUTANT'.

The reference translation's docstring follows.

GLM reserving with bootstrap: a hand-written reference translation of reserving_glm.R.

Written for Case Study 4 as the honest baseline against which the tests and
the mutants are calibrated. It follows the R script:

1. ``load_policy_data``: three tables from SQLite; earned and written premium
   and the number of policies per origin year.
2. ``prepare_glm_data``: one row per observed cell (origin, dev, incremental).
3. ``fit_odp_glm``: over-dispersed Poisson GLM, log link, origin and
   development factors; phi = Pearson chi-square / residual degrees of
   freedom (what R's ``summary(glm(..., quasipoisson))$dispersion`` reports).
4. ``predict_reserves``: expected incremental claims for the future cells.
5. ``bootstrap_reserves``: R's algorithm (adjusted Pearson residuals,
   resampling with replacement, pseudo data floored at 1, refit, predict,
   gamma process step with the ORIGINAL phi). The random numbers come from
   NumPy's default generator, so single draws differ from R's; the
   distribution is the same.
6. ``run_analysis``: the whole pipeline, with reserve-to-premium ratios.

The GLM is fitted with statsmodels on an explicit design matrix
(treatment coding, first origin and first development period as the base,
like R's default contrasts). Nothing is rounded except in ``main()``'s
printout. ``run_analysis`` writes no files; ``main()`` writes
reserve_summary.csv like the R script.
"""

from __future__ import annotations

import sqlite3

import numpy as np
import pandas as pd
import statsmodels.api as sm


# ---------------------------------------------------------------------------
# 1. Policy data
# ---------------------------------------------------------------------------
def load_policy_data(db_path: str) -> dict:
    con = sqlite3.connect(db_path)
    try:
        policies = pd.read_sql_query("SELECT * FROM policies", con)
        premiums = pd.read_sql_query("SELECT * FROM premiums", con)
        claims = pd.read_sql_query("SELECT * FROM claims_detail", con)
    finally:
        con.close()
    merged = policies.merge(premiums, on="policy_id")
    premium_by_year = (merged.groupby("origin_year", as_index=False)
                       .agg(total_earned_premium=("earned_premium", "sum"),
                            total_written_premium=("written_premium", "sum"),
                            n_policies=("policy_id", "size"))
                       .sort_values("origin_year", ignore_index=True))
    return {"premium_by_year": premium_by_year, "policies": policies, "claims": claims}


# ---------------------------------------------------------------------------
# 2. GLM data
# ---------------------------------------------------------------------------
def prepare_glm_data(triangle: pd.DataFrame) -> pd.DataFrame:
    """Long format, one row per observed cell, ordered by origin then dev (as R's loops)."""
    values = triangle.to_numpy(dtype=float)
    n_rows, n_cols = values.shape
    rows = [(i + 1, j + 1, values[i, j]) for i in range(n_rows) for j in range(n_cols)
            if not np.isnan(values[i, j])]
    data = pd.DataFrame(rows, columns=["origin", "dev", "incremental"])
    data["origin"] = data["origin"].astype(int)
    data["dev"] = data["dev"].astype(int)
    data["origin_f"] = pd.Categorical(data["origin"])
    data["dev_f"] = pd.Categorical(data["dev"])
    return data


def _design(origin: np.ndarray, dev: np.ndarray, origin_levels, dev_levels) -> np.ndarray:
    """Intercept + dummies for origin levels 2.. and dev levels 2.. (R's treatment coding)."""
    X = np.zeros((len(origin), 1 + len(origin_levels) - 1 + len(dev_levels) - 1))
    X[:, 0] = 1.0
    for k, lev in enumerate(origin_levels[1:], start=1):
        X[:, k] = origin == lev
    base = len(origin_levels)
    for k, lev in enumerate(dev_levels[1:]):
        X[:, base + k] = dev == lev
    return X


def _fit(y: np.ndarray, X: np.ndarray):
    return sm.GLM(y, X, family=sm.families.Poisson()).fit(scale="X2")


# ---------------------------------------------------------------------------
# 3. ODP GLM
# ---------------------------------------------------------------------------
def fit_odp_glm(data: pd.DataFrame) -> dict:
    origin_levels = sorted(data["origin"].unique())
    dev_levels = sorted(data["dev"].unique())
    X = _design(data["origin"].to_numpy(), data["dev"].to_numpy(), origin_levels, dev_levels)
    model = _fit(data["incremental"].to_numpy(dtype=float), X)
    return {
        "model": model,
        "phi": float(model.scale),              # Pearson chi-square / residual df
        "deviance": float(model.deviance),
        "df_residual": int(round(model.df_resid)),
        "origin_levels": origin_levels,
        "dev_levels": dev_levels,
        "fitted": np.asarray(model.fittedvalues, dtype=float),
        "n_params": X.shape[1],
    }


# ---------------------------------------------------------------------------
# 4. Future cells
# ---------------------------------------------------------------------------
def _future_cells(n_rows: int, n_cols: int) -> pd.DataFrame:
    cells = [(i, j) for i in range(2, n_rows + 1) for j in range(n_cols - i + 2, n_cols + 1)]
    return pd.DataFrame(cells, columns=["origin", "dev"], dtype=int)


def _predict(params: np.ndarray, fit: dict, cells: pd.DataFrame) -> np.ndarray:
    X = _design(cells["origin"].to_numpy(), cells["dev"].to_numpy(),
                fit["origin_levels"], fit["dev_levels"])
    return np.exp(X @ params)


def predict_reserves(fit: dict, n_rows: int, n_cols: int) -> pd.DataFrame:
    cells = _future_cells(n_rows, n_cols)
    cells["predicted"] = _predict(np.asarray(fit["model"].params), fit, cells)
    return cells


# ---------------------------------------------------------------------------
# 5. Bootstrap
# ---------------------------------------------------------------------------
def bootstrap_reserves(glm_data: pd.DataFrame, fit: dict, n_rows: int, n_cols: int,
                       n_boot: int = 1000, seed: int = 42) -> np.ndarray:
    point = predict_reserves(fit, n_rows, n_cols)["predicted"].sum()  # MUTANT
    return np.full(n_boot, point)  # MUTANT: a constant instead of a bootstrap
    y = glm_data["incremental"].to_numpy(dtype=float)
    fitted = fit["fitted"]
    phi = fit["phi"]
    X = _design(glm_data["origin"].to_numpy(), glm_data["dev"].to_numpy(),
                fit["origin_levels"], fit["dev_levels"])
    n_obs, n_params = X.shape
    residuals = (y - fitted) / np.sqrt(fitted) * np.sqrt(n_obs / (n_obs - n_params))
    residuals = residuals[np.isfinite(residuals)]
    cells = _future_cells(n_rows, n_cols)
    X_future = _design(cells["origin"].to_numpy(), cells["dev"].to_numpy(),
                       fit["origin_levels"], fit["dev_levels"])

    rng = np.random.default_rng(seed)
    totals = []
    for _ in range(n_boot):
        resampled = rng.choice(residuals, size=len(fitted), replace=True)
        pseudo = np.maximum(fitted + resampled * np.sqrt(fitted), 1.0)
        try:
            pseudo_model = _fit(pseudo, X)
            predicted = np.exp(X_future @ np.asarray(pseudo_model.params))
        except Exception:  # R: tryCatch(..., error = NA), dropped afterwards
            continue
        simulated = rng.gamma(shape=predicted / phi, scale=phi)  # process variance
        totals.append(simulated.sum())
    return np.asarray(totals, dtype=float)


# ---------------------------------------------------------------------------
# 6. Whole analysis
# ---------------------------------------------------------------------------
def _summary(boot: np.ndarray) -> pd.DataFrame:
    q = np.quantile(boot, [0.25, 0.50, 0.75, 0.95, 0.99])  # same as R's default type 7
    return pd.DataFrame({
        "statistic": ["Mean", "Std Dev", "CV", "P25", "P50 (Median)", "P75", "P95", "P99"],
        "value": [boot.mean(), boot.std(ddof=1), boot.std(ddof=1) / boot.mean(), *q],
    })


def run_analysis(triangle_path: str, db_path: str, n_boot: int = 1000, seed: int = 42) -> dict:
    triangle = pd.read_csv(triangle_path, index_col=0)
    n_rows, n_cols = triangle.shape
    policy = load_policy_data(db_path)
    data = prepare_glm_data(triangle)
    fit = fit_odp_glm(data)
    pred = predict_reserves(fit, n_rows, n_cols)

    by_origin = pred.groupby("origin", as_index=False)["predicted"].sum().rename(
        columns={"predicted": "reserve"})
    origin_years = [int(v) for v in triangle.index]
    by_origin.insert(1, "origin_year", [origin_years[o - 1] for o in by_origin["origin"]])
    total = float(by_origin["reserve"].sum())

    boot = bootstrap_reserves(data, fit, n_rows, n_cols, n_boot=n_boot, seed=seed)

    ratios = by_origin[["origin_year", "reserve"]].merge(
        policy["premium_by_year"][["origin_year", "total_earned_premium"]], on="origin_year", how="left")
    ratios["reserve_to_premium"] = ratios["reserve"] / ratios["total_earned_premium"]
    ratios = ratios.sort_values("origin_year", ignore_index=True)

    return {
        "phi": fit["phi"],
        "deviance": fit["deviance"],
        "df_residual": fit["df_residual"],
        "reserves_by_origin": by_origin,
        "total_reserve": total,
        "boot_results": boot,
        "reserve_summary": _summary(boot),
        "premium_by_year": policy["premium_by_year"],
        "premium_ratios": ratios,
        "predictions": pred,
        "glm_data": data,
    }


def main(triangle_path: str = "claims_triangle.csv", db_path: str = "policies.db") -> dict:
    """Print what the R script prints (rounded for display) and write reserve_summary.csv."""
    out = run_analysis(triangle_path, db_path, n_boot=1000, seed=42)
    print(f"Dispersion parameter (phi): {out['phi']:.10f}")
    print(f"Residual deviance: {out['deviance']:.2f}")
    print(f"Degrees of freedom: {out['df_residual']}")
    print("\nReserves by origin year:")
    for _, r in out["reserves_by_origin"].iterrows():
        print(f"  Origin {int(r['origin'])}: {r['reserve']:.6f}")
    print(f"\nTotal reserve (point estimate): {out['total_reserve']:.6f}")
    summary = out["reserve_summary"].copy()
    summary["value"] = summary["value"].round(2)
    print("\nReserve Distribution Summary:")
    print(summary.to_string())
    shown = out["premium_ratios"].copy()
    shown["reserve_to_premium"] = shown["reserve_to_premium"].round(4)
    print("\nReserves with Premium Ratios:")
    print(shown.to_string())
    summary.to_csv("reserve_summary.csv", index=False)
    print("\nResults saved to reserve_summary.csv")
    return out


if __name__ == "__main__":
    main()
