"""Generate the hidden test inputs for Case Study 4 (Part A).

Writes, inside the bundle's ``inputs/`` folder:

* ``chain_ladder/triangle_B.csv``      a second 10 x 10 incremental triangle
                                        (same origin years 2010-2019 and column
                                        names dev_1..dev_10 as triangle A)
* ``chain_ladder/triangle_gap.csv``    triangle A with one internal missing
                                        cell (2013, dev_3): R's script stops
                                        with an error, so the Python version
                                        must raise ValueError
* ``reserving_glm/claims_triangle_B.csv``  a second 15 x 15 incremental
                                        triangle (origin years 2005-2019,
                                        dev_1..dev_15) with realistic noise, so
                                        that the over-dispersed Poisson (ODP)
                                        GLM has a dispersion phi well above 1

Everything is deterministic (fixed seeds, documented below). Run with the
pinned venv, from the bundle's root folder:

    python tools/make_inputs.py

(In the bundle this script sits in tools/; during the build it sat next to the
bundle folder. Only the path of the bundle changed.)

The script prints the checks it relies on. It uses its own small ODP
bootstrap (numpy + statsmodels) only to *choose* the GLM seed; the ground
truth itself comes from R (see tools/r/).
"""

from __future__ import annotations

import pathlib
import sys
import warnings

import numpy as np
import pandas as pd
import statsmodels.api as sm

HERE = pathlib.Path(__file__).resolve().parent
BUNDLE = HERE.parent                     # the bundle's root folder
LEGACY = BUNDLE / "legacy"
INPUTS = BUNDLE / "inputs"

# ---------------------------------------------------------------------------
# Seeds and generator settings (documented in README.md)
# ---------------------------------------------------------------------------
CL_SEED = 20261002          # chain ladder triangle B
GLM_SEED_START = 20260923   # first seed tried for GLM triangle B
GLM_SEED_TRIES = 40         # the search stops at the first seed that passes


def write_csv(df: pd.DataFrame, path: pathlib.Path) -> None:
    """Write a triangle like the article's files: LF endings, 'NA' for gaps."""
    path.parent.mkdir(parents=True, exist_ok=True)
    text = df.to_csv(na_rep="NA", lineterminator="\n", float_format="%.0f")
    path.write_bytes(text.encode("utf-8"))


# ---------------------------------------------------------------------------
# 1. Chain ladder, triangle B
# ---------------------------------------------------------------------------
def make_chain_ladder_b() -> pd.DataFrame:
    """Multiplicative origin x development model with mild lognormal noise.

    Triangle A develops quickly (CDF from dev_1 about 3.33). Triangle B has a
    larger volume and a slower, longer-tailed payment pattern, so its
    reserves differ from A's by well over 20% for every origin year.
    """
    rng = np.random.default_rng(CL_SEED)
    years = [str(y) for y in range(2010, 2020)]
    cols = [f"dev_{j}" for j in range(1, 11)]
    n = 10
    # volume per origin year: 1,700 growing about 6% a year, with noise
    volume = 1700.0 * 1.06 ** np.arange(n) * np.exp(rng.normal(0.0, 0.03, n))
    # incremental payment pattern (share of dev_1), slower than A's
    pattern = np.array([1.00, 0.97, 0.78, 0.62, 0.49, 0.37, 0.27, 0.19, 0.12, 0.07])
    tri = np.full((n, n), np.nan)
    for i in range(n):
        for j in range(n - i):
            noise = np.exp(rng.normal(0.0, 0.04))
            tri[i, j] = np.round(volume[i] * pattern[j] * noise)
    df = pd.DataFrame(tri, index=pd.Index(years, name="origin_year"), columns=cols)
    return df


def chain_ladder_reserves(df: pd.DataFrame) -> np.ndarray:
    """Plain volume-weighted chain ladder, only used for the >20% check here."""
    cum = df.to_numpy(float).cumsum(axis=1)
    n = cum.shape[1]
    f = []
    for j in range(n - 1):
        ok = ~np.isnan(cum[:, j]) & ~np.isnan(cum[:, j + 1])
        f.append(cum[ok, j + 1].sum() / cum[ok, j].sum())
    cdf = np.append(np.cumprod(np.array(f)[::-1])[::-1], 1.0)
    res = []
    for i in range(cum.shape[0]):
        k = np.max(np.where(~np.isnan(cum[i]))[0])
        res.append(cum[i, k] * cdf[k] - cum[i, k])
    return np.array(res), np.array(f)


# ---------------------------------------------------------------------------
# 2. GLM, triangle B
# ---------------------------------------------------------------------------
N_GLM = 15
OBS = [(i, j) for i in range(N_GLM) for j in range(N_GLM) if i + j < N_GLM]
FUT = [(i, j) for i in range(N_GLM) for j in range(N_GLM) if i + j >= N_GLM]


def _design(cells):
    """Treatment-coded design matrix (intercept, origin 2..n, dev 2..n)."""
    X = np.zeros((len(cells), 2 * N_GLM - 1))
    X[:, 0] = 1.0
    for k, (i, j) in enumerate(cells):
        if i > 0:
            X[k, i] = 1.0
        if j > 0:
            X[k, N_GLM - 1 + j] = 1.0
    return X


X_OBS, X_FUT = _design(OBS), _design(FUT)


def simulate_glm_b(seed: int) -> np.ndarray:
    """Origin x development means with gamma noise, variance = phi0 * mean^1.5.

    The variance power 1.5 lies between Poisson-type noise (power 1: tiny
    late cells become zero) and constant-CV noise (power 2: too little
    dispersion in the large early cells). The ODP GLM fitted to the result
    has a Pearson dispersion phi in the hundreds.
    """
    rng = np.random.default_rng(seed)
    a = 40000.0 * 1.05 ** np.arange(N_GLM) * np.exp(rng.normal(0.0, 0.04, N_GLM))
    j = np.arange(N_GLM)
    b = np.exp(-0.75 * j) + 0.008          # fast early development, flat tail
    b = b / b.sum()
    mean = np.outer(a, b)
    phi0, power = 10.0, 1.5
    y = np.full((N_GLM, N_GLM), np.nan)
    for (i, jj) in OBS:
        shape = mean[i, jj] ** (2.0 - power) / phi0
        y[i, jj] = np.round(rng.gamma(shape, mean[i, jj] / shape))
    return y


def odp_bootstrap(y: np.ndarray, n_boot: int, process: bool, seed: int = 42):
    """Same algorithm as the R script (adjusted Pearson residuals, pmax(.,1),
    refit, predict, gamma process step with the original phi)."""
    yv = np.array([y[i, j] for i, j in OBS])
    fit = sm.GLM(yv, X_OBS, family=sm.families.Poisson()).fit(scale="X2")
    mu, phi = fit.fittedvalues, fit.scale
    r = (yv - mu) / np.sqrt(mu) * np.sqrt(len(mu) / (len(mu) - X_OBS.shape[1]))
    rng = np.random.default_rng(seed)
    out = np.empty(n_boot)
    for b in range(n_boot):
        ys = np.maximum(mu + rng.choice(r, len(r), replace=True) * np.sqrt(mu), 1.0)
        pred = sm.GLM(ys, X_OBS, family=sm.families.Poisson()).fit(scale="X2").predict(X_FUT)
        out[b] = (rng.gamma(pred / phi, phi) if process else pred).sum()
    return phi, fit.predict(X_FUT).sum(), out


def glm_seed_ok(y: np.ndarray, verbose: bool = True):
    """Selection criteria for triangle B (all must hold)."""
    phi, reserve, boot = odp_bootstrap(y, 1000, True)
    _, _, boot0 = odp_bootstrap(y, 1000, False)
    cv = boot.std(ddof=1) / boot.mean()
    ratio = boot0.std(ddof=1) / boot.std(ddof=1)
    m4 = np.mean((boot - boot.mean()) ** 4) / boot.var() ** 2
    cells = y[~np.isnan(y)]
    checks = {
        "phi in [150, 600]": 150 <= phi <= 600,
        "bootstrap CV in [0.10, 0.20]": 0.10 <= cv <= 0.20,
        "SD without process step <= 0.82 x SD": ratio <= 0.82,
        "kurtosis <= 3.6": m4 <= 3.6,
        "smallest cell >= 3": cells.min() >= 3,
        "corner cells >= 10": min(y[0, N_GLM - 1], y[N_GLM - 1, 0]) >= 10,
        "total reserve differs from A's (55,030.64) by > 20%": abs(reserve / 55030.635 - 1) > 0.20,
    }
    stats = dict(phi=phi, reserve=reserve, boot_mean=boot.mean(), boot_sd=boot.std(ddof=1), cv=cv,
                 sd_ratio_without_process=ratio, kurtosis=m4, min_cell=cells.min(),
                 corners=(y[0, N_GLM - 1], y[N_GLM - 1, 0]))
    if verbose:
        print("   ", {k: (round(v, 4) if isinstance(v, float) else v) for k, v in stats.items()})
        print("   ", {k: v for k, v in checks.items()})
    return all(checks.values()), stats


def main() -> int:
    warnings.filterwarnings("ignore")
    # --- chain ladder B ---
    tri_a = pd.read_csv(LEGACY / "chain_ladder" / "triangle.csv", index_col=0)
    tri_b = make_chain_ladder_b()
    res_a, fa = chain_ladder_reserves(tri_a)
    res_b, fb = chain_ladder_reserves(tri_b)
    rel = np.abs(res_b[1:] / res_a[1:] - 1)
    print("chain ladder A total", res_a.sum().round(4), "B total", res_b.sum().round(4),
          "relative difference", round(res_b.sum() / res_a.sum() - 1, 4))
    print("  min per-origin relative difference (2011-2019):", rel.min().round(4))
    print("  B factors:", np.round(fb, 4), " all >= 1:", bool((fb >= 1).all()))
    assert rel.min() > 0.20 and abs(res_b.sum() / res_a.sum() - 1) > 0.20
    assert (fb >= 1).all() and (tri_b.to_numpy()[~np.isnan(tri_b.to_numpy())] > 0).all()
    write_csv(tri_b, INPUTS / "chain_ladder" / "triangle_B.csv")

    # --- chain ladder gap triangle ---
    gap = tri_a.copy()
    gap.loc[2013, "dev_3"] = np.nan
    gap.index = gap.index.astype(str)
    gap.index.name = "origin_year"
    write_csv(gap, INPUTS / "chain_ladder" / "triangle_gap.csv")

    # --- GLM B: first seed from GLM_SEED_START that meets every criterion ---
    chosen = None
    for seed in range(GLM_SEED_START, GLM_SEED_START + GLM_SEED_TRIES):
        y = simulate_glm_b(seed)
        print(f"GLM B candidate seed {seed}")
        ok, stats = glm_seed_ok(y)
        if ok:
            chosen = (seed, y, stats)
            break
    if chosen is None:
        print("no seed met the criteria", file=sys.stderr)
        return 1
    seed, y, stats = chosen
    print(f"GLM B: chosen seed {seed}")
    years = [str(v) for v in range(2005, 2020)]
    cols = [f"dev_{j}" for j in range(1, 16)]
    df = pd.DataFrame(y, index=pd.Index(years, name="origin_year"), columns=cols)
    write_csv(df, INPUTS / "reserving_glm" / "claims_triangle_B.csv")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
