"""Build bundle/mutants/ from the reference translations (DESIGN.md 3.8).

Each mutant is the full reference module with ONE deliberate change, marked
``# MUTANT``, plus a header saying what was changed. Mutant 2 is a stub.
Building them by text substitution (with checks that each substitution
applies exactly once) keeps the mutants in step with the reference.

    python tools/make_mutants.py        (from the bundle's root folder)

In the bundle the honest references are mutants/*_m0_reference.py; this script
reads them from there and rewrites the other mutants. (During the build the
references sat in a separate reference/ folder; only the paths changed.)
"""

from __future__ import annotations

import json
import pathlib

HERE = pathlib.Path(__file__).resolve().parent
BUNDLE = HERE.parent                     # the bundle's root folder
OUT = BUNDLE / "mutants"
REF_FILES = {"chain_ladder.py": OUT / "chain_ladder_m0_reference.py",
             "reserving_glm.py": OUT / "reserving_glm_m0_reference.py"}


def write(name: str, text: str) -> None:
    (OUT / name).write_bytes(text.encode("utf-8"))


def mutate(src: str, header: str, old: str, new: str) -> str:
    """Apply one substitution and put the header at the top of the module docstring.

    (A second docstring before the reference's own would push
    'from __future__ import annotations' off the top of the file: SyntaxError.)
    """
    assert src.count(old) == 1, f"substitution must apply exactly once: {old!r}"
    assert src.startswith('"""'), "the reference must start with its docstring"
    body = src.replace(old, new)
    return '"""' + header + "\n\nThe reference translation's docstring follows.\n\n" + body[3:]


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    cl = REF_FILES["chain_ladder.py"].read_text(encoding="utf-8")
    glm = REF_FILES["reserving_glm.py"].read_text(encoding="utf-8")

    # m0: the honest reference translations, unchanged (the baseline).
    write("chain_ladder_m0_reference.py", cl)
    write("reserving_glm_m0_reference.py", glm)

    # m1: every age-to-age factor 10% too high.
    write("chain_ladder_m1_factors_x110.py", mutate(
        cl,
        "MUTANT 1 (chain ladder): every development factor is 10% too high.\n"
        "One changed line in run_chain_ladder, marked '# MUTANT'. Otherwise the reference translation.",
        "        dev_factors[j] = tri_cum[valid, j + 1].sum() / denom\n",
        "        dev_factors[j] = 1.10 * tri_cum[valid, j + 1].sum() / denom  # MUTANT: 10% too high\n"))

    # m3: factors rounded to 6 decimals BEFORE chaining (as R prints them).
    write("chain_ladder_m3_rounded_factors.py", mutate(
        cl,
        "MUTANT 3 (chain ladder): the factors are rounded to 6 decimals before chaining,\n"
        "as R PRINTS them (R itself chains the unrounded factors). One added line, marked '# MUTANT'.",
        "    # ---- cumulative development factors to ultimate (unrounded factors) ----\n",
        "    dev_factors = np.round(dev_factors, 6)  # MUTANT: round before chaining\n"
        "    # ---- cumulative development factors to ultimate (unrounded factors) ----\n"))

    # m2: a stub that returns R's PRINTED numbers for triangle A, whatever the input.
    gt = json.loads((BUNDLE / "ground_truth" / "chain_ladder_A.json").read_text(encoding="utf-8"))
    g = gt["runs"]["tail_1.00"]
    t = g["printed_results_table"]
    fmt = lambda xs: "[" + ", ".join(repr(float(x)) for x in xs) + "]"  # noqa: E731
    cum_text = "[\n" + "".join(
        "    [" + ", ".join("NA" if v is None else repr(float(v)) for v in row) + "],\n"
        for row in g["cumulative"]) + "]"
    stub = f'''"""MUTANT 2 (chain ladder): a stub. No actuarial computation at all.

It returns the numbers R PRINTS for the given triangle (factors to 6 decimals,
amounts to 2 decimals, total 15,316.33), hardcoded, whatever triangle it is
given. Written by hand for the "does a suite have teeth?" demonstration.
"""

import numpy as np
import pandas as pd

ORIGINS = [str(y) for y in range(2010, 2020)]
DEVS = [f"dev_{{k}}" for k in range(1, 11)]
FACTORS = {fmt(g["printed_factor_table"])}
CDF = {fmt(t["cdf_to_ultimate"][::-1])}
LATEST = {fmt(t["latest_observed"])}
ULTIMATE = {fmt(t["ultimate"])}
RESERVE = {fmt(t["unpaid_claims_reserve"])}
NA = float("nan")
CUMULATIVE = {cum_text}


def run_chain_ladder(triangle, tail_factor=1.0):
    results = pd.DataFrame({{
        "origin_year": ORIGINS,
        "latest_dev_period": DEVS[::-1],
        "latest_observed": LATEST,
        "cdf_to_ultimate": CDF[::-1],
        "ultimate": ULTIMATE,
        "unpaid_claims_reserve": RESERVE,
    }})
    return {{
        "cumulative": pd.DataFrame(CUMULATIVE, index=ORIGINS, columns=DEVS),
        "dev_factors": np.array(FACTORS),
        "n_pairs": np.arange(9, 0, -1),
        "cdf_to_ultimate": np.array(CDF),
        "results": results,
        "total_reserve": {g["printed_total"]!r},
    }}


def main(path="triangle.csv"):
    out = run_chain_ladder(pd.read_csv(path, index_col=0))
    print(out["results"].to_string())
    print(f"\\nTotal Unpaid Claims Reserve: {{out['total_reserve']:.2f}}")
    return out
'''
    write("chain_ladder_m2_stub_printed.py", stub)

    # m2b: the 5-line stub of the design review (article interface; labels only).
    write("chain_ladder_m2b_stub_labels.py", '''"""MUTANT 2b (chain ladder): the 5-line stub from the design review.

Written for the ARTICLE's interface (run_chain_ladder(path)). It performs no
computation and returns only the row labels of the results table.
"""
import pandas as pd
def run_chain_ladder(path=None):
    """Stub: performs NO actuarial computation, only emits the expected labels."""
    return {"results": pd.DataFrame({"origin_year": [str(y) for y in range(2010, 2020)],
                                     "latest_dev_period": [f"dev_{k}" for k in range(10, 0, -1)]})}
''')

    # m4: the bootstrap returns a constant (the point estimate, n_boot times).
    write("reserving_glm_m4_constant_bootstrap.py", mutate(
        glm,
        "MUTANT 4 (GLM): bootstrap_reserves returns a constant: the point estimate of the\n"
        "total reserve, n_boot times. The mean is right; there is no spread at all.\n"
        "Two added lines at the top of bootstrap_reserves, marked '# MUTANT'.",
        '''                       n_boot: int = 1000, seed: int = 42) -> np.ndarray:
    y = glm_data["incremental"].to_numpy(dtype=float)
''',
        '''                       n_boot: int = 1000, seed: int = 42) -> np.ndarray:
    point = predict_reserves(fit, n_rows, n_cols)["predicted"].sum()  # MUTANT
    return np.full(n_boot, point)  # MUTANT: a constant instead of a bootstrap
    y = glm_data["incremental"].to_numpy(dtype=float)
'''))

    # m5: the bootstrap without the gamma process-variance step.
    write("reserving_glm_m5_no_process_variance.py", mutate(
        glm,
        "MUTANT 5 (GLM): the bootstrap omits the gamma process-variance step; each replicate\n"
        "is the sum of the refitted model's predictions. Parameter uncertainty only.\n"
        "One changed line in bootstrap_reserves, marked '# MUTANT'.",
        "        simulated = rng.gamma(shape=predicted / phi, scale=phi)  # process variance\n",
        "        simulated = predicted  # MUTANT: no process variance (gamma step removed)\n"))
    print("mutants written to", OUT)


if __name__ == "__main__":
    main()
