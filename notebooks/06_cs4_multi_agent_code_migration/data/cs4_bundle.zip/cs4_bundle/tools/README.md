# tools/: how the hidden inputs, the ground truth and the mutants were made

These scripts are shipped for provenance. The notebook does not run them.
Run them from the bundle's root folder.

| Script | What it writes | Needs |
|---|---|---|
| `make_inputs.py` | `inputs/chain_ladder/triangle_B.csv`, `inputs/chain_ladder/triangle_gap.csv`, `inputs/reserving_glm/claims_triangle_B.csv` (fixed seeds; the GLM seed is the first from 20260923 that meets the documented checks: 20260925) | numpy, pandas, statsmodels |
| `r/gt_chain_ladder.R` | `ground_truth/chain_ladder_A.json`, `chain_ladder_B.json`, `chain_ladder_gap.json` and the R transcripts | R 4.5.2 (base R) |
| `r/gt_reserving_glm.R` | `ground_truth/reserving_glm_A.json` or `reserving_glm_B.json` and the R transcripts | R 4.5.2 with DBI, RSQLite, dplyr |
| `r/gt_common.R` | helpers of the two R scripts | |
| `make_mutants.py` | `mutants/` m1 to m5 and m2b from the honest references `mutants/*_m0_reference.py` | |

```
python tools/make_inputs.py
Rscript --vanilla tools/r/gt_chain_ladder.R .
Rscript --vanilla tools/r/gt_reserving_glm.R . A
Rscript --vanilla tools/r/gt_reserving_glm.R . B
python tools/make_mutants.py
```

The R scripts run the legacy scripts unchanged. Each one evaluates the script text in a scratch folder
that holds the input under the file name the script expects, then reads the script's own objects.
The same text also runs once more with Rscript to produce the transcript. The only edit is for the tail
case, where `tail_factor <- 1.00` becomes `1.05`. Doubles are written with 17 significant digits.

Checked on 23 September 2026: `make_inputs.py` and `make_mutants.py`, run in this layout on a copy of the
bundle, reproduced every file byte for byte.

The VBA exercise's inputs and its ground truth (Excel's worksheet formula, computed through Excel over
COM) were made with build scripts outside the bundle. Its `ground_truth/` file records the Excel build.
