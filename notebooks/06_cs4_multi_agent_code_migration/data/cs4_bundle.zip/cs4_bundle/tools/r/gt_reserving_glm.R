# Ground truth for the GLM example, computed by the article's own R script
# (bundle/legacy/reserving_glm/reserving_glm.R), which is run UNCHANGED.
#
# How the script is reused: a scratch folder receives the triangle under the
# name the script expects ("claims_triangle.csv") and a copy of policies.db;
# the script text is evaluated in a fresh environment there, and the harness
# reads the script's own objects afterwards (phi, model, reserves_by_year,
# total_reserve, boot_results, reserve_summary, premium_by_year,
# reserves_with_premium). The same text is run once more with Rscript to keep
# the console transcript; the two runs must agree (set.seed(42) inside the
# script's bootstrap function makes them identical).
#
# Values added by the harness (not printed by the script) are marked as such:
# the unrounded reserve-to-premium ratio (R rounds it to 4 decimals) and the
# unrounded bootstrap summary (R rounds it to 2 decimals).
#
# Usage: Rscript gt_reserving_glm.R <bundle_dir> <A|B>

args <- commandArgs(trailingOnly = TRUE)
bundle <- normalizePath(args[1], winslash = "/")
which_tri <- args[2]
here <- dirname(normalizePath(sub("^--file=", "", grep("^--file=", commandArgs(FALSE), value = TRUE))))
source(file.path(here, "gt_common.R"))

script_path <- file.path(bundle, "legacy", "reserving_glm", "reserving_glm.R")
db_path <- file.path(bundle, "legacy", "reserving_glm", "policies.db")
tri_path <- if (which_tri == "A") {
  file.path(bundle, "legacy", "reserving_glm", "claims_triangle.csv")
} else {
  file.path(bundle, "inputs", "reserving_glm", "claims_triangle_B.csv")
}
src <- readLines(script_path, warn = FALSE)
gt_dir <- file.path(bundle, "ground_truth")
tr_dir <- file.path(gt_dir, "r_transcripts")
dir.create(tr_dir, showWarnings = FALSE, recursive = TRUE)
tag <- paste0("reserving_glm_", which_tri)

prepare <- function(suffix) {
  wd <- new_workdir(paste0(tag, suffix))
  file.copy(tri_path, file.path(wd, "claims_triangle.csv"))
  file.copy(db_path, file.path(wd, "policies.db"))
  wd
}

t0 <- Sys.time()
wd_env <- prepare("_env")
ev <- run_in_env(src, wd_env)
t_env <- as.numeric(difftime(Sys.time(), t0, units = "secs"))
if (!is.null(ev$error)) stop("R script failed: ", ev$error)

t1 <- Sys.time()
wd_rs <- prepare("_rs")
rs <- run_rscript(src, "reserving_glm.R", wd_rs)
t_rs <- as.numeric(difftime(Sys.time(), t1, units = "secs"))
transcript <- c(rs$stdout, if (length(rs$stderr)) c("", "---- stderr ----", rs$stderr))
write_lf(transcript, file.path(tr_dir, paste0(tag, ".txt")))

e <- ev$env
b <- e$boot_results
summ_unrounded <- list(
  mean = mean(b), sd = sd(b), cv = sd(b) / mean(b),
  p25 = unname(quantile(b, 0.25)), p50 = unname(quantile(b, 0.50)), p75 = unname(quantile(b, 0.75)),
  p95 = unname(quantile(b, 0.95)), p99 = unname(quantile(b, 0.99))
)
# The script also wrote reserve_summary.csv in each scratch folder; both runs must agree.
csv_env <- read.csv(file.path(wd_env, "reserve_summary.csv"))
csv_rs <- read.csv(file.path(wd_rs, "reserve_summary.csv"))

rwp <- e$reserves_with_premium
out <- list(
  example = "reserving_glm",
  triangle = which_tri,
  input = if (which_tri == "A") "legacy/reserving_glm/claims_triangle.csv" else "inputs/reserving_glm/claims_triangle_B.csv",
  policies_db = "legacy/reserving_glm/policies.db",
  note = paste("All values unrounded, from the R script's own objects, unless the field name says 'printed'.",
               "Fields marked harness_computed are derived from the script's objects by the harness."),
  n_rows = nrow(e$triangle_inc),
  n_cols = ncol(e$triangle_inc),
  origin_years = as.integer(rownames(e$triangle_raw)),
  glm_rows = nrow(e$glm_data),
  n_params = length(coef(e$model)),
  phi = e$phi,
  deviance = e$model$deviance,
  df_residual = e$model$df.residual,
  predictions_rows = nrow(e$predictions),
  predictions = list(origin = e$predictions$origin, dev = e$predictions$dev, predicted = e$predictions$predicted),
  reserves_by_origin = list(
    origin = as.integer(e$reserves_by_year$origin),
    origin_year = as.integer(rownames(e$triangle_raw))[e$reserves_by_year$origin],
    reserve = e$reserves_by_year$reserve
  ),
  total_reserve = e$total_reserve,
  policy_data = list(
    n_policies = nrow(e$policy_data$policies),
    n_claims = nrow(e$policy_data$claims),
    premium_by_year = list(
      origin_year = as.integer(e$premium_by_year$origin_year),
      total_earned_premium = e$premium_by_year$total_earned_premium,
      total_written_premium = e$premium_by_year$total_written_premium,
      n_policies = as.integer(e$premium_by_year$n_policies)
    )
  ),
  premium_ratios = list(
    origin_year = as.integer(rwp$origin_year),
    reserve = rwp$reserve,
    total_earned_premium = rwp$total_earned_premium,
    reserve_to_premium_harness_computed = rwp$reserve / rwp$total_earned_premium,
    reserve_to_premium_printed = rwp$reserve_to_premium
  ),
  bootstrap = list(
    seed = 42L,
    n_boot_requested = 1000L,
    n_success = length(b),
    rng_kind = paste(RNGkind(), collapse = " / "),
    summary_harness_computed = summ_unrounded,
    summary_printed = setNames(as.list(e$reserve_summary$value), e$reserve_summary$statistic),
    draws = as_array(b)
  ),
  checks = list(
    transcript_equals_harness_output = identical(rs$stdout, ev$stdout),
    reserve_summary_csv_equal_between_runs = isTRUE(all.equal(csv_env, csv_rs, tolerance = 0)),
    rscript_exit_status = rs$status,
    warnings_in_harness_run = as_array(ev$warnings)
  ),
  timing_seconds = list(harness_run = t_env, rscript_run = t_rs),
  transcript = paste0("r_transcripts/", tag, ".txt"),
  provenance = provenance(c(script_path, tri_path, db_path))
)
write_json_file(out, file.path(gt_dir, paste0(tag, ".json")))

cat(tag, "phi", sprintf("%.10f", e$phi), "deviance", sprintf("%.6f", e$model$deviance),
    "total", sprintf("%.6f", e$total_reserve), "\n")
cat("bootstrap n", length(b), "mean", sprintf("%.4f", mean(b)), "sd", sprintf("%.4f", sd(b)),
    "cv", sprintf("%.4f", sd(b) / mean(b)), "\n")
cat("transcript == harness output:", identical(rs$stdout, ev$stdout),
    " summary csv equal:", isTRUE(all.equal(csv_env, csv_rs, tolerance = 0)),
    " seconds:", round(t_env, 1), round(t_rs, 1), "\n")
