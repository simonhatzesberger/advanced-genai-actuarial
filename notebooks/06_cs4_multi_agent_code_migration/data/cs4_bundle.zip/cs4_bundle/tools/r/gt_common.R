# Shared helpers for the Case Study 4 ground-truth harness (R side).
#
# - to_json(): a small JSON writer that prints every double with 17
#   significant digits (enough to round-trip an IEEE double exactly).
# - run_in_env(): evaluates an R script's text in a fresh environment with
#   the working directory set to a scratch folder, so the harness can read
#   the script's own objects afterwards. The script's logic is not changed.
# - run_rscript(): runs the same script text with Rscript in the scratch
#   folder and keeps its console output as the transcript.
# - provenance(): R and package versions, RNG kind, file hashes.
#
# All files are written in binary mode so that they get LF line endings on
# Windows as well.

# English R messages in transcripts (the build machine runs a German locale).
Sys.setenv(LANGUAGE = "en")

json_escape <- function(s) {
  s <- gsub("\\", "\\\\", s, fixed = TRUE)
  s <- gsub("\"", "\\\"", s, fixed = TRUE)
  s <- gsub("\n", "\\n", s, fixed = TRUE)
  s <- gsub("\r", "\\r", s, fixed = TRUE)
  s <- gsub("\t", "\\t", s, fixed = TRUE)
  paste0("\"", s, "\"")
}

json_atom <- function(v) {
  if (is.na(v)) return("null")
  if (is.logical(v)) return(if (v) "true" else "false")
  if (is.integer(v)) return(sprintf("%d", v))
  if (is.numeric(v)) {
    if (!is.finite(v)) stop("non-finite number cannot be written to JSON")
    return(sprintf("%.17g", v))
  }
  json_escape(as.character(v))
}

# Length-1 atomic vectors become JSON scalars; longer ones become arrays.
# Wrap a vector in as_array() to force an array even when it has length 1.
as_array <- function(x) structure(list(x), class = "json_array")

to_json <- function(x, indent = 0) {
  pad <- strrep("  ", indent + 1)
  end <- strrep("  ", indent)
  if (inherits(x, "json_array")) {
    v <- x[[1]]
    return(paste0("[", paste(vapply(seq_along(v), function(i) json_atom(v[i]), ""), collapse = ", "), "]"))
  }
  if (is.null(x)) return("null")
  if (is.matrix(x)) {
    rows <- vapply(seq_len(nrow(x)), function(i) to_json(as_array(unname(x[i, ])), indent + 1), "")
    return(paste0("[\n", pad, paste(rows, collapse = paste0(",\n", pad)), "\n", end, "]"))
  }
  if (is.data.frame(x)) x <- as.list(x)
  if (is.list(x)) {
    if (length(x) == 0) return(if (is.null(names(x))) "[]" else "{}")
    if (!is.null(names(x))) {
      items <- vapply(names(x), function(k) paste0(json_escape(k), ": ", to_json(x[[k]], indent + 1)), "")
      return(paste0("{\n", pad, paste(items, collapse = paste0(",\n", pad)), "\n", end, "}"))
    }
    items <- vapply(x, function(v) to_json(v, indent + 1), "")
    return(paste0("[\n", pad, paste(items, collapse = paste0(",\n", pad)), "\n", end, "]"))
  }
  if (is.factor(x)) x <- as.character(x)
  if (length(x) == 1) return(json_atom(x))
  paste0("[", paste(vapply(seq_along(x), function(i) json_atom(x[i]), ""), collapse = ", "), "]")
}

write_lf <- function(lines, path) {
  con <- file(path, open = "wb")
  on.exit(close(con))
  writeLines(enc2utf8(lines), con, sep = "\n", useBytes = TRUE)
}

write_json_file <- function(x, path) write_lf(to_json(x), path)

sha256 <- function(path) unname(as.character(tools::sha256sum(path)))

# Evaluate the script text in a fresh environment; capture printed output,
# warnings and a possible stop() message.
run_in_env <- function(src_lines, workdir) {
  env <- new.env(parent = globalenv())
  old <- setwd(workdir)
  on.exit(setwd(old))
  warns <- character()
  err <- NULL
  out <- utils::capture.output({
    res <- tryCatch(
      withCallingHandlers(
        eval(parse(text = src_lines, keep.source = FALSE), envir = env),
        warning = function(w) {
          warns <<- c(warns, conditionMessage(w))
          invokeRestart("muffleWarning")
        }
      ),
      error = function(e) e
    )
  })
  if (inherits(res, "error")) err <- conditionMessage(res)
  list(env = env, stdout = out, warnings = warns, error = err)
}

# Run the script text with Rscript (as a user would) and keep its output.
run_rscript <- function(src_lines, script_name, workdir) {
  write_lf(src_lines, file.path(workdir, script_name))
  old <- setwd(workdir)
  on.exit(setwd(old))
  out_file <- "stdout.txt"
  err_file <- "stderr.txt"
  rscript <- file.path(R.home("bin"), if (.Platform$OS.type == "windows") "Rscript.exe" else "Rscript")
  status <- system2(rscript, c("--vanilla", shQuote(script_name)), stdout = out_file, stderr = err_file,
                    wait = TRUE)
  list(status = status,
       stdout = readLines(out_file, warn = FALSE),
       stderr = readLines(err_file, warn = FALSE))
}

new_workdir <- function(tag) {
  d <- tempfile(paste0("cs4gt_", tag, "_"))
  dir.create(d)
  d
}

provenance <- function(files) {
  pk <- c("DBI", "RSQLite", "dplyr")
  list(
    r_version = R.version.string,
    platform = R.version$platform,
    os = utils::sessionInfo()$running,
    packages = setNames(lapply(pk, function(p) as.character(utils::packageVersion(p))), pk),
    rng_kind = paste(RNGkind(), collapse = " / "),
    lc_numeric = Sys.getlocale("LC_NUMERIC"),
    created_utc = format(Sys.time(), "%Y-%m-%dT%H:%M:%SZ", tz = "UTC"),
    number_format = "doubles written with sprintf('%.17g')",
    file_sha256 = setNames(lapply(files, sha256), basename(files))
  )
}
