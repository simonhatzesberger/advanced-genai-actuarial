# Ground truth for the chain-ladder example, computed by the article's own R
# script (bundle/legacy/chain_ladder/chain_ladder.R).
#
# How the script is reused: its text is evaluated unchanged in a scratch
# folder that holds the triangle under the name the script expects
# ("triangle.csv"). The harness then reads the script's own objects
# (triangle_cum, dev_factors, n_pairs, cdf_to_ultimate, latest_observed,
# latest_dev_idx, ultimate_claims, reserve_amount). For the tail-factor run
# exactly one line is replaced: "tail_factor <- 1.00" becomes
# "tail_factor <- 1.05". The same script text is also run with Rscript to
# keep the console transcript.
#
# Usage: Rscript gt_chain_ladder.R <bundle_dir>

args <- commandArgs(trailingOnly = TRUE)
bundle <- normalizePath(args[1], winslash = "/")
here <- dirname(normalizePath(sub("^--file=", "", grep("^--file=", commandArgs(FALSE), value = TRUE))))
source(file.path(here, "gt_common.R"))

script_path <- file.path(bundle, "legacy", "chain_ladder", "chain_ladder.R")
src <- readLines(script_path, warn = FALSE)
gt_dir <- file.path(bundle, "ground_truth")
tr_dir <- file.path(gt_dir, "r_transcripts")
dir.create(tr_dir, showWarnings = FALSE, recursive = TRUE)

tail_line <- grep("^tail_factor <- 1\\.00", src)
stopifnot(length(tail_line) == 1)

run_case <- function(triangle_file, tail = c("1.00", "1.05"), tag) {
  tail <- match.arg(tail)
  lines <- src
  if (tail == "1.05") lines[tail_line] <- sub("1.00", "1.05", lines[tail_line], fixed = TRUE)
  wd_env <- new_workdir(paste0(tag, "_env"))
  wd_rs <- new_workdir(paste0(tag, "_rs"))
  file.copy(triangle_file, file.path(wd_env, "triangle.csv"))
  file.copy(triangle_file, file.path(wd_rs, "triangle.csv"))
  ev <- run_in_env(lines, wd_env)
  rs <- run_rscript(lines, "chain_ladder.R", wd_rs)
  transcript <- c(rs$stdout, if (length(rs$stderr)) c("", "---- stderr ----", rs$stderr))
  write_lf(transcript, file.path(tr_dir, paste0(tag, ".txt")))
  list(ev = ev, rs = rs, tail = as.numeric(tail),
       transcript_file = paste0("r_transcripts/", tag, ".txt"),
       lines_changed = if (tail == "1.05") as_array(tail_line) else as_array(integer(0)))
}

extract <- function(case) {
  e <- case$ev$env
  total_line <- grep("Total Unpaid Claims Reserve:", case$rs$stdout, value = TRUE)
  printed_total <- as.numeric(sub(".*Total Unpaid Claims Reserve:\\s*([0-9.eE+-]+).*", "\\1", total_line))
  list(
    tail_factor = case$tail,
    script_lines_changed = case$lines_changed,
    origin_years = e$origin_years,
    dev_periods = e$dev_periods,
    cumulative = unname(e$triangle_cum),
    dev_factors = e$dev_factors,
    n_pairs = e$n_pairs,
    cdf_to_ultimate = e$cdf_to_ultimate,
    latest_dev_idx = e$latest_dev_idx,
    latest_dev_period = e$dev_periods[e$latest_dev_idx],
    latest_observed = e$latest_observed,
    ultimate = e$ultimate_claims,
    unpaid_claims_reserve = e$reserve_amount,
    total_reserve = sum(e$reserve_amount),
    printed_total = printed_total,
    printed_results_table = list(
      latest_observed = e$results$latest_observed,
      cdf_to_ultimate = e$results$cdf_to_ultimate,
      ultimate = e$results$ultimate,
      unpaid_claims_reserve = e$results$unpaid_claims_reserve
    ),
    printed_factor_table = e$dev_factor_table$factor,
    warnings = as_array(case$ev$warnings),
    rscript_exit_status = case$rs$status,
    transcript = case$transcript_file,
    transcript_equals_harness_output = identical(case$rs$stdout, case$ev$stdout)
  )
}

tri_a <- file.path(bundle, "legacy", "chain_ladder", "triangle.csv")
tri_b <- file.path(bundle, "inputs", "chain_ladder", "triangle_B.csv")
tri_gap <- file.path(bundle, "inputs", "chain_ladder", "triangle_gap.csv")

# ---- triangle A: tail 1.00 and tail 1.05 ----
a1 <- run_case(tri_a, "1.00", "chain_ladder_A")
a2 <- run_case(tri_a, "1.05", "chain_ladder_A_tail105")
stopifnot(is.null(a1$ev$error), is.null(a2$ev$error))
write_json_file(list(
  example = "chain_ladder",
  triangle = "A",
  input = "legacy/chain_ladder/triangle.csv",
  note = "All values unrounded, from the R script's own objects; printed_* fields are what R prints (rounded).",
  runs = list(tail_1.00 = extract(a1), tail_1.05 = extract(a2)),
  provenance = provenance(c(script_path, tri_a))
), file.path(gt_dir, "chain_ladder_A.json"))

# ---- triangle B (hidden) ----
b1 <- run_case(tri_b, "1.00", "chain_ladder_B")
stopifnot(is.null(b1$ev$error))
write_json_file(list(
  example = "chain_ladder",
  triangle = "B",
  input = "inputs/chain_ladder/triangle_B.csv",
  note = "Hidden second triangle; never placed in an agent workspace.",
  runs = list(tail_1.00 = extract(b1)),
  provenance = provenance(c(script_path, tri_b))
), file.path(gt_dir, "chain_ladder_B.json"))

# ---- gap triangle: R stops ----
g <- run_case(tri_gap, "1.00", "chain_ladder_gap")
stopifnot(!is.null(g$ev$error))
write_json_file(list(
  example = "chain_ladder",
  triangle = "gap",
  input = "inputs/chain_ladder/triangle_gap.csv",
  r_stops = TRUE,
  r_error_message = g$ev$error,
  rscript_exit_status = g$rs$status,
  transcript = g$transcript_file,
  provenance = provenance(c(script_path, tri_gap))
), file.path(gt_dir, "chain_ladder_gap.json"))

cat("chain ladder A total (unrounded):", sprintf("%.10f", sum(a1$ev$env$reserve_amount)), "\n")
cat("chain ladder A printed total:", grep("Total Unpaid", a1$rs$stdout, value = TRUE), "\n")
cat("chain ladder A tail 1.05 total:", sprintf("%.10f", sum(a2$ev$env$reserve_amount)), "\n")
cat("chain ladder B total:", sprintf("%.10f", sum(b1$ev$env$reserve_amount)), "\n")
cat("gap error:", g$ev$error, "\n")
cat("transcript == harness output:", identical(a1$rs$stdout, a1$ev$stdout), identical(b1$rs$stdout, b1$ev$stdout), "\n")
