"""Test suite for the GLM reserving migration (Case Study 4).

Every number the tests check was computed by the translated code (recorded
by harness/runner.py) and is compared with R's own results
(ground_truth/*.json). Nothing is recomputed here.

Categories: interface, numbers_A (the given triangle), hidden_B (a second,
over-dispersed triangle the agents never see), scaling (every cell doubled),
bootstrap_A / bootstrap_B (1,000 draws each, compared with R's 1,000 draws in
distribution, because Python's and R's random generators differ), seeds.

Tolerances: deterministic outputs relative 1e-6; bootstrap mean within 4
Monte Carlo standard errors of R's; bootstrap standard deviation within
+/-10% of R's. Measured margins of the reference translation are in the
harness README.
"""

from __future__ import annotations

import numpy as np
import pytest

import valuefree as vf

RTOL = 1e-6
FUNCTIONS = ["load_policy_data", "prepare_glm_data", "fit_odp_glm", "predict_reserves",
             "bootstrap_reserves", "run_analysis"]
KEYS = ["phi", "deviance", "df_residual", "reserves_by_origin", "total_reserve", "boot_results",
        "premium_by_year", "premium_ratios"]
WHAT = {"A": "run_analysis on the given data", "B": "run_analysis on a second triangle",
        "policy_data": "load_policy_data", "steps_A": "prepare/fit/predict on the given triangle",
        "steps_A_x2": "prepare/fit/predict on the doubled triangle",
        "seed42_a": "bootstrap_reserves(seed=42)", "seed42_b": "bootstrap_reserves(seed=42), repeated",
        "seed43": "bootstrap_reserves(seed=43)"}


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------
def call_of(outputs: dict, cid: str) -> dict:
    hidden = cid == "B"
    if not outputs.get("import", {}).get("ok"):
        vf.fail("the module could not be imported", hidden)
    call = outputs.get("calls", {}).get(cid)
    if call is None:
        vf.fail(f"{WHAT[cid]}: not run", hidden)
    if not call.get("ok"):
        vf.fail(f"{WHAT[cid]}: raised {call.get('error_type', 'an exception')}", hidden)
    return call


def dict_value(call: dict, key: str, cid: str) -> dict:
    hidden = cid == "B"
    if call.get("returned_type") != "dict":
        vf.fail(f"{WHAT[cid]}: did not return a dict", hidden)
    v = call.get("values", {}).get(key)
    if v is None:
        vf.fail(f"{WHAT[cid]}: key '{key}' missing", hidden)
    return v


def number(v: dict, name: str, hidden: bool = False):
    vf.require(v.get("kind") == "number" and v.get("value") is not None, f"{name}: expected a finite number",
               hidden)
    return v["value"]


def column(v: dict, col: str, name: str, hidden: bool = False) -> list:
    vf.require(v.get("kind") == "frame", f"{name}: expected a DataFrame", hidden)
    data = v["frame"]["data"]
    vf.require(col in data, f"{name}: column '{col}' missing", hidden)
    return data[col]


def draws_of(v: dict, name: str, hidden: bool = False) -> np.ndarray:
    vf.require(v.get("kind") == "array", f"{name}: expected an array of draws", hidden)
    vals = v.get("values", [])
    vf.require(all(x is not None for x in vals), f"{name}: contains missing or non-finite draws", hidden)
    return np.asarray(vals, dtype=float)


@pytest.fixture(scope="module")
def gt_a(ground_truth):
    return ground_truth("reserving_glm_A.json")


@pytest.fixture(scope="module")
def gt_b(ground_truth):
    return ground_truth("reserving_glm_B.json")


# ---------------------------------------------------------------------------
# interface
# ---------------------------------------------------------------------------
@pytest.mark.category("interface")
def test_module_imports_and_exposes_interface(outputs):
    imp = outputs.get("import", {})
    vf.require(imp.get("ok"), f"the module could not be imported ({imp.get('error_type', 'error')})")
    missing = [f for f in FUNCTIONS if f not in imp.get("callables", [])]
    vf.require(not missing, f"missing function(s): {', '.join(missing)}")


@pytest.mark.category("interface")
def test_return_structures(outputs):
    call = call_of(outputs, "A")
    vf.require(call.get("returned_type") == "dict", "run_analysis: did not return a dict")
    missing = [k for k in KEYS if k not in call.get("keys", [])]
    vf.require(not missing, f"run_analysis: key(s) missing: {', '.join(missing)}")
    v = call["values"]
    for key in ("phi", "deviance", "total_reserve"):
        vf.require(v[key].get("kind") == "number", f"{key}: expected a float")
    vf.require(v["df_residual"].get("kind") == "number" and v["df_residual"].get("value") is not None
               and float(v["df_residual"]["value"]).is_integer(), "df_residual: expected an integer")
    rbo = v["reserves_by_origin"]
    vf.require(rbo.get("kind") == "frame" and rbo["frame"]["n_rows"] == 14,
               "reserves_by_origin: expected a DataFrame with one row per origin 2..15")
    for col in ("origin", "origin_year", "reserve"):
        column(rbo, col, "reserves_by_origin")
    vf.require(v["boot_results"].get("kind") == "array", "boot_results: expected a numpy array")
    pby = v["premium_by_year"]
    vf.require(pby.get("kind") == "frame" and pby.get("columns") == [
        "origin_year", "total_earned_premium", "total_written_premium", "n_policies"]
               and pby["frame"]["n_rows"] == 15,
               "premium_by_year: expected 15 rows with columns origin_year, total_earned_premium, "
               "total_written_premium, n_policies")
    pr = v["premium_ratios"]
    for col in ("origin_year", "reserve", "total_earned_premium", "reserve_to_premium"):
        column(pr, col, "premium_ratios")
    steps = call_of(outputs, "steps_A")
    gd = steps["glm_data"]
    vf.require(gd.get("kind") == "frame" and gd["frame"]["n_rows"] == 120,
               "prepare_glm_data: expected one row per observed cell (120)")
    for col in ("origin", "dev", "incremental", "origin_f", "dev_f"):
        vf.require(col in gd.get("columns", []), f"prepare_glm_data: column '{col}' missing")
    pred = steps["predictions"]
    vf.require(pred.get("kind") == "frame" and pred["frame"]["n_rows"] == 105,
               "predict_reserves: expected one row per future cell (105)")
    for col in ("origin", "dev", "predicted"):
        column(pred, col, "predict_reserves")
    fit = steps["fit"]
    vf.require(fit.get("returned_type") == "dict", "fit_odp_glm: did not return a dict")
    for key in ("phi", "deviance", "df_residual"):
        vf.require(key in fit.get("keys", []), f"fit_odp_glm: key '{key}' missing")


# ---------------------------------------------------------------------------
# the given triangle A
# ---------------------------------------------------------------------------
@pytest.mark.category("numbers_A")
def test_dispersion_and_deviance_A(outputs, gt_a):
    call = call_of(outputs, "A")
    vf.check_close("phi", number(dict_value(call, "phi", "A"), "phi"), gt_a["phi"], RTOL, floor=0.0)
    vf.check_close("deviance", number(dict_value(call, "deviance", "A"), "deviance"), gt_a["deviance"], RTOL,
                   floor=0.0)
    vf.check_equal("df_residual", [int(number(dict_value(call, "df_residual", "A"), "df_residual"))],
                   [gt_a["df_residual"]])


@pytest.mark.category("numbers_A")
def test_reserves_by_origin_A(outputs, gt_a):
    v = dict_value(call_of(outputs, "A"), "reserves_by_origin", "A")
    vf.check_equal("reserves_by_origin.origin", [int(x) for x in column(v, "origin", "reserves_by_origin")],
                   gt_a["reserves_by_origin"]["origin"])
    vf.check_equal("reserves_by_origin.origin_year",
                   [int(x) for x in column(v, "origin_year", "reserves_by_origin")],
                   gt_a["reserves_by_origin"]["origin_year"])
    vf.check_close("reserves_by_origin.reserve", column(v, "reserve", "reserves_by_origin"),
                   gt_a["reserves_by_origin"]["reserve"], RTOL)


@pytest.mark.category("numbers_A")
def test_total_reserve_A(outputs, gt_a):
    call = call_of(outputs, "A")
    vf.check_close("total_reserve", number(dict_value(call, "total_reserve", "A"), "total_reserve"),
                   gt_a["total_reserve"], RTOL)


@pytest.mark.category("numbers_A")
def test_premiums_and_ratios_A(outputs, gt_a):
    call = call_of(outputs, "A")
    pby = dict_value(call, "premium_by_year", "A")
    g = gt_a["policy_data"]["premium_by_year"]
    for col in ("origin_year", "n_policies"):
        vf.check_equal(f"premium_by_year.{col}", [int(x) for x in column(pby, col, "premium_by_year")], g[col])
    for col in ("total_earned_premium", "total_written_premium"):
        vf.check_close(f"premium_by_year.{col}", column(pby, col, "premium_by_year"), g[col], RTOL)
    pr = dict_value(call, "premium_ratios", "A")
    gr = gt_a["premium_ratios"]
    vf.check_equal("premium_ratios.origin_year", [int(x) for x in column(pr, "origin_year", "premium_ratios")],
                   gr["origin_year"])
    vf.check_close("premium_ratios.reserve_to_premium", column(pr, "reserve_to_premium", "premium_ratios"),
                   gr["reserve_to_premium_harness_computed"], RTOL, floor=0.0)


@pytest.mark.category("numbers_A")
def test_step_functions_A(outputs, gt_a):
    steps = call_of(outputs, "steps_A")
    fit = steps["fit"]
    vf.require(fit.get("returned_type") == "dict", "fit_odp_glm: did not return a dict")
    vf.check_close("fit_odp_glm phi", number(fit["values"].get("phi", {}), "fit_odp_glm phi"), gt_a["phi"],
                   RTOL, floor=0.0)
    pred = steps["predictions"]
    vf.check_equal("predict_reserves.origin", [int(x) for x in column(pred, "origin", "predict_reserves")],
                   gt_a["predictions"]["origin"])
    vf.check_equal("predict_reserves.dev", [int(x) for x in column(pred, "dev", "predict_reserves")],
                   gt_a["predictions"]["dev"])
    vf.check_close("predict_reserves.predicted", column(pred, "predicted", "predict_reserves"),
                   gt_a["predictions"]["predicted"], RTOL)


# ---------------------------------------------------------------------------
# the hidden triangle B
# ---------------------------------------------------------------------------
@pytest.mark.category("hidden_B")
def test_hidden_triangle_dispersion(outputs, gt_b):
    call = call_of(outputs, "B")
    vf.check_close("phi", number(dict_value(call, "phi", "B"), "phi", True), gt_b["phi"], RTOL, 0.0, hidden=True)
    vf.check_close("deviance", number(dict_value(call, "deviance", "B"), "deviance", True), gt_b["deviance"],
                   RTOL, 0.0, hidden=True)
    vf.check_equal("df_residual", [int(number(dict_value(call, "df_residual", "B"), "df_residual", True))],
                   [gt_b["df_residual"]], hidden=True)


@pytest.mark.category("hidden_B")
def test_hidden_triangle_reserves(outputs, gt_b):
    call = call_of(outputs, "B")
    v = dict_value(call, "reserves_by_origin", "B")
    vf.check_close("reserves", column(v, "reserve", "reserves_by_origin", True),
                   gt_b["reserves_by_origin"]["reserve"], RTOL, hidden=True)
    vf.check_close("total", number(dict_value(call, "total_reserve", "B"), "total_reserve", True),
                   gt_b["total_reserve"], RTOL, hidden=True)
    pr = dict_value(call, "premium_ratios", "B")
    vf.check_close("ratios", column(pr, "reserve_to_premium", "premium_ratios", True),
                   gt_b["premium_ratios"]["reserve_to_premium_harness_computed"], RTOL, 0.0, hidden=True)


# ---------------------------------------------------------------------------
# scaling
# ---------------------------------------------------------------------------
@pytest.mark.category("scaling")
def test_scaling_invariance(outputs, gt_a):
    """Doubling every cell doubles phi, the deviance and every prediction."""
    steps = call_of(outputs, "steps_A_x2")
    fit = steps["fit"]
    vf.require(fit.get("returned_type") == "dict", "fit_odp_glm: did not return a dict")
    vf.check_close("phi (doubled triangle)", number(fit["values"].get("phi", {}), "phi"), 2 * gt_a["phi"],
                   RTOL, floor=0.0)
    vf.check_close("deviance (doubled triangle)", number(fit["values"].get("deviance", {}), "deviance"),
                   2 * gt_a["deviance"], RTOL, floor=0.0)
    vf.check_close("predictions (doubled triangle)",
                   column(steps["predictions"], "predicted", "predict_reserves"),
                   [2 * x for x in gt_a["predictions"]["predicted"]], RTOL)


# ---------------------------------------------------------------------------
# bootstrap (1,000 draws on A and on B, seed 42)
# ---------------------------------------------------------------------------
def _boot(outputs, cid):
    return draws_of(dict_value(call_of(outputs, cid), "boot_results", cid), "boot_results", cid == "B")


@pytest.mark.category("bootstrap_A")
def test_bootstrap_A_draws(outputs, gt_a):
    d = _boot(outputs, "A")
    vf.require(d.size == gt_a["bootstrap"]["n_boot_requested"],
               "boot_results: expected one total per requested bootstrap replicate (1,000)")
    vf.require(np.unique(d).size > 1 and d.std(ddof=1) > 0, "boot_results: the draws are constant")


@pytest.mark.category("bootstrap_A")
def test_bootstrap_A_distribution(outputs, gt_a):
    d, r = _boot(outputs, "A"), np.asarray(gt_a["bootstrap"]["draws"], dtype=float)
    vf.check_mean_in_mc_se("bootstrap mean", d, r, k=4.0)
    vf.check_sd_ratio("bootstrap standard deviation", d, r, tol=0.10)


@pytest.mark.category("bootstrap_B")
def test_bootstrap_B_draws(outputs, gt_b):
    d = _boot(outputs, "B")
    vf.require(d.size == gt_b["bootstrap"]["n_boot_requested"] and np.unique(d).size > 1,
               "", hidden=True)


@pytest.mark.category("bootstrap_B")
def test_bootstrap_B_distribution(outputs, gt_b):
    d, r = _boot(outputs, "B"), np.asarray(gt_b["bootstrap"]["draws"], dtype=float)
    vf.check_mean_in_mc_se("bootstrap mean", d, r, k=4.0, hidden=True)
    vf.check_sd_ratio("bootstrap standard deviation", d, r, tol=0.10, hidden=True)


# ---------------------------------------------------------------------------
# seeds (n_boot = 200 on the given triangle)
# ---------------------------------------------------------------------------
@pytest.mark.category("seeds")
def test_same_seed_reproduces_draws(outputs):
    a = draws_of(call_of(outputs, "seed42_a")["draws"], "bootstrap_reserves(seed=42)")
    b = draws_of(call_of(outputs, "seed42_b")["draws"], "bootstrap_reserves(seed=42), repeated")
    vf.require(a.size == 200, "bootstrap_reserves(n_boot=200): expected 200 draws")
    vf.require(a.shape == b.shape and np.array_equal(a, b),
               "bootstrap_reserves: the same seed did not reproduce the same draws")


@pytest.mark.category("seeds")
def test_other_seed_changes_draws(outputs):
    a = draws_of(call_of(outputs, "seed42_a")["draws"], "bootstrap_reserves(seed=42)")
    c = draws_of(call_of(outputs, "seed43")["draws"], "bootstrap_reserves(seed=43)")
    vf.require(not (a.shape == c.shape and np.array_equal(a, c)),
               "bootstrap_reserves: a different seed gave the same draws (is the seed used?)")
