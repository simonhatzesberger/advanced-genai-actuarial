"""pytest configuration for the Case Study 4 suites (the "grade" half).

The grader never imports the translated module. It reads two things, both
named by environment variables set by harness/grade.py:

* ``CS4_OUTPUTS_JSON``      the runner's outputs (what the translation computed)
* ``CS4_GROUND_TRUTH_DIR``  R's ground truth (bundle/ground_truth)

and writes one results file:

* ``CS4_RESULTS_JSON``      per test: id, category, outcome and a value-free
                            message. Never pytest's failure report (longrepr)
                            and never captured output: those can contain
                            expected values.
"""

from __future__ import annotations

import json
import os
import pathlib

import pytest

from valuefree import ValueFreeFailure

_RESULTS: list[dict] = []


def pytest_configure(config):
    config.addinivalue_line("markers", "category(name): test category for the results table")


@pytest.fixture(scope="session")
def outputs() -> dict:
    path = os.environ.get("CS4_OUTPUTS_JSON", "")
    if not path or not pathlib.Path(path).is_file():
        raise ValueFreeFailure("the runner's outputs file is missing")
    return json.loads(pathlib.Path(path).read_text(encoding="utf-8"))


@pytest.fixture(scope="session")
def ground_truth():
    root = pathlib.Path(os.environ.get("CS4_GROUND_TRUTH_DIR", ""))
    cache: dict = {}

    def load(name: str) -> dict:
        if name not in cache:
            cache[name] = json.loads((root / name).read_text(encoding="utf-8"))
        return cache[name]

    return load


def _category(item) -> str:
    marker = item.get_closest_marker("category")
    return marker.args[0] if marker and marker.args else "uncategorised"


@pytest.hookimpl(wrapper=True)
def pytest_runtest_makereport(item, call):
    report = yield
    if report.when == "call" or (report.when == "setup" and not report.passed):
        if report.passed:
            message = ""
        elif call.excinfo is not None and isinstance(call.excinfo.value, ValueFreeFailure):
            message = str(call.excinfo.value)
        elif call.excinfo is not None:
            message = f"{call.excinfo.typename} inside the test (details withheld)"
        else:
            message = "failed (details withheld)"
        _RESULTS.append({
            "id": item.name,
            "category": _category(item),
            "outcome": "error" if report.when == "setup" else report.outcome,
            "message": message,
        })
    return report


def pytest_sessionfinish(session, exitstatus):
    path = os.environ.get("CS4_RESULTS_JSON")
    if path:
        pathlib.Path(path).write_text(
            json.dumps({"exitstatus": int(exitstatus), "results": _RESULTS}, indent=1),
            encoding="utf-8", newline="\n")
