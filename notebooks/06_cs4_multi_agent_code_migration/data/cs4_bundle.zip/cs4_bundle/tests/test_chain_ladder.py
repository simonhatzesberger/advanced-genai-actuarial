"""Test suite for the chain-ladder migration (Case Study 4).

Every number the tests check was computed by the translated code (recorded
by harness/runner.py) and is compared with R's own results
(ground_truth/*.json). Nothing is recomputed here.

Categories: interface, numbers_A (the given triangle), hidden_B (a second
triangle the agents never see), tail (tail factor 1.05), scaling (every cell
doubled), errors (R's stop() on a triangle with a gap), printout (main()).

Tolerance: relative 1e-9 (floor 1.0 for values near zero). Measured margins
of the reference translation are in the harness README.
"""

from __future__ import annotations

import re

import numpy as np
import pytest

import valuefree as vf

RTOL = 1e-9
FLOOR = 1.0  # currency units; only matters for the zero reserve of the oldest year
RESULT_COLUMNS = ["origin_year", "latest_dev_period", "latest_observed", "cdf_to_ultimate",
                  "ultimate", "unpaid_claims_reserve"]
KEYS = ["cumulative", "dev_factors", "n_pairs", "cdf_to_ultimate", "results", "total_reserve"]
WHAT = {"A": "run_chain_ladder on the given triangle",
        "A_tail105": "run_chain_ladder with tail_factor=1.05",
        "B": "run_chain_ladder on a second triangle",
        "A_x2": "run_chain_ladder on the doubled triangle",
        "main": "main()"}


# ---------------------------------------------------------------------------
# helpers: fetch what the translation returned, failing with value-free text
# ---------------------------------------------------------------------------
def result_of(outputs: dict, cid: str) -> dict:
    hidden = cid == "B"
    if not outputs.get("import", {}).get("ok"):
        vf.fail("the module could not be imported", hidden)
    call = outputs.get("calls", {}).get(cid)
    if call is None:
        vf.fail(f"{WHAT[cid]}: not run", hidden)
    if not call.get("ok"):
        vf.fail(f"{WHAT[cid]}: raised {call.get('error_type', 'an exception')}", hidden)
    if call.get("returned_type") != "dict":
        vf.fail(f"{WHAT[cid]}: did not return a dict", hidden)
    return call


def value(call: dict, key: str, cid: str):
    hidden = cid == "B"
    v = call.get("values", {}).get(key)
    if v is None:
        vf.fail(f"{WHAT[cid]}: key '{key}' missing", hidden)
    return v


def array(call: dict, key: str, cid: str) -> list:
    v = value(call, key, cid)
    if v.get("kind") == "frame":  # accept a one-column table as an array
        cols = list(v["frame"]["data"].values())
        vf.require(len(cols) == 1, f"{key}: expected an array", cid == "B")
        return cols[0]
    vf.require(v.get("kind") == "array", f"{key}: expected an array", cid == "B")
    return v["values"]


def number(call: dict, key: str, cid: str):
    v = value(call, key, cid)
    vf.require(v.get("kind") == "number" and v.get("value") is not None,
               f"{key}: expected a finite number", cid == "B")
    return v["value"]


def results_column(call: dict, col: str, cid: str) -> list:
    v = value(call, "results", cid)
    vf.require(v.get("kind") == "frame", "results: expected a DataFrame", cid == "B")
    data = v["frame"]["data"]
    vf.require(col in data, f"results: column '{col}' missing", cid == "B")
    return data[col]


def cumulative_matrix(call: dict, cid: str) -> list:
    v = value(call, "cumulative", cid)
    vf.require(v.get("kind") == "frame", "cumulative: expected a DataFrame", cid == "B")
    data = v["frame"]["data"]
    cols = v["frame"]["columns"]
    return np.array([data[c] for c in cols], dtype=float).T.tolist() if cols else []


@pytest.fixture(scope="module")
def gt_a(ground_truth):
    return ground_truth("chain_ladder_A.json")["runs"]


@pytest.fixture(scope="module")
def gt_b(ground_truth):
    return ground_truth("chain_ladder_B.json")["runs"]["tail_1.00"]


def _nan_matrix(rows):
    return [[np.nan if v is None else v for v in r] for r in rows]


# ---------------------------------------------------------------------------
# interface
# ---------------------------------------------------------------------------
@pytest.mark.category("interface")
def test_module_imports_and_exposes_interface(outputs):
    imp = outputs.get("import", {})
    vf.require(imp.get("ok"), f"the module could not be imported ({imp.get('error_type', 'error')})")
    missing = [f for f in ("run_chain_ladder", "main") if f not in imp.get("callables", [])]
    vf.require(not missing, f"missing function(s): {', '.join(missing)}")


@pytest.mark.category("interface")
def test_return_structure(outputs):
    call = result_of(outputs, "A")
    missing = [k for k in KEYS if k not in call.get("keys", [])]
    vf.require(not missing, f"run_chain_ladder: key(s) missing: {', '.join(missing)}")
    v = call["values"]
    vf.require(v["cumulative"].get("kind") == "frame" and v["cumulative"].get("shape") == [10, 10],
               "cumulative: expected a 10 x 10 DataFrame")
    for key, n in (("dev_factors", 9), ("n_pairs", 9), ("cdf_to_ultimate", 10)):
        vf.require(v[key].get("kind") == "array" and len(v[key].get("values", [])) == n,
                   f"{key}: expected a numpy array with {n} values")
    vf.require(v["n_pairs"].get("dtype_kind") in ("i", "u"), "n_pairs: expected an integer array")
    res = v["results"]
    vf.require(res.get("kind") == "frame", "results: expected a DataFrame")
    missing = [c for c in RESULT_COLUMNS if c not in res.get("columns", [])]
    vf.require(not missing, f"results: column(s) missing: {', '.join(missing)}")
    vf.require(res["frame"]["n_rows"] == 10, "results: expected one row per origin year")
    vf.require(v["total_reserve"].get("kind") == "number", "total_reserve: expected a float")


@pytest.mark.category("interface")
def test_result_labels(outputs, gt_a):
    call = result_of(outputs, "A")
    vf.check_equal("results.origin_year", results_column(call, "origin_year", "A"),
                   gt_a["tail_1.00"]["origin_years"])
    vf.check_equal("results.latest_dev_period", results_column(call, "latest_dev_period", "A"),
                   gt_a["tail_1.00"]["latest_dev_period"])


@pytest.mark.category("interface")
def test_values_are_unrounded(outputs):
    call = result_of(outputs, "A")
    factors = np.array(array(call, "dev_factors", "A"), dtype=float)
    reserves = np.array(results_column(call, "unpaid_claims_reserve", "A"), dtype=float)
    vf.require(np.any(np.abs(factors - np.round(factors, 6)) > 1e-12),
               "dev_factors look rounded; the interface asks for unrounded values")
    vf.require(np.any(np.abs(reserves - np.round(reserves, 2)) > 1e-9),
               "results.unpaid_claims_reserve looks rounded; the interface asks for unrounded values")


# ---------------------------------------------------------------------------
# the given triangle A
# ---------------------------------------------------------------------------
@pytest.mark.category("numbers_A")
def test_cumulative_triangle_A(outputs, gt_a):
    call = result_of(outputs, "A")
    vf.check_close("cumulative", cumulative_matrix(call, "A"),
                   _nan_matrix(gt_a["tail_1.00"]["cumulative"]), RTOL, FLOOR)


@pytest.mark.category("numbers_A")
def test_dev_factors_and_pairs_A(outputs, gt_a):
    call = result_of(outputs, "A")
    vf.check_close("dev_factors", array(call, "dev_factors", "A"), gt_a["tail_1.00"]["dev_factors"], RTOL)
    vf.check_equal("n_pairs", [int(x) for x in array(call, "n_pairs", "A")], gt_a["tail_1.00"]["n_pairs"])


@pytest.mark.category("numbers_A")
def test_cdf_to_ultimate_A(outputs, gt_a):
    call = result_of(outputs, "A")
    vf.check_close("cdf_to_ultimate", array(call, "cdf_to_ultimate", "A"),
                   gt_a["tail_1.00"]["cdf_to_ultimate"], RTOL)


@pytest.mark.category("numbers_A")
def test_ultimates_and_reserves_A(outputs, gt_a):
    call, g = result_of(outputs, "A"), gt_a["tail_1.00"]
    vf.check_close("results.latest_observed", results_column(call, "latest_observed", "A"),
                   g["latest_observed"], RTOL, FLOOR)
    vf.check_close("results.cdf_to_ultimate", results_column(call, "cdf_to_ultimate", "A"),
                   [g["cdf_to_ultimate"][k - 1] for k in g["latest_dev_idx"]], RTOL)
    vf.check_close("results.ultimate", results_column(call, "ultimate", "A"), g["ultimate"], RTOL, FLOOR)
    vf.check_close("results.unpaid_claims_reserve", results_column(call, "unpaid_claims_reserve", "A"),
                   g["unpaid_claims_reserve"], RTOL, FLOOR)


@pytest.mark.category("numbers_A")
def test_total_reserve_A(outputs, gt_a):
    call = result_of(outputs, "A")
    vf.check_close("total_reserve", number(call, "total_reserve", "A"), gt_a["tail_1.00"]["total_reserve"], RTOL)


# ---------------------------------------------------------------------------
# the hidden triangle B (messages say only that B fails)
# ---------------------------------------------------------------------------
@pytest.mark.category("hidden_B")
def test_hidden_triangle_factors(outputs, gt_b):
    call = result_of(outputs, "B")
    vf.check_close("dev_factors", array(call, "dev_factors", "B"), gt_b["dev_factors"], RTOL, hidden=True)
    vf.check_equal("n_pairs", [int(x) for x in array(call, "n_pairs", "B")], gt_b["n_pairs"], hidden=True)
    vf.check_close("cdf_to_ultimate", array(call, "cdf_to_ultimate", "B"), gt_b["cdf_to_ultimate"], RTOL,
                   hidden=True)


@pytest.mark.category("hidden_B")
def test_hidden_triangle_reserves(outputs, gt_b):
    call = result_of(outputs, "B")
    vf.check_close("cumulative", cumulative_matrix(call, "B"), _nan_matrix(gt_b["cumulative"]), RTOL, FLOOR,
                   hidden=True)
    vf.check_close("ultimate", results_column(call, "ultimate", "B"), gt_b["ultimate"], RTOL, FLOOR, hidden=True)
    vf.check_close("reserves", results_column(call, "unpaid_claims_reserve", "B"),
                   gt_b["unpaid_claims_reserve"], RTOL, FLOOR, hidden=True)
    vf.check_close("total_reserve", number(call, "total_reserve", "B"), gt_b["total_reserve"], RTOL,
                   hidden=True)


# ---------------------------------------------------------------------------
# options and properties
# ---------------------------------------------------------------------------
@pytest.mark.category("tail")
def test_tail_factor(outputs, gt_a):
    call, g = result_of(outputs, "A_tail105"), gt_a["tail_1.05"]
    vf.check_close("cdf_to_ultimate (tail 1.05)", array(call, "cdf_to_ultimate", "A_tail105"),
                   g["cdf_to_ultimate"], RTOL)
    vf.check_close("reserves (tail 1.05)", results_column(call, "unpaid_claims_reserve", "A_tail105"),
                   g["unpaid_claims_reserve"], RTOL, FLOOR)
    vf.check_close("total_reserve (tail 1.05)", number(call, "total_reserve", "A_tail105"),
                   g["total_reserve"], RTOL)


@pytest.mark.category("scaling")
def test_scaling_doubles_reserves_keeps_factors(outputs, gt_a):
    call, g = result_of(outputs, "A_x2"), gt_a["tail_1.00"]
    vf.check_close("dev_factors (doubled triangle)", array(call, "dev_factors", "A_x2"), g["dev_factors"], RTOL)
    vf.check_close("reserves (doubled triangle)", results_column(call, "unpaid_claims_reserve", "A_x2"),
                   [2 * x for x in g["unpaid_claims_reserve"]], RTOL, FLOOR)
    vf.check_close("total_reserve (doubled triangle)", number(call, "total_reserve", "A_x2"),
                   2 * g["total_reserve"], RTOL)


@pytest.mark.category("errors")
def test_gap_in_triangle_raises_value_error(outputs, ground_truth):
    vf.require(ground_truth("chain_ladder_gap.json")["r_stops"], "ground truth: R should stop")
    vf.require(outputs.get("import", {}).get("ok"), "the module could not be imported")
    call = outputs.get("calls", {}).get("gap")
    vf.require(call is not None, "triangle with an internal gap: not run")
    vf.require(not call.get("ok"),
               "a triangle with an internal gap must raise ValueError (R stops); it returned normally")
    vf.require(call.get("is_value_error"),
               f"a triangle with an internal gap raised {call.get('error_type')} instead of ValueError")


# ---------------------------------------------------------------------------
# main(): R's printout and the returned results
# ---------------------------------------------------------------------------
@pytest.mark.category("printout")
def test_main_prints_r_total(outputs, gt_a):
    call = result_of(outputs, "main")
    text = call.get("stdout_tail", "")
    found = re.findall(r"Total Unpaid Claims Reserve:\s*([-+]?[0-9][0-9,]*\.?[0-9]*(?:[eE][-+]?\d+)?)", text)
    vf.require(bool(found), "main(): no line 'Total Unpaid Claims Reserve: <number>' in the printout")
    printed = float(found[-1].replace(",", ""))
    vf.require(abs(printed - gt_a["tail_1.00"]["printed_total"]) < 0.005,
               "main(): the printed total differs from the total R prints")


@pytest.mark.category("printout")
def test_main_returns_unrounded_results(outputs, gt_a):
    call = result_of(outputs, "main")
    vf.check_close("main() total_reserve", number(call, "total_reserve", "main"),
                   gt_a["tail_1.00"]["total_reserve"], RTOL)
