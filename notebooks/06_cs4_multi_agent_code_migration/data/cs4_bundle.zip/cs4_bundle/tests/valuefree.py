"""Value-free checks for the Case Study 4 test suites.

PYTEST_DONT_REWRITE  (this marker keeps pytest's assertion rewriting away
from this module; the test modules themselves contain no bare ``assert``.)

Why: pytest's own failure reports print the expected value (``assert
15316.35 == 15316.3408...``, ``pytest.approx`` and ``assert_allclose`` all
do). The agents only ever see the messages raised here, which name the
quantity and a tolerance band, never a sign, an exact error or an expected
value. A failure on the hidden second triangle says only that it fails there.
"""

from __future__ import annotations

import math

import numpy as np

HIDDEN_MESSAGE = "fails on a second, hidden triangle"
_EDGES = (0.0, 1e-12, 1e-9, 1e-6, 1e-3, 1e-1)


class ValueFreeFailure(AssertionError):
    """A test failure whose message carries no expected value."""


def band(rel: float) -> str:
    """Coarse bucket for a relative error, e.g. 'relative error band 1e-6 to 1e-3'."""
    for lo, hi in zip(_EDGES, _EDGES[1:]):
        if rel < hi:
            return f"relative error band {lo:.0e} to {hi:.0e}".replace("0e+00", "0")
    return "relative error above 1e-1"


def fail(message: str, hidden: bool = False):
    raise ValueFreeFailure(HIDDEN_MESSAGE if hidden else message)


def require(condition: bool, message: str, hidden: bool = False) -> None:
    if not condition:
        fail(message, hidden)


def _as_float_array(x, name: str, hidden: bool) -> np.ndarray:
    try:
        return np.asarray([np.nan if v is None else v for v in np.ravel(np.asarray(x, dtype=object))],
                          dtype=float).reshape(np.shape(np.asarray(x, dtype=object)))
    except (TypeError, ValueError):
        fail(f"{name}: not numeric", hidden)


def check_close(name: str, actual, expected, rtol: float, floor: float = 1.0,
                hidden: bool = False) -> None:
    """Relative closeness with a floor for values near zero.

    The error of each element is |actual - expected| / max(|expected|, floor);
    the check fails if the largest one exceeds ``rtol``. ``None`` counts as
    missing (NaN); missing cells must be exactly where R has them.
    """
    a = _as_float_array(actual, name, hidden)
    e = _as_float_array(expected, name, hidden)
    if a.shape != e.shape:
        fail(f"{name}: has {a.size} values; the interface requires {e.size}", hidden)
    a_nan, e_nan = np.isnan(a), np.isnan(e)
    if not np.array_equal(a_nan, e_nan):
        fail(f"{name}: missing values where R has numbers, or numbers where R has none", hidden)
    if np.any(np.isinf(a[~a_nan])):
        fail(f"{name}: contains infinite values", hidden)
    if (~e_nan).sum() == 0:
        return
    rel = float(np.max(np.abs(a[~a_nan] - e[~e_nan]) / np.maximum(np.abs(e[~e_nan]), floor)))
    if not rel <= rtol:
        fail(f"{name}: outside tolerance ({band(rel)})", hidden)


def _label(v) -> str:
    """Labels compare as text; a whole-number float (2010.0) counts as 2010."""
    if isinstance(v, (float, np.floating)) and float(v).is_integer():
        return str(int(v))
    return str(v)


def check_equal(name: str, actual, expected, hidden: bool = False) -> None:
    """Exact equality for labels and counts (compared as text)."""
    a = [_label(v) for v in np.ravel(np.asarray(actual, dtype=object))]
    e = [_label(v) for v in np.ravel(np.asarray(expected, dtype=object))]
    if len(a) != len(e):
        fail(f"{name}: has {len(a)} entries; the interface requires {len(e)}", hidden)
    if a != e:
        fail(f"{name}: does not match R", hidden)


def check_mean_in_mc_se(name: str, draws, r_draws, k: float = 4.0, hidden: bool = False) -> None:
    """Bootstrap mean within k Monte Carlo standard errors of R's bootstrap mean.

    The standard error is that of the difference of two independent Monte
    Carlo means: sqrt(s_py^2 / n_py + s_R^2 / n_R).
    """
    d = np.asarray(draws, dtype=float)
    r = np.asarray(r_draws, dtype=float)
    se = math.sqrt(d.var(ddof=1) / d.size + r.var(ddof=1) / r.size)
    z = abs(d.mean() - r.mean()) / se if se > 0 else math.inf
    if not z <= k:
        where = "4 to 10" if z <= 10 else ("10 to 100" if z <= 100 else "more than 100")
        fail(f"{name}: outside tolerance ({where} Monte Carlo standard errors from R's)", hidden)


def check_sd_ratio(name: str, draws, r_draws, tol: float = 0.10, hidden: bool = False) -> None:
    """Bootstrap standard deviation within +/- tol (relative) of R's."""
    d = np.asarray(draws, dtype=float)
    r = np.asarray(r_draws, dtype=float)
    rel = abs(d.std(ddof=1) / r.std(ddof=1) - 1.0)
    if not rel <= tol:
        where = ("10% to 25%" if rel <= 0.25 else ("25% to 50%" if rel <= 0.5 else "more than 50%"))
        fail(f"{name}: outside tolerance ({where} from R's)", hidden)
