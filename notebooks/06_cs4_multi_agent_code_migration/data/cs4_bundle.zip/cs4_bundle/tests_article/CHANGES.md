# The article's test suites, changed only in their paths

Source: `output/tests/` of the article's notebook folder, byte-identical to
`case-studies/2026/actuarial_legacy_code_migration_multi-agent_system/tests/`
in https://github.com/IAA-AITF/Actuarial-AI-Case-Studies at tag `eaj-v1.0`
(MIT licence, Copyright (c) 2025 International Actuarial Association).

| File here | Article file | Change |
|---|---|---|
| `test_chain_ladder_article.py` | `test_chain_ladder.py` | renamed; 4 path lines changed (below) |
| `test_reserving_glm_article.py` | `test_reserving_glm.py` | renamed; 4 path lines changed (below) |
| `expected_values_chain_ladder.json` | same name | unchanged |
| `expected_values_reserving_glm.json` | same name | unchanged |
| `conftest.py` | (not the article's) | ours: registers the article's `data` and `content` markers and writes id, category and outcome to the file named by `CS4_RESULTS_JSON`, for scoring |

Why the path changes: the module under test is no longer in `../translated`
(it is passed in `CS4_ARTICLE_TRANSLATED_DIR`), and the data now live in the
bundle's `legacy/` folder instead of the notebook's `examples/` folder. The
data files are the article's files (identical bytes).

Every other line, every test, every tolerance and every expected value is the
article's. As in the article, these suites import the module under test into
the pytest process; run them only on code you have read (the mutants and the
archived translations), never on fresh LLM output.

Complete diff:

```diff
--- article output/tests/test_chain_ladder.py
+++ tests_article/test_chain_ladder_article.py
@@ -17,2 +17,2 @@
-sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "translated"))
-sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..")))
+sys.path.insert(0, os.environ["CS4_ARTICLE_TRANSLATED_DIR"])
+sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
@@ -22,2 +22,2 @@
-BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
-DATA_PATH = os.path.join(BASE_DIR, "examples", "simple", "triangle.csv")
+BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
+DATA_PATH = os.path.join(BASE_DIR, "legacy", "chain_ladder", "triangle.csv")

--- article output/tests/test_reserving_glm.py
+++ tests_article/test_reserving_glm_article.py
@@ -18,2 +18,2 @@
-sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "translated"))
-sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..")))
+sys.path.insert(0, os.environ["CS4_ARTICLE_TRANSLATED_DIR"])
+sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
@@ -23,2 +23,2 @@
-BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
-DATA_DIR = os.path.join(BASE_DIR, "examples", "difficult")
+BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
+DATA_DIR = os.path.join(BASE_DIR, "legacy", "reserving_glm")
```
