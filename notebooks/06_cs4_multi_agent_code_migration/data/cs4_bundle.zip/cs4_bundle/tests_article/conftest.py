"""pytest configuration for the article's suites (ours, not the article's).

Registers the article's two markers and records, for each test, its id,
category (``data`` or ``content``) and outcome in the JSON file named by
``CS4_RESULTS_JSON``, in the same format as tests/conftest.py, so that
harness/grade.py can score both suites the same way. Messages are reduced to
the exception type.
"""

from __future__ import annotations

import json
import os
import pathlib

import pytest

_RESULTS: list[dict] = []


def pytest_configure(config):
    config.addinivalue_line("markers", "data: marks a test as a data/format test")
    config.addinivalue_line("markers", "content: marks a test as a content/numerical test")


@pytest.hookimpl(wrapper=True)
def pytest_runtest_makereport(item, call):
    report = yield
    if report.when == "call" or (report.when == "setup" and not report.passed):
        category = ("data" if item.get_closest_marker("data")
                    else "content" if item.get_closest_marker("content") else "uncategorised")
        _RESULTS.append({
            "id": item.name,
            "category": category,
            "outcome": "error" if report.when == "setup" else report.outcome,
            "message": "" if report.passed else (call.excinfo.typename if call.excinfo else "failed"),
        })
    return report


def pytest_sessionfinish(session, exitstatus):
    path = os.environ.get("CS4_RESULTS_JSON")
    if path:
        pathlib.Path(path).write_text(
            json.dumps({"exitstatus": int(exitstatus), "results": _RESULTS}, indent=1),
            encoding="utf-8", newline="\n")
